'use strict';
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');

const config = require('./src/config');
const { query } = require('./src/db');
const migrate = require('./src/migrate');
const { authUser, authOwner } = require('./src/auth');
const { ApiError } = require('./src/util');

const app = express();
// Hostinger place l'application derrière un proxy HTTPS : nécessaire pour l'IP réelle et les cookies "secure"
app.set('trust proxy', 1);
app.disable('x-powered-by');

// En production, tout passe en HTTPS (le proxy de l'hébergeur transmet le protocole d'origine)
if (config.prod && config.forceHttps) {
  app.use((req, res, next) => {
    if (req.secure || req.path === '/api/health') return next();
    if (req.method === 'GET' || req.method === 'HEAD') return res.redirect(301, 'https://' + req.get('host') + req.originalUrl);
    return res.status(403).json({ error: 'HTTPS obligatoire' });
  });
}

app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'default-src': ["'self'"],
      'script-src': ["'self'"],
      'style-src': ["'self'", "'unsafe-inline'"],
      'img-src': ["'self'", 'data:', 'blob:'],
      'connect-src': ["'self'"],
      'object-src': ["'none'"],
      'frame-ancestors': ["'none'"],
      'base-uri': ["'self'"],
      'form-action': ["'self'"],
      'upgrade-insecure-requests': config.prod ? [] : null,
    },
  },
  hsts: config.prod ? { maxAge: 31536000, includeSubDomains: true } : false,
  referrerPolicy: { policy: 'no-referrer' },
}));
app.use((req, res, next) => {
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  next();
});
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());

/* ---------- API ---------- */
const api = express.Router();

// Les réponses de l'API contiennent des données privées : jamais de cache (navigateur ni proxy)
api.use((req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });
// Plafond général par adresse IP (en plus des limites spécifiques de connexion et d'inscription)
api.use(rateLimit({
  windowMs: 60 * 1000,
  limit: 600,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Trop de requêtes. Patientez un instant.' },
}));

// Protection CSRF : les requêtes qui modifient des données doivent porter cet en-tête, qu'un site tiers ne peut pas envoyer
api.use((req, res, next) => {
  if (req.method !== 'GET' && req.method !== 'HEAD' && req.get('x-requested-with') !== 'managestion') {
    return next(new ApiError(403, 'Requête refusée'));
  }
  next();
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 15,
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true,
  message: { error: 'Trop de tentatives. Réessayez dans quelques minutes.' },
});
const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Trop de créations d\'entreprise depuis cette adresse. Réessayez plus tard.' },
});
// Annulation de vente : les tentatives avec un mauvais identifiant / mot de passe sont limitées (comme la connexion)
const cancelLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true,
  message: { error: 'Trop de tentatives d\'annulation. Réessayez dans quelques minutes.' },
});
api.use('/sales/:id/credit-note', cancelLimiter);
api.use('/auth/login', loginLimiter);
api.use('/auth/register', registerLimiter);

api.get('/health', async (req, res, next) => {
  try { await query('SELECT 1'); res.json({ ok: true }); } catch (e) { next(e); }
});
api.use('/auth', require('./src/routes/auth'));
api.use('/owner', authOwner, require('./src/routes/owner'));
api.use(authUser);
api.use(require('./src/routes/admin'));
api.use(require('./src/routes/stock'));
api.use(require('./src/routes/sales'));
api.use(require('./src/routes/customers'));
api.use(require('./src/routes/inventory'));
api.use(require('./src/routes/purchasing'));
api.use(require('./src/routes/finance'));
api.use((req, res, next) => next(new ApiError(404, 'Route inconnue')));

app.use('/api', api);

/* ---------- Application web (fichiers statiques) ---------- */
app.use(express.static(path.join(__dirname, 'public'), {
  index: 'index.html',
  setHeaders(res, file) {
    // La page, le service worker et le manifeste doivent toujours être revalidés (mises à jour de l'application)
    if (/(index\.html|sw\.js|manifest\.webmanifest)$/.test(file)) res.setHeader('Cache-Control', 'no-cache');
    if (/sw\.js$/.test(file)) res.setHeader('Service-Worker-Allowed', '/');
  },
}));

/* ---------- Erreurs ---------- */
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof ApiError) return res.status(err.status).json({ error: err.message });
  if (err && err.type === 'entity.too.large') return res.status(413).json({ error: 'Données trop volumineuses' });
  if (err && err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Requête illisible' });
  if (err && err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Cet élément existe déjà' });
  console.error(err);
  res.status(500).json({ error: 'Erreur du serveur. Réessayez dans un instant.' });
});

/* ---------- Démarrage ---------- */
(async () => {
  try {
    const n = await migrate();
    console.log('Base de données prête (' + n + ' tables vérifiées).');
  } catch (e) {
    console.error('Impossible de se connecter à la base de données : ' + e.message);
    console.error('Vérifiez DB_HOST, DB_USER, DB_PASSWORD et DB_NAME.');
    process.exit(1);
  }
  const server = app.listen(config.port, () => console.log('ManaGestion démarré sur le port ' + config.port));
  // Arrêt propre quand l'hébergeur redémarre l'application
  const stop = () => server.close(() => process.exit(0));
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
})();

process.on('unhandledRejection', (e) => { console.error('Promesse rejetée non gérée :', e); });
process.on('uncaughtException', (e) => { console.error('Exception non gérée :', e); process.exit(1); });

module.exports = app;
