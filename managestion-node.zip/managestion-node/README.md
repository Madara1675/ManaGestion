# ManaGestion

Application web (PWA) de gestion de stock, de ventes et de trésorerie pour magasins et entrepôts. Node.js + Express + MySQL. Plusieurs entreprises, plusieurs emplacements, plusieurs utilisateurs sur les mêmes données.

## Documentation

| Document | Pour qui | Contenu |
|---|---|---|
| [docs/DEPLOIEMENT-HOSTINGER.md](docs/DEPLOIEMENT-HOSTINGER.md) | vous | Installation pas à pas, variables, liste de contrôle, mises à jour |
| [docs/SECURITE.md](docs/SECURITE.md) | vous | Protections en place, bonnes pratiques, limites connues, incident |
| [docs/ADMINISTRATION.md](docs/ADMINISTRATION.md) | vous | Espace propriétaire, abonnement, sauvegardes, surveillance |
| [docs/GUIDE-UTILISATEUR.md](docs/GUIDE-UTILISATEUR.md) | vos clients | Rôles, caisse, stock, crédits, achats, inventaire |
| [docs/API.md](docs/API.md) | développeurs | Toutes les routes et leurs accès |
| [docs/BASE-DE-DONNEES.md](docs/BASE-DE-DONNEES.md) | développeurs | Tables et principes |
| [docs/DEPANNAGE.md](docs/DEPANNAGE.md) | tous | Erreurs courantes et solutions |
| [CHANGELOG.md](CHANGELOG.md) | tous | Historique |

## Démarrage rapide

```
cp .env.example .env      # renseignez la base et JWT_SECRET
npm install
npm start                 # http://localhost:3000
```

Pour la mise en ligne, suivez `docs/DEPLOIEMENT-HOSTINGER.md`.

## Contenu du projet

```
server.js              point d'entrée (Express, sécurité, routes)
src/                   configuration, base de données, authentification, routes de l'API
database/schema.sql    structure de la base (créée automatiquement au démarrage)
public/                interface web installable (PWA) + CGU et confidentialité à compléter
docs/                  documentation
.env.example           modèle des variables de configuration
```

## Fonctions

- Plusieurs entreprises ; chacune avec ses magasins/entrepôts, son stock séparé et ses transferts.
- Rôles : **administrateur**, **gérant** (son emplacement) et **employé** (caisse).
- Factures numérotées par emplacement, avoirs (annulation avec mot de passe du gérant), TVA, ticket 80 mm, PDF.
- Clients, remises, promotions, crédits clients, paiements partiels.
- Stock : réception, transfert, import CSV, inventaire physique, alertes de stock bas.
- Achats : bons de commande, réception partielle, dettes et paiements fournisseurs.
- Trésorerie, rapports mensuels, exports CSV, journal d'activité, sauvegarde JSON.
- Espace propriétaire : liste des entreprises, blocage, réinitialisation de mot de passe, **abonnement** (7 500 KMF/mois, « Non payé » à partir du 30/31, bouton « Payer »).

## Avant d'ouvrir aux clients

1. Remplissez `public/cgu.html` et `public/confidentialite.html` (éléments entre crochets) et faites-les relire ; la politique doit mentionner l'hébergeur.
2. Changez le mot de passe propriétaire (« Mon accès »).
3. Faites une sauvegarde et testez-la.
4. À chaque mise à jour de l'interface, changez `V` dans `public/sw.js`.

## Limites

- Les quantités sont entières (pas de vente au poids). Avoir = annulation de la facture entière.
- Une connexion internet est nécessaire (pas de mode hors ligne).
- Le code a été vérifié par relecture et par des tests d'interface avec un faux serveur ; faites un essai complet sur votre hébergement avant la mise en service (liste de contrôle dans `docs/DEPLOIEMENT-HOSTINGER.md`).
