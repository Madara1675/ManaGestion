# Historique des versions

## 2.1.0
- **Abonnement** : 7 500 KMF par mois, statut « Non payé » à partir du 30/31, bouton « Payer » dans l'espace propriétaire, bandeau pour les administrateurs avec le numéro +269 386 16 39.
- **Création d'entreprise simplifiée** : champs code entreprise, titulaire et compte bancaire, GSM, email 2 et NIF retirés ; le code de connexion est généré automatiquement.
- **Sécurité** : redirection HTTPS et HSTS en production, algorithme JWT imposé, `no-store` sur l'API, plafond général de requêtes, `Permissions-Policy`, `Referrer-Policy`, arrêt propre du serveur, mots de passe de 6 caractères minimum, annulation de vente soumise au mot de passe du gérant.
- **Correctif** : la connexion d'une version intermédiaire échouait (variable `slug` manquante) ; corrigé.
- Rôles : administrateur, gérant, employé ; promotions ; documentation complète (`docs/`).

## 2.0.0
- Passage en application Node.js + MySQL : données sur le serveur, plusieurs utilisateurs et appareils.
- Espace propriétaire, clients, remises, import CSV, inventaire physique, bons de commande et dettes fournisseurs.
