# Déploiement sur Hostinger (Node.js)

Ce guide installe ManaGestion pas à pas. Comptez 20 à 30 minutes. Les libellés de hPanel peuvent légèrement changer ; la logique reste la même.

## 0. Prérequis

| Élément | Détail |
|---|---|
| Forfait Hostinger | Hébergement **Business**, **Cloud** ou **VPS** (un hébergement « Premium » basique n'exécute pas Node.js) |
| Node.js | version **18 ou plus** (20 ou 22 conseillées) |
| Base de données | MySQL ou MariaDB (fournie par Hostinger) |
| Nom de domaine | avec certificat SSL actif (HTTPS obligatoire) |
| Sur votre ordinateur | le fichier `managestion-node.zip` et le fichier `.env` fourni |

## 1. Créer la base de données

1. hPanel > **Bases de données** > **Gestion** (MySQL).
2. Créez une base, un utilisateur et un mot de passe **fort** (16 caractères ou plus).
3. Notez les trois valeurs : nom de la base, utilisateur, mot de passe. Elles sont préfixées (ex. `u123456789_...`).
4. L'hôte est presque toujours `localhost`.

Vous n'avez **rien à importer** : les tables sont créées automatiquement au premier démarrage.

## 2. Créer l'application Node.js

1. hPanel > **Sites web** > **Ajouter un site web** > **Application web Node.js**.
2. Envoyez `managestion-node.zip` (ou connectez un dépôt GitHub **privé**).
3. Réglages de construction :
   - Version de Node.js : 18 ou plus
   - Fichier d'entrée : `server.js`
   - Commande d'installation : `npm install --omit=dev`
   - Commande de démarrage : `npm start`
4. Ne mettez jamais le dossier `node_modules` ni le fichier `.env` dans le zip ou dans GitHub.

## 3. Variables d'environnement

hPanel > Node.js > **Variables d'environnement**. Recopiez le contenu de votre fichier `.env`.

| Variable | Obligatoire | Valeur |
|---|---|---|
| `NODE_ENV` | oui | `production` |
| `DB_HOST` | oui | `localhost` (en général) |
| `DB_PORT` | non | `3306` |
| `DB_USER` | oui | utilisateur de la base |
| `DB_PASSWORD` | oui | mot de passe de la base |
| `DB_NAME` | oui | nom de la base |
| `JWT_SECRET` | oui | chaîne aléatoire d'au moins 32 caractères (déjà générée dans votre `.env`) |
| `OWNER_LOGIN` / `OWNER_PIN` | recommandé | identifiant et mot de passe propriétaire (6 caractères minimum) |
| `ALLOW_REGISTRATION` | non | `true` (défaut) : tout le monde peut créer une entreprise. `false` : fermé |
| `SESSION_HOURS` | non | durée de connexion, 12 par défaut |
| `SUBSCRIPTION_PRICE` | non | 7500 |
| `SUBSCRIPTION_PHONE` | non | +269 386 16 39 |
| `TZ_OFFSET_MINUTES` | non | 180 (Comores) |
| `FORCE_HTTPS` | non | `true` (défaut) : redirection vers HTTPS. `false` seulement en cas de boucle de redirection |
| `PORT` | non | laissez Hostinger le gérer ; n'indiquez rien si vous n'êtes pas sûr |

> Si `JWT_SECRET` est absent ou trop court en production, l'application **refuse de démarrer** (volontaire). Si vous changez `JWT_SECRET`, tout le monde est déconnecté.

## 4. Démarrer et vérifier

1. Cliquez sur **Déployer** (ou **Redémarrer**).
2. Consultez les journaux : vous devez voir `Base de données prête (20 tables vérifiées)` puis `ManaGestion démarré`.
3. Ouvrez `https://votre-domaine/api/health` : la réponse doit être `{"ok":true}`.
4. Ouvrez `https://votre-domaine/` : l'écran de connexion s'affiche.

## 5. Premiers pas

1. **Espace propriétaire** : dans le formulaire de connexion, saisissez `OWNER_LOGIN` et `OWNER_PIN` (le code entreprise est ignoré). Allez dans **Mon accès** et changez immédiatement le mot de passe.
2. **Première entreprise** (test) : onglet « Nouvelle entreprise ». Le code de connexion est généré à partir du nom et affiché à la fin.
3. Faites une vente de test complète (produit, stock, vente, facture, avoir). Voir la liste de contrôle ci-dessous.
4. Remplissez `public/cgu.html` et `public/confidentialite.html` (éléments entre crochets) **avant** d'ouvrir à des clients, puis redéployez.

## 6. Liste de contrôle avant ouverture aux clients

- [ ] `/api/health` répond `{"ok":true}` et le site s'ouvre en HTTPS (le cadenas s'affiche)
- [ ] Mot de passe propriétaire changé dans « Mon accès »
- [ ] Création d'une entreprise, d'un emplacement, d'un gérant et d'un employé
- [ ] Vente, facture, avoir, crédit client et paiement testés
- [ ] Réception de stock, transfert, inventaire, bon de commande testés
- [ ] Abonnement : « Non payé » visible à partir du 30/31, bouton « Payer » fonctionnel
- [ ] Sauvegarde téléchargée (Profil > sauvegarde) et sauvegarde de la base exportée (phpMyAdmin)
- [ ] CGU et politique de confidentialité remplies et relues
- [ ] `ALLOW_REGISTRATION=false` si vous voulez créer vous-même les entreprises
- [ ] Installation de l'application (PWA) testée sur un téléphone

## 7. Mettre à jour une version déjà en ligne

1. **Sauvegardez la base** (phpMyAdmin > Exporter) et téléchargez une sauvegarde JSON par entreprise importante.
2. Envoyez la nouvelle version (zip ou Git), en **gardant vos variables d'environnement**.
3. Redémarrez. Les nouvelles tables et colonnes sont ajoutées automatiquement, sans perte de données.
4. Videz le cache du navigateur si l'ancienne interface persiste (le service worker se met à jour à chaque nouvelle valeur de `V` dans `public/sw.js`).

## 8. Domaine, HTTPS et PWA

- Activez le certificat SSL gratuit dans hPanel et, si proposé, **« Forcer HTTPS »**. L'application redirige aussi elle-même vers HTTPS en production.
- L'installation sur téléphone (« Ajouter à l'écran d'accueil ») n'est possible qu'en HTTPS.

## 9. Test en local (facultatif)

```
cp .env.example .env     # renseignez la base locale et JWT_SECRET ; NODE_ENV=development
npm install
npm start                # http://localhost:3000
```

En développement, le cookie de session fonctionne en HTTP. En `NODE_ENV=production`, l'application exige HTTPS.
