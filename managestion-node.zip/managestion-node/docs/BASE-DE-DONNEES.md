# Base de données

MySQL / MariaDB, `utf8mb4`, moteur InnoDB. La structure est dans `database/schema.sql` ; elle est appliquée automatiquement à chaque démarrage (`CREATE TABLE IF NOT EXISTS`) et `src/migrate.js` ajoute les colonnes manquantes d'anciennes versions. Les dates sont des horodatages en millisecondes (colonnes `t` et `created_at`).

`npm run migrate` crée ou vérifie les tables sans lancer le serveur.

| Table | Contenu |
|---|---|
| `companies` | Entreprises clientes : code de connexion (`slug`, unique), nom, coordonnées, devise, TVA, logo, statut `blocked`, compteurs d'avoirs et de bons de commande |
| `locations` | Magasins et entrepôts (code, compteur de factures, archivé) |
| `users` | Utilisateurs : identifiant, mot de passe haché (bcrypt), rôle (`admin`, `gérant`, `employé`), emplacement, désactivé |
| `products` | Produits : code-barres, prix d'achat/vente, seuil, promotion |
| `suppliers` | Fournisseurs |
| `stock_moves` | **Journal des mouvements de stock** : le stock = somme des mouvements par produit et emplacement |
| `customers` | Clients |
| `sales`, `sale_lines` | Ventes (facture, mode de paiement, remise, total) et leurs lignes |
| `payments` | Paiements de ventes à crédit |
| `credit_notes` | Avoirs (annulations), une par vente |
| `cash_entries` | Mouvements de caisse manuels |
| `activity_log` | Journal d'activité |
| `owner_account` | Accès propriétaire modifié depuis l'application |
| `stock_counts`, `stock_count_lines` | Inventaires physiques |
| `purchase_orders`, `purchase_order_lines` | Bons de commande fournisseurs |
| `supplier_payments` | Paiements aux fournisseurs |
| `subscription_payments` | Paiements d'abonnement : une ligne par entreprise et par mois (`period` = AAAA-MM, unique) |

## Principes

- Une entreprise = ses données séparées par `company_id` ; toutes les requêtes filtrent sur l'entreprise de l'utilisateur.
- Les ventes, annulations et réceptions s'exécutent en **transaction** avec verrou de ligne : pas de vente en double ni de stock négatif, numérotation sans trou.
- Aucune donnée n'est supprimée à la légère : produits, clients et emplacements sont « archivés ».
- Le mot de passe d'un utilisateur n'est jamais stocké en clair.

## Sauvegarde et restauration

Voir `ADMINISTRATION.md`. Faites toujours une sauvegarde complète avant une mise à jour.
