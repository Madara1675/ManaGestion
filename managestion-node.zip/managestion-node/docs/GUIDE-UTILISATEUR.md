# Guide utilisateur

## Se connecter

Écran de connexion : **code entreprise**, **identifiant**, **mot de passe**. Le code est donné à la création de l'entreprise et reste visible dans **Profil** (administrateur). L'application s'installe comme une application sur téléphone (menu du navigateur > « Ajouter à l'écran d'accueil »). Une connexion internet est nécessaire.

## Rôles

| Rôle | Peut faire |
|---|---|
| **Administrateur** | Tout : tous les emplacements, produits et prix, équipe, rapports, trésorerie, inventaire, achats, journal, sauvegarde, paramètres de l'entreprise |
| **Gérant** (d'un emplacement) | Son emplacement : tableau de bord, stock (réception, transfert), promotions, caisse, crédits, historique des ventes, clients ; il peut autoriser l'annulation d'une vente |
| **Employé** | Tableau de bord, caisse, crédits, clients, profil |

Chaque emplacement (magasin ou entrepôt) a son propre stock. Un gérant et un employé sont créés avec chaque nouvel emplacement.

## Créer son entreprise

« Nouvelle entreprise » : nom, adresse, email, logo (facultatif), puis le compte administrateur (nom, identifiant, mot de passe de 6 caractères minimum). Le **code entreprise** est affiché à la fin : donnez-le à vos employés. Complétez ensuite **Profil** (téléphone, TVA, devise, pied de facture, coordonnées bancaires, NIF).

## Au quotidien

- **Stock** : ajouter des produits (nom, code-barres, prix d'achat et de vente, seuil d'alerte). **Réception** d'une quantité reçue ; **transfert** entre emplacements. Les stocks sous le seuil apparaissent en alerte sur le tableau de bord. L'administrateur peut **importer** des produits depuis un fichier CSV (modèle à télécharger ; un code-barres déjà connu met à jour le produit sans toucher au stock).
- **Promotions** : pourcentage (1 à 99 %) avec dates de début et de fin facultatives ; le prix réduit est calculé par le serveur.
- **Caisse** : ajouter au panier, choisir un client enregistré ou saisir un nom, appliquer une **remise** (montant), choisir le mode de paiement (Espèces, MVola, Holo, Banque, Crédit), valider. La **facture** (FAC-XXX-0001, numérotation par emplacement) s'affiche : impression, PDF, ticket 80 mm.
- **Crédits** : une vente « Crédit » demande un client. Les paiements partiels se saisissent dans l'onglet Crédits ; le reste dû diminue.
- **Annuler une vente** : crée un **avoir** (AVR-0001…), remet le stock et rembourse ce qui a été payé. Il faut l'identifiant et le mot de passe du **gérant de l'emplacement** (ou d'un administrateur). Une vente ne peut être annulée qu'une fois.
- **Clients** : fiche (nom, téléphone, adresse, note), historique d'achats, crédit dû.

## Administrateur

- **Rapports** : rapport du mois (chiffre d’affaires remises déduites, stock valorisé à l’achat et à la vente, meilleurs produits) et exports CSV (produits, ventes, crédits).
- **Trésorerie** : encaissements (ventes, paiements de crédits), sorties (achats de stock, paiements fournisseurs), mouvements de caisse manuels.
- **Inventaire physique** : saisir les quantités comptées pour un emplacement ; chaque écart corrige le stock, est tracé et valorisé au prix d'achat.
- **Achats** : bons de commande fournisseurs (BC-0001…), réception totale ou partielle (augmente le stock de l'emplacement de livraison), dettes fournisseurs, paiements. La sortie d'argent est comptée au paiement du fournisseur. La « Réception » simple de l'onglet Stock compte, elle, la sortie d'argent tout de suite.
- **Emplacements** : créer, modifier, archiver (impossible s'il reste du stock ou des utilisateurs actifs ; il doit rester un emplacement actif).
- **Équipe** : créer des comptes, changer rôle et emplacement, désactiver, réinitialiser un mot de passe.
- **Journal** : qui a fait quoi, et quand.
- **Profil** > sauvegarde JSON : à faire régulièrement.

## Abonnement

7 500 KMF par mois, payable par envoi au **+269 386 16 39**. À partir du 30 du mois, un bandeau rappelle l'abonnement du mois suivant. Après réception du paiement, il est marqué « Payé » dans l'espace propriétaire.

## Conseils

- Mot de passe de 8 caractères ou plus, différent pour chaque personne ; ne le partagez pas.
- Déconnectez-vous sur un appareil partagé.
- Faites une sauvegarde chaque semaine.
- Les quantités sont des nombres entiers.
