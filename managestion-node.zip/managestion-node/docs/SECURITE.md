# Sécurité

## Ce qui est en place

| Domaine | Mesure |
|---|---|
| Mots de passe | Hachés avec **bcrypt** (jamais stockés en clair, illisibles même pour le propriétaire). Minimum **6 caractères** à la création et à chaque changement |
| Connexion | Limite de **15 échecs par 15 minutes et par adresse IP** ; comparaison à temps constant même si l'identifiant n'existe pas (on ne révèle pas quels comptes existent) ; message d'erreur unique |
| Session | Jeton **JWT HS256** dans un cookie `HttpOnly` (illisible par JavaScript), `SameSite=Lax`, `Secure` en HTTPS ; durée `SESSION_HOURS` (12 h) |
| Contrôle à chaque requête | Le compte est relu en base : un utilisateur désactivé ou une entreprise bloquée est refusé **immédiatement** |
| CSRF | Toute requête qui modifie des données doit porter l'en-tête `X-Requested-With: managestion` (un site tiers ne peut pas l'envoyer) + cookie `SameSite` |
| HTTPS | Redirection automatique vers HTTPS en production ; **HSTS** (1 an) |
| En-têtes | Content-Security-Policy stricte (scripts du site uniquement), `X-Frame-Options`/`frame-ancestors none`, `no-referrer`, `Permissions-Policy`, `X-Powered-By` retiré |
| API | `Cache-Control: no-store` (pas de données privées en cache), plafond de 600 requêtes/minute/IP, limite d'inscription (10/heure/IP), limite d'annulation de vente |
| Injection SQL | Requêtes **paramétrées** uniquement ; recherches `LIKE` échappées |
| XSS | Tout texte affiché est échappé ; pas de script en ligne (CSP) |
| Isolation | Chaque entreprise ne voit que ses données ; chaque employé ne voit que son emplacement ; contrôles de rôle sur le serveur (jamais seulement dans l'interface) |
| Prix et stock | Les prix sont relus en base à la vente ; le stock est verrouillé (pas de vente en double) |
| Annulation de vente | Exige l'identifiant et le mot de passe du **gérant de l'emplacement** ou d'un administrateur |
| Secrets | Variables d'environnement uniquement ; l'application refuse de démarrer en production sans `JWT_SECRET` d'au moins 32 caractères |
| Journal | Connexions, ventes, avoirs, réinitialisations de PIN, paiements d'abonnement sont tracés |

## Ce que vous devez faire

1. **Changer le mot de passe propriétaire** dès la première connexion (« Mon accès »), avec un mot de passe long et unique.
2. **Garder `.env` et `JWT_SECRET` secrets** : jamais dans un zip envoyé, une capture d'écran, un message ou GitHub.
3. **Mot de passe de la base** long et propre à cette base.
4. **Activer l'authentification à deux facteurs** sur votre compte Hostinger (la prise de contrôle de ce compte donnerait accès à tout).
5. **Sauvegardes régulières** (voir `ADMINISTRATION.md`) et test de restauration au moins une fois.
6. **Mises à jour** : lancez `npm audit` sur votre ordinateur de temps en temps et mettez à jour les dépendances ; surveillez les versions de Node.js.
7. Demandez à vos clients des mots de passe de 8 caractères ou plus pour les administrateurs.
8. Faites relire les CGU et la politique de confidentialité (données personnelles de vos clients et de leurs clients).

## Limites connues (à connaître)

- **Pas de double authentification** pour les utilisateurs de l'application.
- **Les sessions ne sont pas révoquées** quand un mot de passe est changé : un ancien cookie reste valable jusqu'à son expiration (12 h par défaut). Pour forcer la déconnexion de tout le monde : changez `JWT_SECRET` et redémarrez. Pour une personne seule : désactivez son compte (effet immédiat).
- Le plafond de tentatives est **par adresse IP**, pas par compte : un attaquant qui change d'adresse peut insister. Utilisez des mots de passe longs.
- L'application n'a pas fait l'objet d'un audit de sécurité indépendant ni de tests d'intrusion. Pour un usage à grande échelle ou des données sensibles, faites-en réaliser un.
- Le fichier de sauvegarde JSON contient toutes les données de l'entreprise (mais pas les mots de passe) : conservez-le comme un document confidentiel.

## En cas d'incident

1. Changez `JWT_SECRET` et redémarrez (déconnecte tout le monde).
2. Changez le mot de passe de la base (hPanel) **et** `DB_PASSWORD`.
3. Changez le mot de passe propriétaire (variables `OWNER_*` ou « Mon accès »).
4. Réinitialisez les mots de passe des comptes concernés (espace propriétaire > Réinitialiser le PIN).
5. Bloquez l'entreprise concernée le temps de l'analyse (bouton « Bloquer »).
6. Consultez le journal d'activité de l'entreprise et les journaux Node.js de hPanel.
7. Si des données personnelles ont fuité, prévenez les personnes concernées comme l'exige la loi applicable.

## Signaler une faille

Ne publiez pas la faille. Écrivez au propriétaire de l'application avec les étapes pour la reproduire.
