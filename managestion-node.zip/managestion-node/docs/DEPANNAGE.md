# Dépannage

| Symptôme | Cause probable | Solution |
|---|---|---|
| L'application ne démarre pas, journal : « JWT_SECRET est obligatoire / trop court » | Variable absente ou de moins de 32 caractères | Ajoutez `JWT_SECRET` (chaîne aléatoire de 32 caractères ou plus) |
| « Impossible de se connecter à la base de données » | `DB_*` incorrect, base ou utilisateur non créé, utilisateur non associé à la base | Vérifiez les 3 valeurs préfixées (`u123..._...`) ; dans hPanel, l'utilisateur doit avoir tous les droits sur la base ; hôte `localhost` |
| Page blanche ou erreur 503 | Application arrêtée ou mauvais fichier d'entrée | Fichier d'entrée `server.js`, Node.js 18+, redémarrez, lisez les journaux |
| `Cannot find module 'express'` | Dépendances non installées | Lancez `npm install --omit=dev` dans hPanel (ou « Réinstaller ») |
| On ne reste pas connecté, ou la connexion « ne fait rien » | Site ouvert en HTTP (le cookie sécurisé est refusé) ; cookies bloqués | Utilisez `https://` ; activez le SSL ; autorisez les cookies |
| Le site « tourne en boucle » (trop de redirections) en production | L'hébergeur ne transmet pas le protocole HTTPS à l'application | Mettez `FORCE_HTTPS=false`, activez « Forcer HTTPS » dans hPanel, et signalez-le (le cookie de session exige aussi que le protocole soit transmis) |
| En local, redirection vers HTTPS impossible | `NODE_ENV=production` en local | Utilisez `NODE_ENV=development` pour tester en HTTP |
| « Entreprise, identifiant ou mot de passe incorrect » | Code entreprise erroné | Le code est dans Profil (administrateur) ; il ne contient que des minuscules, chiffres et tirets |
| « Trop de tentatives » (429) | Limite de connexion atteinte | Attendez 15 minutes |
| « Compte bloqué. Contactez ManaGestion » | L'entreprise a été bloquée par le propriétaire | Le propriétaire la débloque (espace propriétaire) ; souvent lié à l'abonnement |
| Espace propriétaire inaccessible | `OWNER_*` vides, ou accès déjà modifié dans l'application | Voir `ADMINISTRATION.md` (« Mot de passe propriétaire perdu ») |
| L'ancienne interface s'affiche après une mise à jour | Cache du service worker | Rechargez en force (Ctrl+Maj+R) ou fermez et rouvrez l'application installée ; vérifiez que `V` a changé dans `public/sw.js` |
| « Stock insuffisant » à la caisse | Le stock de cet emplacement est insuffisant | Faites une réception ou un transfert vers l'emplacement |
| Import CSV : caractères accentués abîmés | Fichier non UTF-8 | Réenregistrez en « CSV UTF-8 » depuis Excel (l'application essaie aussi Windows-1252) |
| Erreur 413 | Données trop volumineuses (logo, requête) | Utilisez un logo de moins de 500 Ko |
| Le jour de l'abonnement semble décalé | Fuseau horaire | Réglez `TZ_OFFSET_MINUTES` (180 pour les Comores) |

## Collecter les informations pour de l'aide

1. L'URL `/api/health` : réponse ?
2. Les 30 dernières lignes des journaux Node.js (hPanel). Retirez tout mot de passe avant de les partager.
3. La version de Node.js et ce que vous avez fait juste avant l'erreur.
