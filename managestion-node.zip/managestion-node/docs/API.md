# Référence de l'API

Toutes les routes sont sous `/api`. Réponses et erreurs en JSON (`{"error":"message"}`). Les requêtes qui **modifient** des données (POST, PUT, DELETE) doivent porter l'en-tête `X-Requested-With: managestion`. L'authentification se fait par un cookie `mg_token` (HttpOnly) obtenu à la connexion.

Accès : **Public** = sans connexion ; **Tous** = utilisateur connecté ; **Gérant+** = gérant ou administrateur ; **Admin** = administrateur ; **Propriétaire** = session propriétaire.

Limites : 600 requêtes/minute/IP (général), 15 échecs/15 min (connexion), 10 créations/heure (inscription), 10 échecs/15 min (annulation de vente). Codes : 400 requête invalide, 401 non connecté, 403 interdit, 404 introuvable, 409 doublon, 413 trop volumineux, 429 trop de requêtes, 500 erreur serveur.

## Authentification
| Méthode | Route | Accès | Rôle |
|---|---|---|---|
| GET | `/health` | Public | Vérifie que le serveur et la base répondent |
| POST | `/auth/login` | Public | `{slug, login, pin}` ; si identifiant/mot de passe propriétaire : session propriétaire |
| POST | `/auth/register` | Public | Crée une entreprise `{company:{name,addr,email1,logo}, admin:{name,login,pin}}` ; le code `slug` est généré |
| POST | `/auth/logout` | Public | Ferme la session |
| GET | `/auth/session` | Public | Données de la session en cours (401 si absente) |

## Espace propriétaire
| Méthode | Route | Accès | Rôle |
|---|---|---|---|
| GET | `/owner/companies` | Propriétaire | Entreprises, utilisateurs, emplacements, abonnement |
| POST | `/owner/companies/:id/block` | Propriétaire | `{blocked}` bloque/débloque |
| POST | `/owner/companies/:id/pay` | Propriétaire | Marque l'abonnement de la période due comme payé |
| POST | `/owner/users/:id/reset-pin` | Propriétaire | `{pin}` nouveau mot de passe d'un utilisateur |
| GET / PUT | `/owner/account` | Propriétaire | Lit / change l'identifiant et le mot de passe propriétaire |


## Entreprise, emplacements, équipe, fournisseurs, journal
| Méthode | Route | Accès |
|---|---|---|
| GET | `/company` | Tous |
| PUT | `/company` | Admin |
| PUT | `/me` | Tous (nom et mot de passe de l'utilisateur) |
| GET | `/locations` | Tous |
| POST | `/locations` | Admin (crée l'emplacement avec son gérant et son employé) |
| PUT | `/locations/:id` | Admin |
| POST | `/locations/:id/archive` | Admin (bascule archivé / actif) |
| GET, POST | `/users` | Admin |
| PUT | `/users/:id` | Admin |
| GET | `/suppliers` | Tous |
| POST | `/suppliers` | Admin |
| GET | `/log` | Admin |

## Produits et stock
| Méthode | Route | Accès |
|---|---|---|
| GET | `/products` | Tous |
| POST | `/products` | Admin |
| PUT, DELETE | `/products/:id` | Admin |
| POST | `/products/import` | Admin (import CSV) |
| POST, DELETE | `/promotions` | Gérant+ |
| DELETE | `/promotions/:id` | Gérant+ |
| POST | `/stock/receive` | Gérant+ |
| POST | `/stock/transfer` | Gérant+ |

## Ventes, avoirs, crédits
| Méthode | Route | Accès |
|---|---|---|
| POST | `/sales` | Tous (les prix viennent de la base) |
| GET | `/sales` | Gérant+ |
| GET | `/sales/:id` | Tous (limité à son emplacement) |
| POST | `/sales/:id/credit-note` | Tous + identifiant et mot de passe du gérant de l'emplacement ou d'un admin |
| GET | `/credit-notes` | Gérant+ |
| GET | `/credits` | Tous |
| POST | `/credits/:saleId/pay` | Tous |

## Clients
| Méthode | Route | Accès |
|---|---|---|
| GET, POST | `/customers` | Tous |
| GET | `/customers/:id` | Tous |
| PUT, DELETE | `/customers/:id` | Admin |

## Inventaire, achats
| Méthode | Route | Accès |
|---|---|---|
| GET, POST | `/inventory` | Admin |
| GET | `/inventory/:id` | Admin |
| GET | `/purchase-orders`, `/purchase-orders/:id` | Tous |
| POST | `/purchase-orders` | Admin |
| POST | `/purchase-orders/:id/receive` | Gérant+ |
| POST | `/purchase-orders/:id/cancel` | Admin |
| GET | `/suppliers/balances` | Admin |
| POST | `/suppliers/:id/payments` | Admin |

## Tableau de bord, finance, exports
| Méthode | Route | Accès |
|---|---|---|
| GET | `/dashboard` | Tous |
| GET, POST | `/cash` | Admin |
| GET | `/reports` | Admin |
| GET | `/export/:kind.csv` | Admin (`products`, `sales`, `credits`) |
| GET | `/backup` | Admin (sauvegarde JSON de l'entreprise) |

Les paramètres `loc` (identifiant d'emplacement ou `all`) et les dates s'utilisent en query string ; un gérant ou un employé est toujours limité à son emplacement, quel que soit `loc`.
