# Administration de la plateforme (propriétaire)

Ce guide est pour **vous**, le propriétaire de ManaGestion : vous hébergez l'application et vous avez des entreprises clientes.

## Accéder à l'espace propriétaire

Il n'y a pas de bouton dédié. Sur l'écran de connexion, saisissez votre identifiant et votre mot de passe propriétaire (le champ « code entreprise » est ignoré). Les valeurs de départ viennent de `OWNER_LOGIN` et `OWNER_PIN`.

- **Mon accès** : changer votre identifiant et votre mot de passe (6 caractères minimum). Une fois changés ici, ils remplacent les variables d'environnement.
- Si vous laissez `OWNER_LOGIN`/`OWNER_PIN` vides et qu'aucun accès n'a été enregistré, l'espace propriétaire est **désactivé**.
- Mot de passe propriétaire perdu : remettez `OWNER_LOGIN` et `OWNER_PIN` ne suffit pas si un accès est déjà enregistré en base. Dans phpMyAdmin, videz la table `owner_account` (supprimez sa ligne), puis redémarrez : les variables d'environnement s'appliquent de nouveau.

## Ce que vous voyez

Une ligne par entreprise : nom et code, utilisateurs (nom, identifiant, rôle), téléphone et email, emplacements, statut (Active/Bloquée), abonnement. La recherche accepte un nom, un code ou un numéro de téléphone.

## Actions

| Action | Effet |
|---|---|
| **Bloquer / Débloquer** | Une entreprise bloquée ne peut plus se connecter (effet immédiat) ; ses données sont conservées |
| **Réinitialiser le PIN** | Vous définissez un nouveau mot de passe pour un utilisateur (6 caractères minimum) et vous le transmettez à la personne. Les mots de passe existants sont illisibles pour tout le monde |
| **Payer** | Enregistre le paiement de l'abonnement de la période due |

## Abonnement

- Prix : **7 500 KMF par mois** (`SUBSCRIPTION_PRICE`). Numéro d'envoi affiché aux clients : **+269 386 16 39** (`SUBSCRIPTION_PHONE`).
- Règle : **à partir du 30** du mois (ou du dernier jour en février : 28 ou 29), l'abonnement du **mois suivant** est dû. Les entreprises qui n'ont pas payé affichent **« Non payé »** avec un bouton **« Payer »**.
- Quand vous recevez un paiement, cliquez sur **Payer** et confirmez : le statut devient **« Payé »** pour cette période. Le paiement est enregistré (montant, date) et tracé dans le journal de l'entreprise.
- Avant le 30, une entreprise sans paiement enregistré s'affiche « À jour ».
- Le jour du mois est calculé à l'heure des Comores (`TZ_OFFSET_MINUTES=180`).
- Le statut est **informatif** : il ne bloque pas l'accès. Si un client ne paie pas, utilisez **Bloquer**.
- Les administrateurs des entreprises voient un bandeau « Abonnement à payer » avec le montant et le numéro.
- Un paiement ne peut pas être enregistré deux fois pour la même période.

## Créer des entreprises

- `ALLOW_REGISTRATION=true` : n'importe qui crée son entreprise depuis l'écran de connexion (limité à 10 créations par heure et par adresse IP).
- `ALLOW_REGISTRATION=false` : l'inscription publique est fermée. Pour créer vous-même une entreprise, remettez temporairement `true`, créez-la, puis refermez.
- Le code de connexion est généré à partir du nom (ex. « Épicerie Mâ » donne `epicerie-ma`, ou `epicerie-ma-4821` s'il existe déjà). L'entreprise le retrouve dans Profil.

## Sauvegardes

| Quoi | Comment | Fréquence conseillée |
|---|---|---|
| **Toute la base** | phpMyAdmin > votre base > Exporter (SQL) ; ou sauvegardes automatiques Hostinger | chaque semaine, et avant chaque mise à jour |
| **Une entreprise** | Profil > « Télécharger une sauvegarde » (JSON, administrateur de l'entreprise) | à la demande |
| **Votre code et `.env`** | copie sur votre ordinateur, hors ligne | à chaque changement |

**Restaurer** : phpMyAdmin > Importer le fichier SQL. Testez une restauration sur une base vide avant d'en avoir besoin. Le JSON d'une entreprise sert à consulter ou archiver ; il n'est pas réimporté automatiquement.

## Surveillance et maintenance

- Journaux : hPanel > Node.js > Journaux. Cherchez les lignes `Erreur`, `Exception non gérée`, `Impossible de se connecter à la base`.
- Santé : `https://votre-domaine/api/health` doit répondre `{"ok":true}` (utile pour une sonde de supervision gratuite, type UptimeRobot).
- Espace disque et taille de la base : surveillez dans hPanel. Les logos sont stockés en base (500 Ko maximum chacun).
- Journal d'activité : chaque entreprise peut le consulter (administrateur > Journal).
- Mettez à jour Node.js et les dépendances régulièrement (voir `SECURITE.md`).

## Données personnelles et obligations

Vous traitez des données (clients, ventes, fournisseurs) pour le compte de vos clients. Remplissez et faites relire `public/cgu.html` et `public/confidentialite.html` (hébergeur Hostinger, pays du serveur, durée de conservation, contact). Prévoyez une procédure pour supprimer les données d'une entreprise qui part (après export, suppression de la ligne de l’entreprise dans la table `companies` via phpMyAdmin ; vérifiez ensuite qu’il ne reste aucune donnée liée).
