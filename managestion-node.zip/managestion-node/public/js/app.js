'use strict';
/* ManaGestion : interface web. Toutes les données sont lues et écrites via l'API du serveur (/api). */

const LOGO = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#14b8a6"/><stop offset="1" stop-color="#0f766e"/></linearGradient></defs><rect width="512" height="512" rx="112" fill="url(#g)"/><path d="M112 392V144H178L256 262L334 144H400V392H338V248L282 330H230L174 248V392Z" fill="#fff"/><circle cx="392" cy="104" r="24" fill="#fbbf24"/></svg>');

const $ = (s) => document.querySelector(s);
const v = (i) => { const e = document.getElementById(i); return e ? e.value : ''; };
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ---------- État ---------- */
const ST = { me: null, co: null, locs: [], owner: false };
let tab = 'dash', vl = 'all', cart = [], cm = '', ent = 'login', ip = null, view = 0;
let PR = [], USERS = [], OWN = [], logo = '', CLI = '', MODE = 'Espèces', hT = null;
let CUSTS = [], CID = '', DISC = 0, IMP = [], PO = [], POSUP = '';

/* ---------- Réseau ---------- */
async function api(method, url, body) {
  let r;
  try {
    r = await fetch('/api' + url, {
      method,
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'managestion' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch (e) {
    throw new Error('Connexion au serveur impossible. Vérifiez votre accès internet.');
  }
  let d = null;
  try { d = await r.json(); } catch (e) { /* réponse vide */ }
  if (!r.ok) {
    if (r.status === 401 && (ST.me || ST.owner)) { ST.me = null; ST.owner = false; cart = []; render(); }
    throw new Error((d && d.error) || 'Erreur du serveur (' + r.status + ')');
  }
  return d;
}
const qs = (o) => {
  const p = Object.entries(o).filter(([, x]) => x !== undefined && x !== null && x !== '').map(([k, x]) => k + '=' + encodeURIComponent(x));
  return p.length ? '?' + p.join('&') : '';
};
async function download(url, name) {
  const r = await fetch(url, { credentials: 'same-origin' });
  if (!r.ok) {
    let d = null;
    try { d = await r.json(); } catch (e) { /* ignore */ }
    throw new Error((d && d.error) || 'Téléchargement impossible');
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(await r.blob());
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

/* ---------- Utilitaires ---------- */
const isA = () => !!ST.me && ST.me.role === 'admin';
const AL = () => ST.locs.filter((l) => !l.archived);
const LN = (id) => (ST.locs.find((l) => l.id === +id) || { name: '—' }).name;
const CUR = () => (isA() ? vl : String(ST.me.location_id));
const locP = () => (isA() ? { loc: vl } : {});
const fm = (n) => Math.round(n || 0).toLocaleString('fr-FR') + ' ' + esc((ST.co && ST.co.cur) || 'KMF');
const dt = (t) => new Date(t).toLocaleDateString('fr-FR');
const ym = (t) => { const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); };
const monthRange = (m) => { const [y, mo] = m.split('-').map(Number); return { from: new Date(y, mo - 1, 1).getTime(), to: new Date(y, mo, 1).getTime() }; };
const remember = (slug) => { try { localStorage.setItem('mg_slug', slug); } catch (e) { /* stockage indisponible */ } };

function toast(m, err) {
  const t = $('#mgtoast');
  t.textContent = m;
  t.className = err ? 'err' : '';
  t.style.display = 'block';
  clearTimeout(toast.h);
  toast.h = setTimeout(() => { t.style.display = 'none'; }, err ? 5000 : 3500);
}
const openMo = (html) => { $('#mo').innerHTML = html; };
const closeMo = () => { $('#mo').innerHTML = ''; };
const one = () => {
  if (isA() && vl === 'all') { toast('Choisissez un magasin ou un entrepôt en haut de l\'écran', true); return false; }
  return true;
};
const optLocs = (sel) => AL().map((l) => `<option value="${l.id}" ${String(sel) === String(l.id) ? 'selected' : ''}>${esc(l.name)}</option>`).join('');

/* Promotions : gérées par l'administrateur et les vendeurs ; le prix réduit est calculé par le serveur (salePrice). */
const canPromo = () => !!ST.me && (ST.me.role === 'admin' || ST.me.role === 'gérant');
/* Rôles : l'administrateur voit tout ; le gérant gère son emplacement (stock, promotions, ventes) ; l'employé encaisse. */
const isM = () => !!ST.me && ST.me.role === 'gérant';
const canHist = () => isA() || isM();
const pxH = (p) => (p.promoActive ? `<s class="mu">${fm(p.price)}</s> <b>${fm(p.salePrice)}</b> <span class="bdg pro">−${p.promoPct} %</span>` : fm(p.price));
const mkLine = (p, q) => ({ id: p.id, name: p.name, price: p.salePrice, orig: p.price, pct: p.promoActive ? p.promoPct : 0, q });
const lq = (l) => `${l.q} × ${l.pct ? `<s class="mu">${fm(l.orig)}</s> ` : ''}${fm(l.price)}${l.pct ? ` <span class="bdg pro">−${l.pct} %</span>` : ''}`;
const lqi = (l) => `${l.qty} × ${l.promoPct > 0 ? `<s class="mu">${fm(l.listPrice)}</s> ` : ''}${fm(l.price)}${l.promoPct > 0 ? ` <span class="bdg pro">−${+l.promoPct} %</span>` : ''}`;

function setSession(d) {
  ST.sub = d.sub || null; ST.me = d.user; ST.co = d.company; ST.locs = d.locations; ST.owner = false;
  tab = 'dash'; vl = 'all'; cart = []; CLI = ''; CID = ''; DISC = 0; PO = []; POSUP = ''; MODE = 'Espèces';
}
async function refreshLocs() { ST.locs = await api('GET', '/locations'); }

/* ---------- Écran d'entrée ---------- */
function entryH() {
  return `<div class="c"><div class="hd"><img src="${LOGO}" alt=""><h1 style="margin:0">Mana<span style="color:var(--pr)">Gestion</span></h1></div>
<div class="tabs"><button class="${ent === 'login' ? 'on' : ''}" data-act="ent" data-arg="login">Connexion</button><button class="${ent === 'new' ? 'on' : ''}" data-act="ent" data-arg="new">Nouvelle entreprise</button>${ip ? '<button class="s" data-act="inst">Installer l\'application</button>' : ''}</div></div>
${ent === 'login' ? loginH() : setupH()}
<div class="mu ctr"><a href="/cgu.html">Conditions d'utilisation</a> · <a href="/confidentialite.html">Confidentialité</a></div>`;
}
function loginH() {
  let slug = '';
  try { slug = localStorage.getItem('mg_slug') || ''; } catch (e) { /* ignore */ }
  return `<div class="c"><h2>Connexion</h2><label>Code entreprise</label><input id="ls" autocapitalize="none" autocomplete="organization" value="${esc(slug)}"><label>Identifiant</label><input id="lu" autocapitalize="none" autocomplete="username"><label>Mot de passe</label><input id="lp" type="password" autocomplete="current-password" data-enter="login"><br><br><button data-act="login">Se connecter</button></div>`;
}
function setupH() {
  return `<div class="c"><h2>Créer une entreprise</h2><div class="g"><div><label>Nom de l'entreprise *</label><input id="a1"></div><div><label>Adresse</label><input id="a4"></div><div><label>Email 1 *</label><input id="a6" type="email"></div><div><label>Logo (facultatif)</label><input type="file" accept="image/*" data-ch="logo"></div></div>
<h3 class="mt">Compte administrateur</h3><div class="g"><div><label>Votre nom *</label><input id="b1"></div><div><label>Identifiant de connexion *</label><input id="b0" autocapitalize="none"></div><div><label>Mot de passe (6 caractères min.) *</label><input id="b2" type="password"></div></div><div class="mu">Le code entreprise est créé automatiquement à partir du nom et affiché après la création (il reste visible dans Profil). Vos gérants et employés se connecteront avec ce code, leur identifiant et leur mot de passe.</div><br><button data-act="setup">Créer mon espace</button></div>`;
}

/* ---------- Espace propriétaire ---------- */
const MOIS = (p) => { const [y, m] = String(p).split('-'); return ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'][+m - 1] + ' ' + y; };
function ownList(q) {
  const d = String(q || '').replace(/\D/g, '');
  const s = String(q || '').trim().toLowerCase();
  const L = OWN.filter((c) => !s || (d && (c.gsm || '').replace(/\D/g, '').includes(d)) || c.name.toLowerCase().includes(s) || c.slug.includes(s) || c.users.some((u) => u.name.toLowerCase().includes(s)));
  if (!L.length) return '<span class="mu">Aucun résultat.</span>';
  return `<table><tr><th>Entreprise</th><th>Utilisateurs</th><th>Téléphone / email</th><th>Emplacements</th><th>Statut</th><th>Abonnement</th><th></th></tr>${L.map((c) => `<tr><td><b>${esc(c.name)}</b> <span class="mu">(${esc(c.slug)})</span><br><span class="mu">${esc(c.addr)}</span></td><td>${c.users.map((u) => esc(u.name) + ' <span class="mu">@' + esc(u.login) + ' (' + esc(u.role) + ')</span>' + (u.disabled ? ' <span class="bdg bad">désactivé</span>' : '') + ' <button class="s" data-act="oreset" data-arg="' + u.id + '">Réinitialiser le mot de passe</button>').join('<br>')}</td><td>${esc(c.gsm)}<br><span class="mu">${esc(c.email)}</span></td><td>${c.locations.map(esc).join('<br>') || '—'}</td><td>${c.blocked ? '<span class="bdg bad">Bloquée</span>' : '<span class="bdg">Active</span>'}</td><td>${c.sub.unpaid ? '<span class="bdg bad">Non payé</span> <span class="mu">' + esc(MOIS(c.sub.period)) + '</span><br><button data-act="opay" data-arg="' + c.id + '">Payer</button>' : '<span class="bdg">' + (c.sub.paid ? 'Payé' : 'À jour') + '</span> <span class="mu">' + (c.sub.paid ? esc(MOIS(c.sub.period)) : '') + '</span>'}</td><td><button class="${c.blocked ? '' : 's'}" data-act="oblock" data-arg="${c.id}">${c.blocked ? 'Débloquer' : 'Bloquer'}</button></td></tr>`).join('')}</table>`;
}
function ownH() {
  const L = OWN;
  return `<div class="c"><div class="hd"><h2>Espace propriétaire</h2><div class="sp"></div><button class="s" data-act="oacct">Mon accès</button> <button class="s" data-act="logout">Quitter</button></div><div class="g"><div><div class="mu">Entreprises</div><div class="k">${L.length}</div></div><div><div class="mu">Actives</div><div class="k">${L.filter((c) => !c.blocked).length}</div></div><div><div class="mu">Bloquées</div><div class="k bad">${L.filter((c) => c.blocked).length}</div></div><div><div class="mu">Abonnements non payés</div><div class="k bad">${L.filter((c) => c.sub.unpaid).length}</div></div><div><div class="mu">Magasins / entrepôts</div><div class="k">${L.reduce((a, c) => a + c.locations.length, 0)}</div></div></div></div>
<div class="c"><label>Rechercher par numéro de téléphone, nom ou code</label><input id="os" placeholder="+269 ..." data-in="osearch"></div><div class="c tbl" id="ol">${ownList('')}</div>`;
}

/* ---------- Rendu principal ---------- */
function tabs() {
  // admin : tout ; gérant : tableau de bord, stock, promotions, caisse, ventes, crédits, clients, profil ;
  // employé : tableau de bord, caisse, crédits, clients, profil.
  const T = [['dash', 'Tableau de bord']];
  if (canHist()) T.push(['prod', 'Stock']);
  if (canPromo()) T.push(['promo', 'Promotions']);
  T.push(['sale', 'Caisse']);
  if (canHist()) T.push(['hist', 'Ventes']);
  T.push(['cred', 'Crédits'], ['cust', 'Clients']);
  if (isA()) T.push(['rap', 'Rapports'], ['cash', 'Trésorerie'], ['inv', 'Inventaire'], ['buy', 'Achats'], ['loc', 'Emplacements'], ['team', 'Équipe'], ['jr', 'Journal']);
  T.push(['prof', 'Profil']);
  return T;
}
let shellSig = '', lastTab = '';
async function render() {
  const a = $('#app');
  a.className = ST.me || ST.owner ? 'w' : 'w n';
  try {
    if (ST.owner) {
      shellSig = '';
      OWN = await api('GET', '/owner/companies');
      a.innerHTML = ownH();
      return;
    }
    if (!ST.me) { shellSig = ''; a.innerHTML = entryH(); return; }
    const T = tabs();
    if (!T.some((x) => x[0] === tab)) tab = 'dash';
    const co = ST.co, me = ST.me;
    const head = `<div class="c nop hd"><img src="${esc(co.logo || LOGO)}" alt=""><div><h2>${esc(co.name)}</h2><div class="mu">ManaGestion · ${esc(me.name)} (${esc(me.role)})</div></div><div class="sp"></div><span class="bdg" id="net">${navigator.onLine ? 'En ligne' : 'Hors ligne'}</span>${isA() ? `<select class="auto" data-ch="vl"><option value="all" ${vl === 'all' ? 'selected' : ''}>Tous les emplacements</option>${optLocs(vl)}</select>` : `<span class="bdg">${esc(LN(me.location_id))}</span>`}<button data-act="logout">⏻ Déconnexion</button></div>
${ST.sub && ST.sub.unpaid && isA() ? `<div class="al nop">Abonnement de ${esc(MOIS(ST.sub.period))} à payer : ${fm(ST.sub.price)} par mois. Envoyez votre paiement au ${esc(ST.sub.phone)}.</div>` : ''}`;
    const btns = T.map((t) => `<button data-act="go" data-arg="${t[0]}">${t[1]}</button>`).join('');
    let bar = $('#tabs');
    if (head + btns !== shellSig || !bar || !$('#main')) {
      // L'en-tête et la barre d'onglets ne sont reconstruits que s'ils ont changé : la barre garde sa position de défilement.
      const keep = bar ? bar.scrollLeft : 0;
      a.innerHTML = head + `<div class="tabs nop" id="tabs">${btns}</div><div id="main"><div class="c mu">Chargement…</div></div>`;
      shellSig = head + btns;
      bar = $('#tabs');
      bar.scrollLeft = keep;
      lastTab = tab;
    } else if (lastTab !== tab) {
      $('#main').innerHTML = '<div class="c mu">Chargement…</div>';
      lastTab = tab;
    }
    bar.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.arg === tab));
    const my = ++view;
    const html = await V[tab]();
    const m = $('#main');
    if (my === view && m) m.innerHTML = html;
  } catch (e) {
    const m = $('#main');
    if (m) m.innerHTML = '<div class="al">' + esc(e.message) + '</div>';
    else toast(e.message, true);
  }
}

/* ---------- Écrans ---------- */
const V = {
  async dash() {
    const d = await api('GET', '/dashboard' + qs({ ...locP(), since: new Date().setHours(0, 0, 0, 0) }));
    return `<div class="g"><div class="c"><div class="mu">Ventes du jour</div><div class="k">${fm(d.today)}</div></div>${isA() ? `<div class="c"><div class="mu">Valeur du stock</div><div class="k">${fm(d.stockValue)}</div></div>` : ''}<div class="c"><div class="mu">Produits</div><div class="k">${d.products}</div></div><div class="c"><div class="mu">Crédits à recevoir</div><div class="k">${fm(d.creditsDue)}</div></div>${isA() && d.suppliersDue !== undefined ? `<div class="c"><div class="mu">Dettes fournisseurs</div><div class="k">${fm(d.suppliersDue)}</div></div>` : ''}</div>
<div class="c"><h3>Alertes stock bas</h3>${d.low.length ? d.low.map((p) => `<div>${esc(p.name)} : <b class="bad">${p.stock}</b> (seuil ${p.min})</div>`).join('') : '<span class="mu">Aucune alerte.</span>'}</div>`;
  },

  async prod() {
    const ad = isA(), all = CUR() === 'all', ml = AL().length > 1;
    const [list, sup] = await Promise.all([api('GET', '/products' + qs(locP())), api('GET', '/suppliers')]);
    PR = list;
    const popt = PR.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
    return `${ad ? `<div class="c"><h3>Nouveau produit</h3><div class="g"><div><label>Nom</label><input id="pn"></div><div><label>Code-barres</label><input id="pc"></div><div><label>Prix d'achat</label><input id="pb" type="number" min="0"></div><div><label>Prix de vente</label><input id="ps" type="number" min="0"></div><div><label>Stock initial (emplacement choisi, sinon principal)</label><input id="pq" type="number" min="0" value="0"></div><div><label>Seuil d'alerte</label><input id="pm" type="number" min="0" value="5"></div></div><br><button data-act="addProd">Ajouter</button></div>` : ''}
${ad ? importCard() : ''}
<div class="c"><h3>Fournisseurs</h3><div class="g">${ad ? '<div><label>Nom</label><input id="sn"></div><div><label>Téléphone</label><input id="st"></div>' : ''}<div><label>Fournisseur des prochaines réceptions</label><select id="rsup"><option value="">—</option>${sup.map((x) => `<option>${esc(x.name)}</option>`).join('')}</select></div></div>${ad ? '<br><button class="s" data-act="addSup">Ajouter le fournisseur</button>' : ''}</div>
${ml ? `<div class="c"><h3>Transfert de stock</h3><div class="g"><div><label>De</label>${ad ? `<select id="tf">${optLocs(CUR())}</select>` : `<input value="${esc(LN(CUR()))}" disabled>`}</div><div><label>Vers</label><select id="tt">${AL().filter((l) => ad || String(l.id) !== CUR()).map((l) => `<option value="${l.id}">${esc(l.name)}</option>`).join('')}</select></div><div><label>Produit</label><select id="tp">${popt}</select></div><div><label>Quantité</label><input id="tq" type="number" min="1"></div></div><br><button class="s" data-act="transfer">Transférer</button></div>` : ''}
<div class="c tbl"><input placeholder="Rechercher un produit…" data-in="flt" style="margin-bottom:8px"><table><tr><th>Produit</th><th>Code</th>${ad ? '<th>Achat</th>' : ''}<th>Vente</th><th>Stock${all ? ' (total)' : ''}</th>${ad && ST.locs.length > 1 ? '<th>Par emplacement</th>' : ''}<th></th></tr>${PR.map((p) => `<tr class="pr"><td>${esc(p.name)}</td><td>${esc(p.code)}</td>${ad ? `<td>${fm(p.buy)}</td>` : ''}<td>${pxH(p)}</td><td class="${p.stock <= p.min ? 'bad' : ''}"><b>${p.stock}</b></td>${ad && ST.locs.length > 1 ? `<td class="mu">${ST.locs.map((l) => esc(l.name) + ' : ' + ((p.byLoc || {})[l.id] || 0)).join(' · ')}</td>` : ''}<td><input id="r${p.id}" type="number" min="1" placeholder="Qté" class="w80"> <button class="s" data-act="recv" data-arg="${p.id}">Réception</button>${ad ? ` <button class="s" data-act="editP" data-arg="${p.id}">Modifier</button>` : ''}</td></tr>`).join('')}</table></div>`;
  },

  async promo() {
    PR = await api('GET', '/products' + qs(locP()));
    const on = PR.filter((p) => p.promoPct > 0);
    const STT = { active: 'En cours', planned: 'Programmée', ended: 'Terminée' };
    const per = (p) => (p.promoFrom ? 'du ' + dt(p.promoFrom) : 'dès maintenant') + (p.promoTo ? ' au ' + dt(p.promoTo) : ', sans date de fin');
    return `<div class="c"><h3>Nouvelle promotion</h3><div class="mu">Cochez les produits concernés, indiquez le pourcentage de réduction, puis appliquez. Le prix réduit s'affiche à la caisse et sur la facture, avec l'ancien prix barré. Une promotion s'applique à tous les emplacements.</div>
<div class="g"><div><label>Réduction (%)</label><input id="xp" type="number" min="1" max="99" placeholder="ex : 15" data-in="promoPrev"></div><div><label>Début (facultatif)</label><input id="xf" type="date"></div><div><label>Fin (facultatif)</label><input id="xt" type="date"></div></div>
<div class="mu">Sans date, la promotion commence tout de suite et dure jusqu'à son retrait. Une nouvelle promotion remplace l'ancienne sur les produits cochés.</div>
<div class="hd mt"><h3 style="margin:0">Produits concernés</h3><div class="sp"></div><button class="s" data-act="pickAll" data-arg="1">Tout cocher</button><button class="s" data-act="pickAll" data-arg="0">Tout décocher</button></div>
<div class="tbl"><input placeholder="Rechercher un produit…" data-in="flt" style="margin:8px 0"><table><tr><th></th><th>Produit</th><th>Prix normal</th><th>Prix promo</th></tr>${PR.map((p) => `<tr class="pr"><td><input type="checkbox" class="pck" value="${p.id}"></td><td>${esc(p.name)}${p.promoPct > 0 ? ` <span class="bdg pro">−${p.promoPct} %</span>` : ''}</td><td>${fm(p.price)}</td><td><b class="pv" data-p="${p.price}">—</b></td></tr>`).join('')}</table>${PR.length ? '' : '<span class="mu">Ajoutez d\'abord des produits dans l\'onglet Stock.</span>'}</div><br><button data-act="applyPromo">Appliquer la promotion</button></div>
<div class="c tbl"><div class="hd"><h3 style="margin:0">Produits en promotion</h3><div class="sp"></div>${on.length ? '<button class="s" data-act="stopAll">Tout retirer</button>' : ''}</div>${on.length ? `<table><tr><th>Produit</th><th>Prix normal</th><th>Réduction</th><th>Prix promo</th><th>Période</th><th>État</th><th></th></tr>${on.map((p) => `<tr><td>${esc(p.name)}</td><td>${fm(p.price)}</td><td><b>−${p.promoPct} %</b></td><td>${fm(Math.round(p.price * (1 - p.promoPct / 100)))}</td><td class="mu">${per(p)}</td><td><span class="bdg ${p.promoState === 'active' ? 'pro' : ''}">${STT[p.promoState] || ''}</span></td><td><button class="s" data-act="stopPromo" data-arg="${p.id}">Retirer</button></td></tr>`).join('')}</table>` : '<div class="mu mt">Aucune promotion pour le moment.</div>'}</div>`;
  },

  async sale() {
    const [list, custs] = await Promise.all([api('GET', '/products' + qs(locP())), api('GET', '/customers')]);
    PR = list; CUSTS = custs;
    const tot = cart.reduce((a, l) => a + l.q * l.price, 0), net = tot - Math.min(Math.max(0, +DISC || 0), tot);
    const modes = ['Espèces', 'MVola', 'Holo', 'Banque', 'Crédit'];
    return `<div class="c"><h3>Nouvelle vente</h3><div class="g"><div><label>Produit</label><select id="sp">${PR.map((p) => `<option value="${p.id}">${esc(p.name)} (${p.stock}) - ${fm(p.salePrice)}${p.promoActive ? ' · −' + p.promoPct + ' %' : ''}</option>`).join('')}</select></div><div><label>Quantité</label><input id="sq" type="number" value="1" min="1"></div><div><label>Code-barres (douchette)</label><input id="sb" placeholder="Scanner puis Entrée" data-enter="scan"></div></div><br><button data-act="addLine">Ajouter au panier</button></div>
<div class="c tbl"><table>${cart.map((l, i) => `<tr><td>${esc(l.name)}</td><td>${lq(l)}</td><td>${fm(l.q * l.price)}</td><td><button class="s" data-act="delLine" data-arg="${i}">✕</button></td></tr>`).join('')}</table><div class="k" id="tot">Total : ${fm(net)}</div>
<div class="g"><div><label>Client enregistré</label><select id="cs" data-ch="cust"><option value="">— Client comptoir / autre —</option>${CUSTS.map((c) => `<option value="${c.id}" ${String(CID) === String(c.id) ? 'selected' : ''}>${esc(c.name)}${c.phone ? ' · ' + esc(c.phone) : ''}</option>`).join('')}</select></div><div><label>Nom (si non enregistré)</label><input id="cn" placeholder="Client comptoir" value="${esc(CLI)}" data-in="cli"></div><div><label>Remise (montant)</label><input id="dc" type="number" min="0" value="${DISC || ''}" data-in="disc"></div><div><label>Paiement</label><select id="cm" data-ch="mode">${modes.map((m) => `<option ${m === MODE ? 'selected' : ''}>${m}</option>`).join('')}</select></div></div><br><button ${cart.length ? '' : 'disabled'} data-act="doSale">Valider la vente</button></div>`;
  },

  async hist() {
    const [rows, notes] = await Promise.all([api('GET', '/sales' + qs(locP())), api('GET', '/credit-notes' + qs(locP()))]);
    return `<div class="c tbl"><input id="hq" placeholder="Rechercher (facture, client)…" data-in="hsearch" style="margin-bottom:8px"><div id="hl">${histTable(rows)}</div></div><div class="mu">Les factures sont immuables : une annulation passe par un avoir (ouvrez la facture).</div>${notes.length ? `<div class="c tbl"><h3>Avoirs</h3><table>${notes.map((a) => `<tr><td>${esc(a.no)}</td><td>${dt(a.t)}</td><td>${esc(a.sno)}</td><td>${fm(a.total)}</td><td>${esc(a.reason)}</td></tr>`).join('')}</table></div>` : ''}`;
  },

  async cred() {
    const d = await api('GET', '/credits' + qs(locP()));
    return `<div class="c"><h3>Crédits clients</h3><div class="k">${fm(d.due)}</div><div class="mu">à recevoir</div></div><div class="c tbl"><table><tr><th>Facture</th><th>Client</th><th>Total</th><th>Reste</th><th>Encaisser</th></tr>${d.list.map((s) => `<tr><td>${esc(s.no)}</td><td>${esc(s.client)}</td><td>${fm(s.total)}</td><td class="bad">${fm(s.rest)}</td><td><input id="ra${s.id}" type="number" min="1" class="w110" value="${s.rest}"> <button class="s" data-act="repay" data-arg="${s.id}">Encaisser</button></td></tr>`).join('')}</table>${d.list.length ? '' : '<span class="mu">Aucun crédit en cours.</span>'}</div>`;
  },

  async cash() {
    const m = cm || ym(Date.now());
    const d = await api('GET', '/cash' + qs({ ...locP(), ...monthRange(m) }));
    return `<div class="c"><div class="hd"><h3>Trésorerie du mois</h3><input type="month" value="${m}" class="auto" data-ch="month"></div><div class="g"><div><div class="mu">Entrées</div><div class="k">${fm(d.totalIn)}</div></div><div><div class="mu">Sorties</div><div class="k bad">${fm(d.totalOut)}</div></div><div><div class="mu">Solde</div><div class="k">${fm(d.totalIn - d.totalOut)}</div></div></div></div>
<div class="c"><h3>Ajouter une opération</h3><div class="g"><div><label>Libellé</label><input id="el"></div><div><label>Montant</label><input id="ea" type="number" min="0"></div><div><label>Type</label><select id="ek"><option value="out">Sortie (loyer, salaire…)</option><option value="in">Entrée (autre)</option></select></div></div><br><button data-act="addExp">Ajouter</button></div>
<div class="c tbl"><h3>Détail</h3><table><tr><th>Date</th><th>Libellé</th><th>Entrée</th><th>Sortie</th></tr>${d.rows.map((x) => `<tr><td>${dt(x.t)}</td><td>${esc(x.label)}</td><td>${x.kind === 'in' ? fm(x.amount) : ''}</td><td class="bad">${x.kind === 'in' ? '' : fm(x.amount)}</td></tr>`).join('')}<tr><th></th><th>Total</th><th>${fm(d.totalIn)}</th><th>${fm(d.totalOut)}</th></tr></table></div><div class="mu">Entrées = ventes encaissées (hors crédit). Sorties = réceptions de stock au prix d'achat + dépenses saisies.</div>`;
  },

  async rap() {
    const m = cm || ym(Date.now());
    const d = await api('GET', '/reports' + qs({ ...locP(), ...monthRange(m) }));
    return `<div class="c"><div class="hd"><h3>Rapports du mois</h3><input type="month" value="${m}" class="auto" data-ch="month"></div><div class="g"><div><div class="mu">Chiffre d'affaires (remises déduites)</div><div class="k">${fm(d.rev)}</div></div><div><div class="mu">Coût des marchandises</div><div class="k">${fm(d.cost)}</div></div><div><div class="mu">Marge brute</div><div class="k">${fm(d.rev - d.cost)}</div></div></div></div>
<div class="g"><div class="c"><div class="mu">Stock valorisé (achat)</div><div class="k">${fm(d.stockBuy)}</div></div><div class="c"><div class="mu">Stock valorisé (vente)</div><div class="k">${fm(d.stockSell)}</div></div><div class="c"><div class="mu">Crédits à recevoir</div><div class="k">${fm(d.creditsDue)}</div></div></div>
<div class="c tbl"><h3>Meilleurs produits</h3><table>${d.top.map((x) => `<tr><td>${esc(x.name)}</td><td>${x.q} vendus</td><td>${fm(x.a)}</td></tr>`).join('') || '<tr><td class="mu">Aucune vente ce mois</td></tr>'}</table></div>
<div class="c"><h3>Exports Excel (.csv)</h3><button class="s" data-act="expo" data-arg="products">Produits</button> <button class="s" data-act="expo" data-arg="sales">Ventes</button> <button class="s" data-act="expo" data-arg="credits">Crédits</button></div>`;
  },

  async cust() {
    CUSTS = await api('GET', '/customers');
    return `<div class="c"><h3>Nouveau client</h3><div class="g"><div><label>Nom</label><input id="kn"></div><div><label>Téléphone</label><input id="kt"></div><div><label>Adresse</label><input id="ka"></div><div><label>Note</label><input id="kq"></div></div><br><button data-act="addCust">Ajouter</button></div>
<div class="c tbl"><input placeholder="Rechercher un client (nom, téléphone)…" data-in="csearch" style="margin-bottom:8px"><div id="cl">${custTable(CUSTS)}</div></div>`;
  },

  async inv() {
    const hist = await api('GET', '/inventory');
    let body;
    if (vl === 'all') {
      body = '<div class="c">Choisissez un magasin ou un entrepôt en haut de l\'écran pour faire un inventaire.</div>';
    } else {
      PR = await api('GET', '/products' + qs({ loc: vl }));
      body = `<div class="c"><h3>Nouvel inventaire : ${esc(LN(vl))}</h3><div class="mu">Comptez le stock réel et saisissez la quantité trouvée. Laissez vide les produits que vous ne comptez pas. À la validation, chaque écart corrige le stock et reste tracé.</div><br><input placeholder="Rechercher un produit…" data-in="flt" style="margin-bottom:8px"><div class="tbl"><table><tr><th>Produit</th><th>Code</th><th>Stock attendu</th><th>Quantité comptée</th></tr>${PR.map((p) => `<tr class="pr"><td>${esc(p.name)}</td><td>${esc(p.code)}</td><td>${p.stock}</td><td><input id="ic${p.id}" type="number" min="0" placeholder="—" class="w80"></td></tr>`).join('')}</table></div><div class="g"><div><label>Note (facultatif)</label><input id="inote" placeholder="ex : inventaire de fin de mois"></div></div><br><button data-act="invGo">Valider l'inventaire</button></div>`;
    }
    return body + `<div class="c tbl"><h3>Inventaires précédents</h3>${hist.length ? `<table><tr><th>N°</th><th>Date</th><th>Emplacement</th><th>Par</th><th>Produits comptés</th><th>Écarts</th><th>Valeur des écarts</th><th></th></tr>${hist.map((h) => `<tr><td>#${h.id}</td><td>${dt(h.t)}</td><td>${esc(h.locName)}</td><td>${esc(h.by)}</td><td>${h.nlines}</td><td>${h.diffs}</td><td class="${h.value < 0 ? 'bad' : ''}">${fm(h.value)}</td><td><button class="s" data-act="invView" data-arg="${h.id}">Détail</button></td></tr>`).join('')}</table><div class="mu">Valeur des écarts au prix d'achat : négative = perte, positive = surplus.</div>` : '<span class="mu">Aucun inventaire pour le moment.</span>'}</div>`;
  },

  async buy() {
    const [sup, prods, pos, bal] = await Promise.all([api('GET', '/suppliers'), api('GET', '/products' + qs({ loc: 'all' })), api('GET', '/purchase-orders' + qs(locP())), api('GET', '/suppliers/balances')]);
    PR = prods;
    const total = PO.reduce((a, l) => a + l.qty * l.cost, 0);
    const newPO = !sup.length
      ? '<div class="c"><h3>Nouveau bon de commande</h3><span class="mu">Ajoutez d\'abord un fournisseur dans l\'onglet Stock.</span></div>'
      : `<div class="c"><h3>Nouveau bon de commande</h3>${vl === 'all' ? '<div class="al">Choisissez en haut de l\'écran le magasin ou l\'entrepôt où la marchandise sera livrée.</div>' : `<div class="mu">Livraison : ${esc(LN(vl))}</div>`}<div class="g"><div><label>Fournisseur</label><select id="bs" data-ch="posup"><option value="">—</option>${sup.map((x) => `<option value="${x.id}" ${String(POSUP) === String(x.id) ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></div><div><label>Produit</label><select id="bp">${PR.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select></div><div><label>Quantité</label><input id="bq" type="number" min="1" value="1"></div><div><label>Prix d'achat unitaire (vide = prix d'achat du produit)</label><input id="bc" type="number" min="0"></div></div><br><button class="s" data-act="addPOLine">Ajouter la ligne</button>${PO.length ? `<div class="tbl"><table>${PO.map((l, i) => `<tr><td>${esc(l.name)}</td><td>${l.qty} × ${fm(l.cost)}</td><td>${fm(l.qty * l.cost)}</td><td><button class="s" data-act="delPOLine" data-arg="${i}">✕</button></td></tr>`).join('')}</table><div class="k">Total : ${fm(total)}</div></div>` : ''}<div class="g"><div><label>Note (facultatif)</label><input id="bn"></div></div><br><button ${PO.length ? '' : 'disabled'} data-act="savePO">Créer le bon de commande</button></div>`;
    const st = { 'ouvert': 'Ouvert', 'reçu partiel': 'Reçu en partie', 'reçu': 'Reçu', 'annulé': 'Annulé' };
    return newPO + `<div class="c tbl"><h3>Bons de commande</h3>${pos.length ? `<table><tr><th>N°</th><th>Date</th><th>Fournisseur</th><th>Livraison</th><th>Total</th><th>Statut</th><th></th></tr>${pos.map((o) => `<tr><td>${esc(o.no)}</td><td>${dt(o.t)}</td><td>${esc(o.supplier_name)}</td><td>${esc(o.locName)}</td><td>${fm(o.total)}</td><td><span class="bdg ${o.status === 'annulé' ? 'bad' : ''}">${esc(st[o.status] || o.status)}</span></td><td><button class="s" data-act="poView" data-arg="${o.id}">${o.status === 'ouvert' || o.status === 'reçu partiel' ? 'Voir / Recevoir' : 'Voir'}</button></td></tr>`).join('')}</table>` : '<span class="mu">Aucun bon de commande.</span>'}</div>
<div class="c tbl"><h3>Dettes fournisseurs</h3><div class="mu">Dette = marchandise reçue sur les bons de commande − paiements. La sortie d'argent apparaît en trésorerie au moment du paiement.</div>${bal.length ? `<table><tr><th>Fournisseur</th><th>Reçu</th><th>Payé</th><th>Reste dû</th><th>Payer</th></tr>${bal.map((b) => `<tr><td>${esc(b.name)}</td><td>${fm(b.received)}</td><td>${fm(b.paid)}</td><td class="${b.due > 0 ? 'bad' : ''}"><b>${fm(b.due)}</b></td><td>${b.due > 0 ? `<input id="sa${b.id}" type="number" min="1" class="w110" value="${b.due}"> <button class="s" data-act="supPay" data-arg="${b.id}">Payer</button>` : '—'}</td></tr>`).join('')}</table>` : '<span class="mu">Aucun fournisseur.</span>'}</div>`;
  },

  async jr() {
    const L = await api('GET', '/log');
    return `<div class="c tbl"><h3>Journal d'activité</h3><table><tr><th>Date</th><th>Utilisateur</th><th>Action</th><th>Détail</th></tr>${L.map((x) => `<tr><td>${new Date(x.t).toLocaleString('fr-FR')}</td><td>${esc(x.by)}</td><td>${esc(x.ty)}</td><td>${esc(x.d)}</td></tr>`).join('')}</table></div>`;
  },

  async loc() {
    const [locs, users, prods] = await Promise.all([api('GET', '/locations'), api('GET', '/users'), api('GET', '/products' + qs({ loc: 'all' }))]);
    ST.locs = locs;
    const value = (id) => prods.reduce((a, p) => a + ((p.byLoc || {})[id] || 0) * p.buy, 0);
    return `<div class="c"><h3>Magasins et entrepôts</h3><div class="mu">Chaque emplacement a son propre stock et ses ventes. Vous, administrateur, voyez tout.</div></div>
<div class="c tbl"><table><tr><th>Nom</th><th>Type</th><th>Adresse</th><th>Utilisateurs</th><th>Valeur du stock</th><th></th></tr>${locs.map((l) => `<tr><td><b>${esc(l.name)}</b>${l.archived ? ' <span class="bdg bad">archivé</span>' : ''}</td><td>${esc(l.type)}</td><td>${esc(l.addr)}</td><td>${users.filter((u) => u.role !== 'admin' && !u.disabled && u.location_id === l.id).map((u) => esc(u.name) + ' <span class="mu">(' + esc(u.role) + ')</span>').join('<br>') || '—'}${!l.archived && !users.some((u) => u.role === 'gérant' && !u.disabled && u.location_id === l.id) ? '<br><span class="bdg bad">Aucun gérant</span>' : ''}</td><td>${fm(value(l.id))}</td><td><button class="s" data-act="editL" data-arg="${l.id}">Modifier</button> <button class="s" data-act="arch" data-arg="${l.id}">${l.archived ? 'Réactiver' : 'Archiver'}</button></td></tr>`).join('')}</table></div>
<div class="c"><h3>Nouvel emplacement</h3><div class="g"><div><label>Nom</label><input id="ln"></div><div><label>Type</label><select id="lt"><option>magasin</option><option>entrepôt</option></select></div><div><label>Adresse</label><input id="la"></div></div>
<h3 class="mt">Compte du gérant</h3><div class="mu">Le gérant gère cet emplacement : tableau de bord, stock, promotions, caisse, crédits, ventes, clients et profil. Lui seul peut annuler une vente.</div><div class="g"><div><label>Nom du gérant *</label><input id="gm1" autocomplete="off"></div><div><label>Identifiant *</label><input id="gm2" autocapitalize="none" autocomplete="off"></div><div><label>Mot de passe * (6 caractères min.)</label><input id="gm3" type="password" autocomplete="new-password"></div></div>
<h3 class="mt">Compte de l'employé</h3><div class="mu">L'employé a accès au tableau de bord, à la caisse, aux crédits, aux clients et à son profil. Vous pourrez ajouter d'autres employés dans l'onglet Équipe.</div><div class="g"><div><label>Nom de l'employé *</label><input id="ge1" autocomplete="off"></div><div><label>Identifiant *</label><input id="ge2" autocapitalize="none" autocomplete="off"></div><div><label>Mot de passe * (6 caractères min.)</label><input id="ge3" type="password" autocomplete="new-password"></div></div>
<div class="mu">Chacun se connecte avec le code entreprise, son identifiant et son mot de passe personnel. Vous ne pourrez plus lire ces mots de passe ; chacun peut ensuite le changer dans son Profil.</div><br><button data-act="addLoc">Créer l'emplacement et ses deux comptes</button></div>`;
  },

  async team() {
    USERS = await api('GET', '/users');
    return `<div class="c"><h3>Équipe (${USERS.length})</h3>${USERS.map((u) => `<div>${esc(u.name)} <span class="mu">@${esc(u.login)}</span> <span class="bdg">${esc(u.role)}</span>${u.disabled ? ' <span class="bdg bad">désactivé</span>' : ''} <button class="s" data-act="editU" data-arg="${u.id}">Modifier</button>${u.role !== 'admin' ? ` <span class="mu">· ${esc(LN(u.location_id))}</span>` : ''}</div>`).join('')}</div>
<div class="c"><h3>Ajouter un gérant ou un employé</h3><div class="g"><div><label>Nom</label><input id="un"></div><div><label>Identifiant</label><input id="ul" autocapitalize="none"></div><div><label>Mot de passe</label><input id="up" type="password" autocomplete="new-password"></div><div><label>Rôle</label><select id="ur"><option>gérant</option><option>employé</option><option>admin</option></select></div><div><label>Emplacement (gérant/employé)</label><select id="ul2">${optLocs('')}</select></div></div><br><button data-act="addUser">Créer</button><div class="mu">Nombre d'utilisateurs illimité.</div></div>`;
  },

  async prof() {
    const c = ST.co, me = ST.me, ad = isA();
    return `<div class="c"><h3>Mon profil</h3><div class="g"><div><label>Nom</label><input id="fn" value="${esc(me.name)}"></div><div><label>Identifiant</label><input value="${esc(me.login)}" disabled></div><div><label>Rôle</label><input value="${esc(me.role)}" disabled></div></div><h3 class="mt">Changer mon mot de passe</h3><div class="g"><div><label>Mot de passe actuel</label><input id="po" type="password"></div><div><label>Nouveau mot de passe</label><input id="pn2" type="password"></div></div><br><button data-act="saveProf">Enregistrer</button></div>
${ad ? `<div class="c"><h3>Entreprise</h3><div class="mu">Code de connexion de l'entreprise : <b>${esc(c.slug)}</b></div><div class="g"><div><label>Nom</label><input id="k1" value="${esc(c.name)}"></div><div><label>Titulaire du compte bancaire</label><input id="k2" value="${esc(c.holder)}"></div><div><label>Compte bancaire</label><input id="k3" value="${esc(c.bank)}"></div><div><label>Adresse</label><input id="k4" value="${esc(c.addr)}"></div><div><label>GSM</label><input id="k5" value="${esc(c.gsm)}"></div><div><label>Email 1</label><input id="k6" value="${esc(c.e1)}"></div><div><label>Email 2</label><input id="k7" value="${esc(c.e2)}"></div><div><label>NIF</label><input id="k8" value="${esc(c.nif)}"></div><div><label>Devise</label><input id="k9" value="${esc(c.cur || 'KMF')}"></div><div><label>TVA incluse dans les prix (%)</label><input id="k10" type="number" min="0" max="100" value="${c.tva || 0}"></div><div><label>Pied de facture (mentions légales)</label><input id="k11" value="${esc(c.foot || '')}"></div><div><label>Nouveau logo</label><input type="file" accept="image/*" data-ch="logo"></div></div><div class="mu">Cliquez sur « Enregistrer » ci-dessus pour valider.</div></div>
<div class="c"><h3>Sauvegarde</h3><div class="mu">Vos données sont enregistrées sur le serveur. Vous pouvez en plus télécharger une copie complète (fichier .json) et la garder en lieu sûr.</div><br><button data-act="backup">Télécharger une sauvegarde</button></div>` : ''}`;
  },
};

function histTable(rows) {
  if (!rows.length) return '<span class="mu">Aucune vente.</span>';
  return `<table><tr><th>N°</th><th>Date</th><th>Client</th><th>Emplacement</th><th>Vendeur</th><th>Total</th><th></th></tr>${rows.map((s) => `<tr><td>${esc(s.no)}${s.cancelled ? ' <span class="bdg bad">Annulée</span>' : ''}${s.mode === 'Crédit' ? ' <span class="bdg">Crédit</span>' : ''}</td><td>${dt(s.t)}</td><td>${esc(s.client)}</td><td>${esc(s.locName)}</td><td>${esc(s.by)}</td><td>${fm(s.total)}</td><td><button class="s" data-act="inv" data-arg="${s.id}">Facture</button></td></tr>`).join('')}</table>`;
}

/* ---------- Clients ---------- */
function custTable(rows) {
  if (!rows.length) return '<span class="mu">Aucun client.</span>';
  return `<table><tr><th>Client</th><th>Téléphone</th><th>Achats</th><th>Total acheté</th><th>Crédit dû</th><th></th></tr>${rows.map((c) => `<tr><td><b>${esc(c.name)}</b>${c.note ? `<br><span class="mu">${esc(c.note)}</span>` : ''}</td><td>${esc(c.phone)}</td><td>${c.purchases}</td><td>${fm(c.spent)}</td><td class="${c.due > 0 ? 'bad' : ''}">${fm(c.due)}</td><td><button class="s" data-act="custView" data-arg="${c.id}">Fiche</button>${isA() ? ` <button class="s" data-act="editC" data-arg="${c.id}">Modifier</button>` : ''}</td></tr>`).join('')}</table>`;
}

/* ---------- Import de produits (CSV) ---------- */
function importCard() {
  return `<div class="c"><h3>Importer des produits (Excel / CSV)</h3><div class="mu">Colonnes : Nom, Code-barres, Prix d'achat, Prix de vente, Stock, Seuil d'alerte. Dans Excel : Fichier › Enregistrer sous › CSV. Mettez la colonne des codes-barres au format Texte. Un code-barres déjà connu met à jour le produit (nom, prix, seuil) sans toucher à son stock : pour corriger un stock, utilisez l'Inventaire.</div><div class="g"><div><label>Fichier .csv</label><input type="file" accept=".csv,.txt,text/csv" data-ch="importfile"></div></div><div class="mu" id="impinfo">Aucun fichier choisi.</div><br><button class="s" data-act="tpl">Télécharger un modèle</button> <button id="impgo" data-act="importGo" disabled>Importer</button></div>`;
}
function parseCsv(text) {
  text = text.replace(/^﻿/, '');
  const first = text.split(/\r?\n/, 1)[0] || '';
  const sep = [';', ',', '\t'].map((c) => [c, first.split(c).length]).sort((a, b) => b[1] - a[1])[0][0];
  const rows = [];
  let row = [], cur = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else quoted = false; } else cur += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === sep) { row.push(cur); cur = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      row.push(cur); cur = '';
      if (row.some((c) => c.trim() !== '')) rows.push(row);
      row = [];
    } else cur += ch;
  }
  row.push(cur);
  if (row.some((c) => c.trim() !== '')) rows.push(row);
  return rows;
}
const normH = (s) => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');
const HMAP = {
  name: ['nom', 'produit', 'designation', 'name', 'article', 'libelle'],
  code: ['code', 'codebarres', 'codebarre', 'barcode', 'ean', 'reference', 'ref'],
  buy: ['achat', 'prixachat', 'prixdachat', 'buy', 'cout', 'cost'],
  price: ['vente', 'prixvente', 'prixdevente', 'prix', 'price', 'pv'],
  qty: ['stock', 'quantite', 'qte', 'qty', 'stockinitial'],
  min: ['seuil', 'seuilalerte', 'seuildalerte', 'min', 'minimum'],
};
function readImport(text) {
  const t = parseCsv(text);
  if (t.length < 2) return { rows: [], error: 'Le fichier est vide ou ne contient que les en-têtes.' };
  const head = t[0].map(normH), col = {};
  for (const [k, names] of Object.entries(HMAP)) { const i = head.findIndex((h) => names.includes(h)); if (i >= 0) col[k] = i; }
  if (col.name === undefined || col.price === undefined) return { rows: [], error: 'Colonnes obligatoires introuvables : « Nom » et « Prix de vente ».' };
  const num = (x) => { const y = String(x ?? '').replace(/\s/g, '').replace(',', '.'); return y === '' ? '' : (Number.isFinite(Number(y)) ? Number(y) : 'x'); };
  const get = (r, k) => (col[k] === undefined ? '' : r[col[k]]);
  return {
    rows: t.slice(1).map((r) => ({ name: String(get(r, 'name') || '').trim(), code: String(get(r, 'code') || '').trim(), buy: num(get(r, 'buy')), price: num(get(r, 'price')), qty: num(get(r, 'qty')), min: num(get(r, 'min')) })),
  };
}
const csvFile = (name, rows) => {
  const b = new Blob(['﻿' + rows.map((r) => r.map((c) => '"' + String(c).replace(/"/g, '""') + '"').join(';')).join('\n')], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
};

/* ---------- Facture ---------- */
function showInv(s) {
  const c = ST.co, tv = +c.tva || 0, ta = tv ? s.total * tv / (100 + tv) : 0;
  const sv = s.lines.reduce((a, l) => a + (l.promoPct > 0 ? (l.listPrice - l.price) * l.qty : 0), 0);
  openMo(`<div class="md"><div class="c inv"><div class="hd">${c.logo ? `<img src="${esc(c.logo)}" alt="">` : ''}<div><b>${esc(c.name)}</b><br>${esc(c.addr)}<br>${esc(c.gsm)} · ${esc(c.e1)}${c.nif ? '<br>NIF : ' + esc(c.nif) : ''}</div></div><h3>Facture ${esc(s.no)}</h3><div>${esc(s.locName)} · ${dt(s.t)} · ${esc(s.client)} · ${esc(s.mode)}</div>
<table style="width:100%;margin:8px 0"><tr><th>Désignation</th><th class="r">Qté × Prix</th><th class="r">Montant</th></tr>${s.lines.map((l) => `<tr><td>${esc(l.name)}</td><td class="r">${lqi(l)}</td><td class="r">${fm(l.qty * l.price)}</td></tr>`).join('')}</table>
${sv > 0 ? `<div class="r mu">Économie grâce aux promotions : ${fm(sv)}</div>` : ''}${s.discount > 0 ? `<div class="r">Remise : −${fm(s.discount)}</div>` : ''}${tv ? `<div class="r">Total HT : ${fm(s.total - ta)}</div><div class="r">TVA (${tv} %) : ${fm(ta)}</div>` : ''}<div class="k r">Total${tv ? ' TTC' : ''} : ${fm(s.total)}</div>${s.mode === 'Crédit' && !s.cancelled ? `<div class="r">Reste à payer : ${fm(s.rest)}</div>` : ''}${c.bank ? `<div class="mu">Paiement bancaire : ${esc(c.holder)} — ${esc(c.bank)}</div>` : ''}${c.foot ? `<div class="mu">${esc(c.foot)}</div>` : ''}<br>
${s.cancelled ? `<div class="bad"><b>Facture annulée par l'avoir ${esc(s.cnNo)}</b></div>` : `<div class="nop"><h3>Annuler cette vente</h3><div class="mu">Seul le gérant peut annuler une vente : il saisit son identifiant et son mot de passe.</div><div class="g"><div><label>Motif</label><input id="av" placeholder="Motif de l'annulation"></div><div><label>Identifiant du gérant</label><input id="avl" autocapitalize="none" autocomplete="off"></div><div><label>Mot de passe du gérant</label><input id="avp" type="password" autocomplete="new-password" data-enter="avoir" data-arg="${s.id}"></div></div><br><button data-act="avoir" data-arg="${s.id}">Annuler la vente (émettre l'avoir)</button></div>`}<br>
<div class="nop"><button data-act="print">Imprimer (A4 / PDF)</button> <button class="s" data-act="tk">Ticket</button> <button class="s" data-act="closeMo">Fermer</button></div></div></div>`);
}

/* ---------- Actions ---------- */
const ACT = {
  go(t) { tab = t; render(); },
  ent(x) { ent = x; render(); },
  inst() { if (ip) ip.prompt(); ip = null; render(); },

  async login() {
    const slug = v('ls').trim().toLowerCase();
    if (!v('lu').trim() || !v('lp')) return toast('Identifiant et mot de passe requis', true);
    const d = await api('POST', '/auth/login', { slug, login: v('lu'), pin: v('lp') });
    if (d.owner) { ST.owner = true; render(); return; }
    remember(slug); setSession(d); render();
  },
  async setup() {
    if (!v('a1') || !v('a6') || !v('b1') || !v('b0') || v('b2').length < 6) return toast('Remplissez les champs obligatoires (*).', true);
    const d = await api('POST', '/auth/register', {
      company: { name: v('a1'), addr: v('a4'), email1: v('a6'), logo },
      admin: { name: v('b1'), login: v('b0'), pin: v('b2') },
    });
    logo = ''; remember(d.company.slug); setSession(d); render();
    toast('Entreprise créée. Code de connexion de vos employés : ' + d.company.slug);
  },
  async logout() {
    try { await api('POST', '/auth/logout', {}); } catch (e) { /* ignore */ }
    ST.me = null; ST.co = null; ST.locs = []; ST.owner = false; cart = []; ent = 'login'; closeMo(); render();
  },
  async opay(id) {
    const c = OWN.find((x) => x.id === +id);
    if (!c || !confirm('Confirmer le paiement de l\'abonnement de « ' + c.name + ' » pour ' + MOIS(c.sub.period) + ' (' + fm(c.sub.price) + ') ?')) return;
    await api('POST', '/owner/companies/' + id + '/pay', {});
    toast('Abonnement marqué comme payé');
    render();
  },
  async oblock(id) {
    const c = OWN.find((x) => x.id === +id);
    await api('POST', '/owner/companies/' + id + '/block', { blocked: !c.blocked });
    toast(c.blocked ? 'Entreprise débloquée' : 'Entreprise bloquée');
    render();
  },

  oreset(id) {
    const u = OWN.flatMap((c) => c.users.map((x) => ({ ...x, co: c.name }))).find((x) => x.id === +id);
    if (!u) return;
    openMo(`<div class="md"><div class="c"><h3>Réinitialiser le mot de passe</h3><div class="mu">${esc(u.name)} (@${esc(u.login)}) · ${esc(u.co)}</div><label>Nouveau mot de passe (6 caractères min.)</label><input id="orp" type="text" autocomplete="off" data-enter="oresetGo" data-arg="${u.id}"><div class="mu">L'ancien mot de passe ne peut pas être lu. Communiquez le nouveau à l'utilisateur ; il pourra ensuite le changer dans son Profil.</div><br><button data-act="oresetGo" data-arg="${u.id}">Enregistrer</button> <button class="s" data-act="closeMo">Annuler</button></div></div>`);
  },
  async oresetGo(id) {
    if (v('orp').length < 6) return toast('Mot de passe : 6 caractères min.', true);
    await api('POST', '/owner/users/' + id + '/reset-pin', { pin: v('orp') });
    closeMo(); toast('Mot de passe réinitialisé');
  },
  async oacct() {
    const a = await api('GET', '/owner/account');
    openMo(`<div class="md"><div class="c"><h3>Mon accès propriétaire</h3><label>PIN actuel</label><input id="ocp" type="password" autocomplete="current-password"><label>Identifiant</label><input id="olg" autocapitalize="none" value="${esc(a.login)}"><label>Nouveau PIN (6 caractères min.)</label><input id="onp" type="password" autocomplete="new-password"><label>Confirmer le nouveau PIN</label><input id="onp2" type="password" autocomplete="new-password" data-enter="oacctGo"><div class="mu">Les valeurs enregistrées ici remplacent OWNER_LOGIN et OWNER_PIN du serveur.</div><br><button data-act="oacctGo">Enregistrer</button> <button class="s" data-act="closeMo">Annuler</button></div></div>`);
  },
  async oacctGo() {
    if (!v('ocp')) return toast('Entrez votre PIN actuel', true);
    if (v('onp').length < 6) return toast('Nouveau PIN : 6 caractères min.', true);
    if (v('onp') !== v('onp2')) return toast('Les deux PIN ne correspondent pas', true);
    const r = await api('PUT', '/owner/account', { currentPin: v('ocp'), login: v('olg'), newPin: v('onp') });
    closeMo(); toast('Accès enregistré. Identifiant : ' + r.login);
  },

  async addCust() {
    if (!v('kn').trim()) return toast('Nom du client requis', true);
    await api('POST', '/customers', { name: v('kn'), phone: v('kt'), addr: v('ka'), note: v('kq') });
    toast('Client ajouté'); render();
  },
  async custView(id) {
    const c = await api('GET', '/customers/' + id);
    const due = c.sales.reduce((a, s) => a + s.rest, 0);
    openMo(`<div class="md"><div class="c"><h3>${esc(c.name)}</h3><div class="mu">${esc(c.phone)}${c.addr ? ' · ' + esc(c.addr) : ''}${c.note ? ' · ' + esc(c.note) : ''}</div><div class="k mt ${due > 0 ? 'bad' : ''}">Crédit dû : ${fm(due)}</div><div class="tbl"><table><tr><th>Facture</th><th>Date</th><th>Paiement</th><th>Total</th><th>Reste</th><th></th></tr>${c.sales.map((s) => `<tr><td>${esc(s.no)}${s.cancelled ? ' <span class="bdg bad">Annulée</span>' : ''}</td><td>${dt(s.t)}</td><td>${esc(s.mode)}</td><td>${fm(s.total)}</td><td class="${s.rest > 0 ? 'bad' : ''}">${fm(s.rest)}</td><td><button class="s" data-act="inv" data-arg="${s.id}">Facture</button></td></tr>`).join('')}</table>${c.sales.length ? '' : '<span class="mu">Aucun achat.</span>'}</div><br><button class="s" data-act="closeMo">Fermer</button></div></div>`);
  },
  editC(id) {
    const c = CUSTS.find((x) => x.id === +id);
    if (!c) return;
    openMo(`<div class="md"><div class="c"><h3>Modifier le client</h3><div class="g"><div><label>Nom</label><input id="cen" value="${esc(c.name)}"></div><div><label>Téléphone</label><input id="cet" value="${esc(c.phone)}"></div><div><label>Adresse</label><input id="cea" value="${esc(c.addr)}"></div><div><label>Note</label><input id="ceq" value="${esc(c.note)}"></div></div><br><button data-act="saveC" data-arg="${c.id}">Enregistrer</button> <button class="s" data-act="closeMo">Fermer</button> <button class="s" data-act="delC" data-arg="${c.id}">Archiver</button></div></div>`);
  },
  async saveC(id) {
    if (!v('cen').trim()) return toast('Nom du client requis', true);
    await api('PUT', '/customers/' + id, { name: v('cen'), phone: v('cet'), addr: v('cea'), note: v('ceq') });
    closeMo(); toast('Client modifié'); render();
  },
  async delC(id) {
    await api('DELETE', '/customers/' + id);
    closeMo(); toast('Client archivé'); render();
  },

  tpl() {
    csvFile('modele_produits.csv', [['Nom', 'Code-barres', "Prix d'achat", 'Prix de vente', 'Stock', "Seuil d'alerte"], ['Riz 25 kg', '6001234567890', 12000, 15000, 10, 5], ['Huile 5 L', '6009876543210', 4500, 6000, 20, 5]]);
  },
  async importGo() {
    if (!IMP.length) return toast('Choisissez d\'abord un fichier', true);
    const r = await api('POST', '/products/import', { rows: IMP, loc: vl });
    IMP = [];
    openMo(`<div class="md"><div class="c"><h3>Import terminé</h3><div>${r.created} produit(s) créé(s), ${r.updated} mis à jour, ${r.skippedCount} ligne(s) ignorée(s).</div>${r.stocked ? `<div class="mu">Stock initial enregistré pour ${r.stocked} produit(s).</div>` : ''}${r.skippedCount ? `<div class="mt"><b>Lignes ignorées</b> (numéro de ligne du fichier, hors lignes vides)${r.skippedCount > r.skipped.length ? ' : les ' + r.skipped.length + ' premières' : ''}</div><div class="tbl"><table>${r.skipped.map((x) => `<tr><td>Ligne ${x.line}</td><td>${esc(x.reason)}</td></tr>`).join('')}</table></div>` : ''}<br><button data-act="closeMo">Fermer</button></div></div>`);
    render();
  },

  async invGo() {
    const counts = [];
    for (const p of PR) {
      const raw = v('ic' + p.id).trim();
      if (raw === '') continue;
      const n = Number(raw);
      if (!Number.isInteger(n) || n < 0) return toast('Quantité invalide pour « ' + p.name + ' »', true);
      counts.push({ productId: p.id, counted: n });
    }
    if (!counts.length) return toast('Renseignez la quantité comptée d\'au moins un produit', true);
    const r = await api('POST', '/inventory', { loc: vl, note: v('inote'), counts });
    toast('Inventaire #' + r.id + ' : ' + r.differences + ' écart(s) corrigé(s) sur ' + r.counted + ' produit(s)'); render();
  },
  async invView(id) {
    const h = await api('GET', '/inventory/' + id);
    openMo(`<div class="md"><div class="c"><h3>Inventaire #${h.id}</h3><div class="mu">${esc(h.locName)} · ${dt(h.t)} · ${esc(h.by)}${h.note ? ' · ' + esc(h.note) : ''}</div><div class="tbl"><table><tr><th>Produit</th><th>Attendu</th><th>Compté</th><th>Écart</th><th>Valeur</th></tr>${h.lines.map((l) => { const d = l.counted - l.expected; return `<tr><td>${esc(l.name)}</td><td>${l.expected}</td><td>${l.counted}</td><td class="${d < 0 ? 'bad' : ''}">${d > 0 ? '+' : ''}${d}</td><td class="${d < 0 ? 'bad' : ''}">${fm(d * l.buy)}</td></tr>`; }).join('')}</table></div><br><button class="s" data-act="closeMo">Fermer</button></div></div>`);
  },

  addPOLine() {
    const p = PR.find((x) => x.id === +v('bp')), qty = Math.floor(+v('bq'));
    if (!p || !(qty >= 1)) return toast('Choisissez un produit et une quantité', true);
    const cost = v('bc') === '' ? (p.buy || 0) : Math.max(0, +v('bc'));
    PO.push({ id: p.id, name: p.name, qty, cost });
    render();
  },
  delPOLine(i) { PO.splice(+i, 1); render(); },
  async savePO() {
    if (!one()) return;
    if (!POSUP) return toast('Choisissez un fournisseur', true);
    if (!PO.length) return toast('Ajoutez au moins un produit', true);
    const r = await api('POST', '/purchase-orders', { supplierId: +POSUP, loc: vl, note: v('bn'), lines: PO.map((l) => ({ productId: l.id, qty: l.qty, cost: l.cost })) });
    PO = []; toast('Bon ' + r.no + ' créé'); render();
  },
  async poView(id) {
    const o = await api('GET', '/purchase-orders/' + id);
    const open = o.status === 'ouvert' || o.status === 'reçu partiel';
    const total = o.lines.reduce((a, l) => a + l.qty * l.cost, 0);
    openMo(`<div class="md"><div class="c"><h3>Bon ${esc(o.no)}</h3><div class="mu">${esc(o.supplier_name)} · livraison : ${esc(o.locName)} · ${dt(o.t)} · ${esc(o.status)}${o.note ? ' · ' + esc(o.note) : ''}</div><div class="tbl"><table><tr><th>Produit</th><th>Commandé</th><th>Reçu</th><th>Prix</th>${open ? '<th>Recevoir maintenant</th>' : ''}</tr>${o.lines.map((l) => `<tr><td>${esc(l.name)}</td><td>${l.qty}</td><td>${l.received}</td><td>${fm(l.cost)}</td>${open ? `<td><input id="rl${l.id}" type="number" min="0" max="${l.qty - l.received}" value="${l.qty - l.received}" class="w80"></td>` : ''}</tr>`).join('')}</table></div><div class="k">Total : ${fm(total)}</div><br>${open ? `<button data-act="poRecv" data-arg="${o.id}">Enregistrer la réception</button> ` : ''}${o.status === 'ouvert' ? `<button class="s" data-act="poCancel" data-arg="${o.id}">Annuler le bon</button> ` : ''}<button class="s" data-act="closeMo">Fermer</button></div></div>`);
  },
  async poRecv(id) {
    const lines = [...document.querySelectorAll('[id^="rl"]')].map((e) => ({ lineId: +e.id.slice(2), qty: Math.floor(+e.value) })).filter((l) => l.qty > 0);
    if (!lines.length) return toast('Indiquez au moins une quantité reçue', true);
    const r = await api('POST', '/purchase-orders/' + id + '/receive', { lines });
    closeMo(); toast('Réception enregistrée (' + r.status + ')'); render();
  },
  async poCancel(id) {
    await api('POST', '/purchase-orders/' + id + '/cancel', {});
    closeMo(); toast('Bon annulé'); render();
  },
  async supPay(id) {
    const a = +v('sa' + id);
    if (!(a > 0)) return toast('Montant invalide', true);
    await api('POST', '/suppliers/' + id + '/payments', { amount: a, loc: vl });
    toast('Paiement enregistré : ' + fm(a)); render();
  },

  pickAll(x) {
    document.querySelectorAll('tr.pr').forEach((r) => {
      const c = r.querySelector('.pck');
      if (c && r.style.display !== 'none') c.checked = x === '1';
    });
  },
  async applyPromo() {
    const ids = [...document.querySelectorAll('.pck:checked')].map((e) => +e.value);
    const pct = +v('xp');
    if (!ids.length) return toast('Choisissez au moins un produit', true);
    if (!(pct >= 1 && pct <= 99)) return toast('Le pourcentage doit être compris entre 1 et 99', true);
    const f = v('xf'), t = v('xt');
    const from = f ? new Date(f + 'T00:00:00').getTime() : 0, to = t ? new Date(t + 'T23:59:59').getTime() : 0;
    if (from && to && to < from) return toast('La date de fin précède la date de début', true);
    const r = await api('POST', '/promotions', { ids, pct, from, to });
    toast('Promotion −' + pct + ' % appliquée à ' + r.count + ' produit(s)'); render();
  },
  async stopPromo(id) {
    await api('DELETE', '/promotions/' + id);
    toast('Promotion retirée'); render();
  },
  async stopAll() {
    if (!confirm('Retirer toutes les promotions ?')) return;
    const r = await api('DELETE', '/promotions');
    toast(r.count + ' promotion(s) retirée(s)'); render();
  },

  async addProd() {
    if (!v('pn') || !v('ps')) return toast('Nom et prix de vente requis', true);
    await api('POST', '/products', { name: v('pn'), code: v('pc'), buy: v('pb'), price: v('ps'), qty: v('pq'), min: v('pm'), loc: vl });
    toast('Produit ajouté'); render();
  },
  async addSup() {
    if (!v('sn')) return toast('Nom requis', true);
    await api('POST', '/suppliers', { name: v('sn'), phone: v('st') });
    toast('Fournisseur ajouté'); render();
  },
  async recv(id) {
    if (!one()) return;
    const q = Math.floor(+v('r' + id));
    if (!(q > 0)) return toast('Entrez la quantité à ajouter', true);
    const r = await api('POST', '/stock/receive', { productId: +id, qty: q, supplier: v('rsup'), loc: vl });
    toast(q + ' ajouté(s) au stock : ' + r.name); render();
  },
  async transfer() {
    const q = Math.floor(+v('tq'));
    if (!(q > 0)) return toast('Quantité requise', true);
    await api('POST', '/stock/transfer', { from: isA() ? +v('tf') : undefined, to: +v('tt'), productId: +v('tp'), qty: q });
    toast('Transfert effectué'); render();
  },
  editP(id) {
    const p = PR.find((x) => x.id === +id);
    if (!p) return;
    openMo(`<div class="md"><div class="c"><h3>Modifier le produit</h3><div class="g"><div><label>Nom</label><input id="en" value="${esc(p.name)}"></div><div><label>Code-barres</label><input id="ec" value="${esc(p.code)}"></div><div><label>Prix d'achat</label><input id="eb" type="number" min="0" value="${p.buy}"></div><div><label>Prix de vente</label><input id="ep" type="number" min="0" value="${p.price}"></div><div><label>Seuil d'alerte</label><input id="em" type="number" min="0" value="${p.min}"></div><div><label>Ajuster le stock (+/-)</label><input id="ed" type="number" value="0"></div></div><br><button data-act="saveP" data-arg="${p.id}">Enregistrer</button> <button class="s" data-act="closeMo">Fermer</button> <button class="s" data-act="delP" data-arg="${p.id}">Archiver</button></div></div>`);
  },
  async saveP(id) {
    if (!v('en') || !(+v('ep') >= 0)) return toast('Nom et prix requis', true);
    await api('PUT', '/products/' + id, { name: v('en'), code: v('ec'), buy: v('eb'), price: v('ep'), min: v('em'), adjust: Math.trunc(+v('ed')) || 0, loc: vl });
    closeMo(); toast('Produit modifié'); render();
  },
  async delP(id) {
    await api('DELETE', '/products/' + id);
    closeMo(); toast('Produit archivé'); render();
  },

  addLine() {
    if (!one()) return;
    const p = PR.find((x) => x.id === +v('sp')), q = +v('sq');
    if (!p || !(q >= 1)) return;
    const l = cart.find((x) => x.id === p.id), n = (l ? l.q : 0) + Math.floor(q);
    if (n > p.stock) return toast('Stock insuffisant (' + p.stock + ')', true);
    if (l) l.q = n; else cart.push(mkLine(p, n));
    render();
  },
  scan() {
    if (!one()) return;
    const c = v('sb').trim(), p = PR.find((x) => x.code && x.code === c);
    if (!p) return toast('Code inconnu', true);
    const l = cart.find((x) => x.id === p.id), n = (l ? l.q : 0) + 1;
    if (n > p.stock) return toast('Stock insuffisant', true);
    if (l) l.q = n; else cart.push(mkLine(p, 1));
    render().then(() => { const e = $('#sb'); if (e) e.focus(); });
  },
  delLine(i) { cart.splice(+i, 1); render(); },
  async doSale() {
    if (!one()) return;
    if (MODE === 'Crédit' && !CLI.trim() && !CID) return toast('Client requis pour un crédit : choisissez un client enregistré ou saisissez un nom', true);
    const s = await api('POST', '/sales', { lines: cart.map((l) => ({ productId: l.id, qty: l.q })), client: CLI, customerId: CID || undefined, discount: DISC || undefined, mode: MODE, loc: vl });
    cart = []; CLI = ''; CID = ''; DISC = 0; MODE = 'Espèces'; tab = canHist() ? 'hist' : 'sale'; render(); showInv(s);
  },

  async inv(id) { showInv(await api('GET', '/sales/' + id)); },
  async avoir(id) {
    if (!v('avl').trim() || !v('avp')) return toast('Identifiant et mot de passe du gérant requis', true);
    const r = await api('POST', '/sales/' + id + '/credit-note', { reason: v('av'), login: v('avl'), password: v('avp') });
    closeMo(); toast('Avoir ' + r.no + ' émis, stock remis'); render();
  },
  print() { window.print(); },
  tk() { document.body.classList.add('tk'); window.print(); setTimeout(() => document.body.classList.remove('tk'), 800); },
  closeMo,

  async repay(id) {
    const r = await api('POST', '/credits/' + id + '/pay', { amount: +v('ra' + id) });
    toast('Règlement enregistré : ' + fm(r.amount)); render();
  },
  async addExp() {
    if (!v('el') || !(+v('ea') > 0)) return toast('Libellé et montant requis', true);
    await api('POST', '/cash', { label: v('el'), amount: +v('ea'), kind: v('ek'), loc: vl });
    toast('Opération ajoutée'); render();
  },

  async saveProf() {
    const n = v('fn').trim(), np = v('pn2');
    if (!n) return toast('Nom requis', true);
    if (np && np.length < 6) return toast('Nouveau mot de passe : 6 caractères min.', true);
    await api('PUT', '/me', { name: n, currentPin: v('po'), newPin: np });
    ST.me.name = n;
    if (isA() && $('#k1')) {
      ST.co = await api('PUT', '/company', { name: v('k1'), holder: v('k2'), bank: v('k3'), addr: v('k4'), gsm: v('k5'), e1: v('k6'), e2: v('k7'), nif: v('k8'), cur: v('k9'), tva: v('k10'), foot: v('k11'), logo });
      logo = '';
    }
    toast('Profil enregistré'); render();
  },
  async expo(kind) {
    await download('/api/export/' + kind + '.csv' + qs({ ...locP(), tz: new Date().getTimezoneOffset() }), ST.co.slug + '_' + kind + '.csv');
  },
  async backup() {
    await download('/api/backup', 'sauvegarde_' + ST.co.slug + '_' + new Date().toISOString().slice(0, 10) + '.json');
    toast('Sauvegarde téléchargée');
  },

  async addLoc() {
    if (!v('ln').trim()) return toast('Nom de l\'emplacement requis', true);
    const acc = (n, l, p, who) => {
      if (!v(n).trim() || !v(l).trim() || v(p).length < 6) { toast('Compte ' + who + ' : nom, identifiant et mot de passe (6 caractères min.) requis', true); return null; }
      return { name: v(n), login: v(l), pin: v(p) };
    };
    const manager = acc('gm1', 'gm2', 'gm3', 'du gérant');
    if (!manager) return;
    const employee = acc('ge1', 'ge2', 'ge3', 'de l\'employé');
    if (!employee) return;
    if (manager.login.trim().toLowerCase() === employee.login.trim().toLowerCase()) return toast('Le gérant et l\'employé doivent avoir deux identifiants différents', true);
    await api('POST', '/locations', { name: v('ln'), type: v('lt'), addr: v('la'), manager, employee });
    await refreshLocs(); toast('Emplacement créé avec le compte du gérant et celui de l\'employé'); render();
  },
  editL(id) {
    const l = ST.locs.find((x) => x.id === +id);
    if (!l) return;
    openMo(`<div class="md"><div class="c"><h3>Modifier l'emplacement</h3><div class="g"><div><label>Nom</label><input id="en" value="${esc(l.name)}"></div><div><label>Type</label><select id="et"><option ${l.type === 'magasin' ? 'selected' : ''}>magasin</option><option ${l.type !== 'magasin' ? 'selected' : ''}>entrepôt</option></select></div><div><label>Adresse</label><input id="ea2" value="${esc(l.addr)}"></div></div><br><button data-act="saveL" data-arg="${l.id}">Enregistrer</button> <button class="s" data-act="closeMo">Fermer</button></div></div>`);
  },
  async saveL(id) {
    if (!v('en')) return toast('Nom requis', true);
    await api('PUT', '/locations/' + id, { name: v('en'), type: v('et'), addr: v('ea2') });
    await refreshLocs(); closeMo(); toast('Emplacement modifié'); render();
  },
  async arch(id) {
    await api('POST', '/locations/' + id + '/archive', {});
    if (vl === String(id)) vl = 'all';
    await refreshLocs(); render();
  },

  async addUser() {
    if (!v('un') || !v('ul').trim() || v('up').length < 6) return toast('Nom, identifiant et mot de passe (6 caractères min.) requis', true);
    await api('POST', '/users', { name: v('un'), login: v('ul'), pin: v('up'), role: v('ur'), location_id: +v('ul2') || null });
    toast('Utilisateur créé'); render();
  },
  editU(id) {
    const u = USERS.find((x) => x.id === +id);
    if (!u) return;
    openMo(`<div class="md"><div class="c"><h3>Modifier ${esc(u.name)}</h3><div class="g"><div><label>Nom</label><input id="un2" value="${esc(u.name)}"></div><div><label>Rôle</label><select id="ur2"><option ${u.role === 'gérant' ? 'selected' : ''}>gérant</option><option ${u.role === 'employé' ? 'selected' : ''}>employé</option><option ${u.role === 'admin' ? 'selected' : ''}>admin</option></select></div><div><label>Emplacement</label><select id="ul3">${optLocs(u.location_id || (AL()[0] || {}).id)}</select></div><div><label>Nouveau mot de passe (vide = inchangé)</label><input id="up2" type="password"></div><div><label>Statut</label><select id="us2"><option value="on">Actif</option><option value="off" ${u.disabled ? 'selected' : ''}>Désactivé</option></select></div></div><br><button data-act="saveU" data-arg="${u.id}">Enregistrer</button> <button class="s" data-act="closeMo">Fermer</button></div></div>`);
  },
  async saveU(id) {
    if (!v('un2')) return toast('Nom requis', true);
    if (v('up2') && v('up2').length < 6) return toast('Mot de passe : 6 caractères min.', true);
    await api('PUT', '/users/' + id, { name: v('un2'), role: v('ur2'), location_id: +v('ul3') || null, pin: v('up2'), disabled: v('us2') === 'off' });
    if (+id === ST.me.id) ST.me.name = v('un2');
    closeMo(); toast('Utilisateur modifié'); render();
  },
};

/* ---------- Saisie / sélection ---------- */
const INP = {
  csearch(q) {
    clearTimeout(hT);
    hT = setTimeout(async () => {
      try {
        CUSTS = await api('GET', '/customers' + qs({ q }));
        const el = $('#cl');
        if (el) el.innerHTML = custTable(CUSTS);
      } catch (e) { toast(e.message, true); }
    }, 300);
  },
  disc(x) {
    DISC = Math.max(0, +x || 0);
    const t = $('#tot');
    if (t) { const s = cart.reduce((a, l) => a + l.q * l.price, 0); t.innerHTML = 'Total : ' + fm(s - Math.min(DISC, s)); }
  },
  promoPrev(x) {
    const p = +x, ok = p >= 1 && p <= 99;
    document.querySelectorAll('.pv').forEach((e) => { e.innerHTML = ok ? fm(Math.round(+e.dataset.p * (1 - p / 100))) : '—'; });
  },
  flt(q) { document.querySelectorAll('tr.pr').forEach((r) => { r.style.display = r.textContent.toLowerCase().includes(q.toLowerCase()) ? '' : 'none'; }); },
  cli(x) { CLI = x; },
  osearch(q) { const el = $('#ol'); if (el) el.innerHTML = ownList(q); },
  hsearch(q) {
    clearTimeout(hT);
    hT = setTimeout(async () => {
      try {
        const rows = await api('GET', '/sales' + qs({ ...locP(), q }));
        const el = $('#hl');
        if (el) el.innerHTML = histTable(rows);
      } catch (e) { toast(e.message, true); }
    }, 300);
  },
};
const CH = {
  cust(x) { CID = x; },
  posup(x) { POSUP = x; },
  async importfile(x, el) {
    const f = el.files[0];
    if (!f) return;
    const info = $('#impinfo'), go = $('#impgo');
    IMP = [];
    if (go) go.disabled = true;
    try {
      if (f.size > 1e6) throw new Error('Fichier trop volumineux (max 1 Mo)');
      const buf = await f.arrayBuffer();
      let text;
      try { text = new TextDecoder('utf-8', { fatal: true }).decode(buf); } catch (e) { text = new TextDecoder('windows-1252').decode(buf); }
      const r = readImport(text);
      if (r.error) throw new Error(r.error);
      if (r.rows.length > 2000) throw new Error('Maximum 2000 lignes par import (' + r.rows.length + ' dans le fichier)');
      IMP = r.rows;
      if (info) info.textContent = IMP.length + ' ligne(s) prête(s) à importer.';
      if (go) go.disabled = false;
    } catch (e) {
      if (info) info.textContent = e.message;
      toast(e.message, true);
    }
  },
  vl(x) { vl = x; cart = []; render(); },
  mode(x) { MODE = x; },
  month(x) { cm = x; render(); },
  logo(x, el) {
    const f = el.files[0];
    if (!f) return;
    if (f.size > 3e5) { el.value = ''; toast('Logo trop lourd (max 300 Ko)', true); return; }
    const r = new FileReader();
    r.onload = () => { logo = r.result; };
    r.readAsDataURL(f);
  },
};

/* ---------- Événements (aucun gestionnaire en ligne : compatible avec la politique de sécurité du serveur) ---------- */
async function run(name, arg, el) {
  const f = ACT[name];
  if (!f) return;
  const btn = el && el.tagName === 'BUTTON' ? el : null;
  if (btn) btn.disabled = true;
  try { await f(arg, el); } catch (e) { toast(e.message || 'Erreur', true); } finally { if (btn && btn.isConnected) btn.disabled = false; }
}
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]');
  if (!el || el.disabled) return;
  if (el.tagName === 'A') e.preventDefault();
  run(el.dataset.act, el.dataset.arg, el);
});
document.addEventListener('input', (e) => {
  const el = e.target.closest('[data-in]');
  if (el && INP[el.dataset.in]) INP[el.dataset.in](el.value, el);
});
document.addEventListener('change', (e) => {
  const el = e.target.closest('[data-ch]');
  if (el && CH[el.dataset.ch]) CH[el.dataset.ch](el.value, el);
});
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  const el = e.target.closest('[data-enter]');
  if (el) { e.preventDefault(); run(el.dataset.enter, el.dataset.arg, el); }
});
// La barre de défilement des onglets est cachée : la molette de la souris la fait défiler horizontalement
document.addEventListener('wheel', (e) => {
  const bar = e.target.closest && e.target.closest('.tabs');
  if (!bar || bar.scrollWidth <= bar.clientWidth || Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
  e.preventDefault();
  bar.scrollLeft += e.deltaY;
}, { passive: false });
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  ip = e;
  if (!ST.me && !ST.owner && !v('lu') && !v('a1')) render();
});
const net = () => { const e = $('#net'); if (e) e.textContent = navigator.onLine ? 'En ligne' : 'Hors ligne'; };
window.addEventListener('online', net);
window.addEventListener('offline', net);

/* ---------- Démarrage ---------- */
(async () => {
  try {
    const d = await api('GET', '/auth/session');
    if (d.owner) ST.owner = true; else setSession(d);
  } catch (e) { /* pas de session ouverte */ }
  render();
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }
})();
