// Changez V à chaque nouvelle version de l'interface pour forcer la mise à jour du cache.
const V = "managestion-v13";
const F = ["/", "/css/app.css", "/js/app.js", "/manifest.webmanifest", "/icon-192.png", "/icon-512.png", "/logo-icon.svg", "/cgu.html", "/confidentialite.html"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(V).then((c) => c.addAll(F)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== V).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Les données vivent sur le serveur : /api n'est jamais mis en cache. Seule l'interface l'est (réseau d'abord, cache en secours).
self.addEventListener("fetch", (e) => {
  const r = e.request;
  const url = new URL(r.url);
  if (r.method !== "GET" || url.origin !== location.origin || url.pathname.startsWith("/api/")) return;
  e.respondWith(
    fetch(r)
      .then((res) => {
        if (res.ok) {
          const copy = res.clone();
          caches.open(V).then((c) => c.put(r, copy));
        }
        return res;
      })
      .catch(() => caches.match(r, { ignoreSearch: true }).then((c) => c || caches.match("/")))
  );
});
