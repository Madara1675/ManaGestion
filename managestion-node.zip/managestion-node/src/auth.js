'use strict';
const jwt = require('jsonwebtoken');
const config = require('./config');
const { query } = require('./db');
const { ApiError, bad, forbidden, wrap, int } = require('./util');
const ownerAccount = require('./ownerAccount');

const COOKIE = 'mg_token';

function setSession(req, res, payload) {
  const token = jwt.sign(payload, config.jwtSecret, { algorithm: 'HS256', expiresIn: config.sessionHours + 'h' });
  res.cookie(COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: req.secure,
    maxAge: config.sessionHours * 3600 * 1000,
    path: '/',
  });
}

function clearSession(res) {
  res.clearCookie(COOKIE, { path: '/' });
}

function readToken(req) {
  const t = req.cookies && req.cookies[COOKIE];
  if (!t) return null;
  try {
    return jwt.verify(t, config.jwtSecret, { algorithms: ['HS256'] });
  } catch (_) {
    return null;
  }
}

/** Authentifie un utilisateur d'entreprise et recharge son état à chaque requête (blocage, désactivation, rôle). */
const authUser = wrap(async (req, res, next) => {
  const p = readToken(req);
  if (!p || p.owner) throw new ApiError(401, 'Session expirée : reconnectez-vous');
  const rows = await query(
    'SELECT u.id, u.company_id, u.name, u.login, u.role, u.location_id, u.disabled, c.blocked, c.slug ' +
      'FROM users u JOIN companies c ON c.id = u.company_id WHERE u.id = ? AND u.company_id = ?',
    [p.uid, p.cid]
  );
  const u = rows[0];
  if (!u) throw new ApiError(401, 'Compte introuvable : reconnectez-vous');
  if (u.blocked) throw new ApiError(401, 'Compte bloqué. Contactez ManaGestion.');
  if (u.disabled) throw new ApiError(401, 'Compte désactivé. Contactez l\'administrateur.');
  if (u.role !== 'admin' && !u.location_id) {
    const l = await query('SELECT id FROM locations WHERE company_id = ? AND archived = 0 ORDER BY id LIMIT 1', [u.company_id]);
    u.location_id = l[0] ? l[0].id : null;
  }
  req.user = u;
  next();
});

/** Authentifie le propriétaire de la plateforme. */
const authOwner = wrap(async (req, res, next) => {
  const p = readToken(req);
  if (!p || !p.owner || !(await ownerAccount.enabled())) throw new ApiError(401, 'Session expirée : reconnectez-vous');
  req.owner = true;
  next();
});

const adminOnly = (req, res, next) => (req.user.role === 'admin' ? next() : next(forbidden()));

/** Administrateur ou gérant d'un emplacement (stock, promotions, historique des ventes). Les employés n'y ont pas accès. */
const managerUp = (req, res, next) => (['admin', 'gérant'].includes(req.user.role)
  ? next()
  : next(forbidden('Action réservée au gérant ou à l\'administrateur')));

/** Gestion des promotions : administrateur et gérant (pas les employés). */
const promoRoles = (req, res, next) => (['admin', 'gérant'].includes(req.user.role)
  ? next()
  : next(forbidden('Les promotions sont réservées aux administrateurs et aux gérants')));

/**
 * Détermine l'emplacement concerné par la requête.
 * - gérant / employé : toujours son propre emplacement ;
 * - admin : paramètre "loc" (id ou "all").
 * single:true exige un emplacement précis, actif (écritures).
 */
async function scopeLoc(req, { single = false } = {}) {
  const u = req.user;
  if (u.role !== 'admin') {
    if (!u.location_id) throw bad('Aucun emplacement n\'est attribué à votre compte');
    return { all: false, id: u.location_id };
  }
  const raw = req.body && req.body.loc !== undefined ? req.body.loc : req.query.loc;
  if (raw === undefined || raw === null || raw === '' || raw === 'all') {
    if (single) throw bad('Choisissez un magasin ou un entrepôt en haut de l\'écran');
    return { all: true, id: null };
  }
  const id = int(raw);
  const rows = await query('SELECT id, archived FROM locations WHERE id = ? AND company_id = ?', [id, u.company_id]);
  if (!rows[0]) throw bad('Emplacement inconnu');
  if (single && rows[0].archived) throw bad('Cet emplacement est archivé');
  return { all: false, id };
}

/** Fragment SQL " AND col = ?" selon l'emplacement. */
const locFilter = (scope, col) => (scope.all ? { sql: '', params: [] } : { sql: ' AND ' + col + ' = ?', params: [scope.id] });

module.exports = { COOKIE, setSession, clearSession, readToken, authUser, authOwner, adminOnly, managerUp, promoRoles, scopeLoc, locFilter };
