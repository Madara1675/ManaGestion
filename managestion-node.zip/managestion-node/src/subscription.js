'use strict';
const config = require('./config');
const { query } = require('./db');
const { duePeriod, inDueWindow } = require('./period');

const localNow = () => new Date(Date.now() + config.tzOffsetMinutes * 60000);

/** Abonnements de plusieurs entreprises : { id -> { period, paid, unpaid, paidAt } }.
 *  « Non payé » = nous sommes à partir du 30/31 et la période due n'a pas été payée. */
async function statuses(ids) {
  const d = localNow();
  const period = duePeriod(d);
  const window = inDueWindow(d);
  const rows = ids.length ? await query('SELECT company_id, t FROM subscription_payments WHERE period = ? AND company_id IN (?)', [period, ids]) : [];
  const paidAt = new Map(rows.map((r) => [r.company_id, r.t]));
  const out = new Map();
  for (const id of ids) {
    const paid = paidAt.has(id);
    out.set(id, { price: config.subscriptionPrice, period, paid, paidAt: paid ? paidAt.get(id) : null, unpaid: window && !paid });
  }
  return out;
}

const info = () => ({ price: config.subscriptionPrice, phone: config.subscriptionPhone });

module.exports = { statuses, info, localNow };
