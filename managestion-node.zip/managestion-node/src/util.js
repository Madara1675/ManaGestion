'use strict';
const { query } = require('./db');

class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const bad = (msg) => new ApiError(400, msg);
const forbidden = (msg) => new ApiError(403, msg || 'Action réservée à l\'administrateur');
const notFound = (msg) => new ApiError(404, msg || 'Introuvable');

/** Enveloppe un handler async pour transmettre les erreurs à Express. */
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const str = (v, max, def = '') => {
  if (v === undefined || v === null) return def;
  return String(v).trim().slice(0, max);
};
const num = (v, def = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
};
const int = (v, def = 0) => {
  const n = Math.trunc(Number(v));
  return Number.isFinite(n) ? n : def;
};

/** Journal d'activité. conn optionnelle pour s'inscrire dans une transaction. */
async function logActivity(req, type, detail, conn) {
  const cid = req.user.company_id;
  const sql = 'INSERT INTO activity_log (company_id, by_name, type, detail, t) VALUES (?,?,?,?,?)';
  const params = [cid, req.user.name, type, String(detail ?? '').slice(0, 255), Date.now()];
  if (conn) await conn.query(sql, params);
  else await query(sql, params);
}

/** Bornes de période (ms) transmises par le navigateur (fuseau horaire de l'utilisateur). */
function range(req) {
  const from = int(req.query.from, 0);
  const to = int(req.query.to, 0);
  if (!from || !to || to <= from) throw bad('Période invalide');
  return { from, to };
}

/** Tronque un code d'emplacement : 3 premiers caractères alphanumériques en majuscules. */
function locCode(name, taken) {
  let c = String(name).replace(/[^A-Za-z0-9]/g, '').slice(0, 3).toUpperCase() || 'LOC';
  let i = 1;
  const base = c;
  while (taken.has(c)) c = base + i++;
  return c;
}

/** Cellule CSV sûre : neutralise l'injection de formules Excel. */
function csvCell(v) {
  let s = String(v ?? '');
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return '"' + s.replace(/"/g, '""') + '"';
}
const toCsv = (rows) => '﻿' + rows.map((r) => r.map(csvCell).join(';')).join('\n');

module.exports = { ApiError, bad, forbidden, notFound, wrap, str, num, int, logActivity, range, locCode, toCsv };
