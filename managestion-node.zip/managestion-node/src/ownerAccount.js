'use strict';
// Accès propriétaire : valeurs de la base si le propriétaire les a changées dans l'interface, sinon variables OWNER_LOGIN / OWNER_PIN.
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const config = require('./config');
const { query } = require('./db');

const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();
const safeEq = (a, b) => crypto.timingSafeEqual(sha(a), sha(b));
const norm = (s) => String(s ?? '').trim().toLowerCase().replace(/\s+/g, ' ').slice(0, 60);
const envSet = () => !!(config.ownerLogin && config.ownerPin);

async function row() {
  const r = await query('SELECT login, pin_hash FROM owner_account WHERE id = 1');
  return r[0] || null;
}

/** L'espace propriétaire est actif s'il existe un accès en base ou dans les variables d'environnement. */
async function enabled() {
  return !!(await row()) || envSet();
}

async function currentLogin() {
  const r = await row();
  return r ? { login: r.login, source: 'database' } : { login: config.ownerLogin, source: 'env' };
}

/** Vérifie identifiant et PIN (les deux comparaisons sont toujours exécutées). */
async function verify(login, pin) {
  const r = await row();
  if (r) {
    const a = safeEq(norm(login), r.login);
    const b = await bcrypt.compare(String(pin ?? ''), r.pin_hash);
    return a && b;
  }
  if (!envSet()) return false;
  const a = safeEq(norm(login), config.ownerLogin);
  const b = safeEq(String(pin ?? ''), config.ownerPin);
  return a && b;
}

async function save(login, pin) {
  const hash = await bcrypt.hash(pin, 10);
  await query(
    'INSERT INTO owner_account (id, login, pin_hash, updated_at) VALUES (1, ?, ?, ?) ' +
      'ON DUPLICATE KEY UPDATE login = VALUES(login), pin_hash = VALUES(pin_hash), updated_at = VALUES(updated_at)',
    [login, hash, Date.now()]);
}

module.exports = { norm, enabled, currentLogin, verify, save };
