'use strict';
const path = require('path');
const crypto = require('crypto');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const env = process.env;
const prod = env.NODE_ENV === 'production';

let jwtSecret = env.JWT_SECRET || '';
if (!jwtSecret) {
  if (prod) {
    console.error('ERREUR : la variable JWT_SECRET est obligatoire en production (au moins 32 caractères).');
    process.exit(1);
  }
  jwtSecret = crypto.randomBytes(32).toString('hex');
  console.warn('Attention : JWT_SECRET absent, un secret temporaire est utilisé (les sessions sont perdues à chaque redémarrage).');
}
if (prod && jwtSecret.length < 32) {
  console.error('ERREUR : JWT_SECRET est trop court (minimum 32 caractères).');
  process.exit(1);
}

module.exports = {
  prod,
  port: Number(env.PORT) || 3000,
  db: {
    host: env.DB_HOST || 'localhost',
    port: Number(env.DB_PORT) || 3306,
    user: env.DB_USER || 'root',
    password: env.DB_PASSWORD || '',
    database: env.DB_NAME || 'managestion',
  },
  jwtSecret,
  sessionHours: Number(env.SESSION_HOURS) > 0 ? Number(env.SESSION_HOURS) : 12,
  ownerLogin: (env.OWNER_LOGIN || '').trim().toLowerCase().replace(/\s+/g, ' '),
  ownerPin: env.OWNER_PIN || '',
  // Abonnement mensuel des entreprises clientes
  subscriptionPrice: Number(env.SUBSCRIPTION_PRICE) > 0 ? Number(env.SUBSCRIPTION_PRICE) : 7500,
  subscriptionPhone: (env.SUBSCRIPTION_PHONE || '+269 386 16 39').trim(),
  // Décalage horaire utilisé pour savoir quel jour du mois on est (180 = Comores, UTC+3)
  tzOffsetMinutes: env.TZ_OFFSET_MINUTES !== undefined && env.TZ_OFFSET_MINUTES !== '' && Number.isFinite(Number(env.TZ_OFFSET_MINUTES)) ? Number(env.TZ_OFFSET_MINUTES) : 180,
  // Redirection automatique vers HTTPS en production (mettre false seulement si l'hébergeur ne transmet pas le protocole et provoque une boucle de redirection)
  forceHttps: String(env.FORCE_HTTPS || 'true').toLowerCase() !== 'false',
  allowRegistration: String(env.ALLOW_REGISTRATION || 'true').toLowerCase() !== 'false',
};
