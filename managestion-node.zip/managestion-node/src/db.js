'use strict';
const mysql = require('mysql2/promise');
const config = require('./config');

const pool = mysql.createPool({
  host: config.db.host,
  port: config.db.port,
  user: config.db.user,
  password: config.db.password,
  database: config.db.database,
  waitForConnections: true,
  connectionLimit: 10,
  charset: 'utf8mb4',
  decimalNumbers: true, // DECIMAL renvoyés comme nombres JS
  dateStrings: true,
});

/** Exécute une requête (paramètres "?" ; les tableaux sont développés pour IN (?)). */
async function query(sql, params) {
  const [rows] = await pool.query(sql, params);
  return rows;
}

/** Exécute fn(connexion) dans une transaction ; annule tout en cas d'erreur. */
async function tx(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (e) {
    try { await conn.rollback(); } catch (_) { /* connexion perdue */ }
    throw e;
  } finally {
    conn.release();
  }
}

/** Raccourci pour une connexion de transaction : renvoie uniquement les lignes. */
async function q(conn, sql, params) {
  const [rows] = await conn.query(sql, params);
  return rows;
}

module.exports = { pool, query, tx, q };
