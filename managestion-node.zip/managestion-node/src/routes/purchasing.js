'use strict';
// Bons de commande fournisseurs, réception (totale ou partielle), dettes et paiements fournisseurs.
const express = require('express');
const { query, tx, q } = require('../db');
const { adminOnly, managerUp, scopeLoc, locFilter } = require('../auth');
const { bad, notFound, forbidden, wrap, str, num, int, logActivity } = require('../util');
const { supplierBalances } = require('../queries');

const router = express.Router();
const round2 = (n) => Math.round(n * 100) / 100;

/* ---------- Bons de commande ---------- */
router.get('/purchase-orders', wrap(async (req, res) => {
  const scope = await scopeLoc(req);
  const f = locFilter(scope, 'po.location_id');
  res.json(await query(
    'SELECT po.id, po.no, po.supplier_id, po.supplier_name, po.status, po.t, po.location_id AS loc, l.name AS locName, ' +
      'COALESCE(SUM(pol.qty * pol.cost), 0) AS total, COALESCE(SUM(pol.received * pol.cost), 0) AS receivedValue ' +
      'FROM purchase_orders po JOIN locations l ON l.id = po.location_id LEFT JOIN purchase_order_lines pol ON pol.po_id = po.id ' +
      'WHERE po.company_id = ?' + f.sql + ' GROUP BY po.id, l.name ORDER BY po.id DESC LIMIT 200',
    [req.user.company_id, ...f.params]));
}));

async function loadPO(cid, id, user) {
  const head = await query(
    'SELECT po.id, po.no, po.supplier_id, po.supplier_name, po.status, po.note, po.t, po.by_name AS `by`, po.location_id AS loc, l.name AS locName ' +
      'FROM purchase_orders po JOIN locations l ON l.id = po.location_id WHERE po.id = ? AND po.company_id = ?',
    [id, cid]);
  const po = head[0];
  if (!po || (user.role !== 'admin' && po.loc !== user.location_id)) throw notFound('Bon de commande introuvable');
  po.lines = await query('SELECT id, product_id, name, qty, received, cost FROM purchase_order_lines WHERE po_id = ? ORDER BY id', [id]);
  return po;
}

router.get('/purchase-orders/:id', wrap(async (req, res) => {
  res.json(await loadPO(req.user.company_id, int(req.params.id), req.user));
}));

router.post('/purchase-orders', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const supplierId = int(req.body.supplierId);
  const raw = Array.isArray(req.body.lines) ? req.body.lines : [];
  if (!supplierId) throw bad('Choisissez un fournisseur');
  if (!raw.length) throw bad('Ajoutez au moins un produit');
  if (raw.length > 200) throw bad('Trop de lignes');
  const lines = raw.map((l) => ({ productId: int(l.productId), qty: int(l.qty), cost: Math.max(0, num(l.cost)) }));
  if (lines.some((l) => !l.productId || !(l.qty > 0))) throw bad('Ligne de commande invalide');
  const scope = await scopeLoc(req, { single: true });
  const note = str(req.body.note, 255);

  const out = await tx(async (conn) => {
    const sup = await q(conn, 'SELECT id, name FROM suppliers WHERE id=? AND company_id=?', [supplierId, cid]);
    if (!sup[0]) throw bad('Fournisseur inconnu');
    const ids = [...new Set(lines.map((l) => l.productId))];
    const prods = await q(conn, 'SELECT id, name FROM products WHERE company_id=? AND deleted=0 AND id IN (?)', [cid, ids]);
    if (prods.length !== ids.length) throw bad('Un produit de la commande n\'existe plus');
    const names = new Map(prods.map((p) => [p.id, p.name]));
    const c = await q(conn, 'SELECT po_seq FROM companies WHERE id=? FOR UPDATE', [cid]);
    const seq = c[0].po_seq + 1;
    await q(conn, 'UPDATE companies SET po_seq=? WHERE id=?', [seq, cid]);
    const no = 'BC-' + String(seq).padStart(4, '0');
    const head = await q(conn,
      'INSERT INTO purchase_orders (company_id, location_id, supplier_id, supplier_name, no, status, note, by_name, t) VALUES (?,?,?,?,?,?,?,?,?)',
      [cid, scope.id, supplierId, sup[0].name, no, 'ouvert', note, req.user.name, Date.now()]);
    await q(conn, 'INSERT INTO purchase_order_lines (po_id, product_id, name, qty, received, cost) VALUES ?',
      [lines.map((l) => [head.insertId, l.productId, names.get(l.productId), l.qty, 0, l.cost])]);
    await logActivity(req, 'achat', no + ' : ' + sup[0].name, conn);
    return { id: head.insertId, no };
  });
  res.status(201).json(out);
}));

// Réception : le stock augmente à l'emplacement du bon, et la valeur reçue s'ajoute à la dette du fournisseur.
// Le coût du mouvement reste à 0 : la sortie d'argent n'est comptée en trésorerie qu'au paiement du fournisseur.
router.post('/purchase-orders/:id/receive', managerUp, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const id = int(req.params.id);
  const wanted = Array.isArray(req.body.lines) ? req.body.lines : [];
  const out = await tx(async (conn) => {
    const heads = await q(conn, 'SELECT id, no, status, location_id, supplier_name FROM purchase_orders WHERE id=? AND company_id=? FOR UPDATE', [id, cid]);
    const po = heads[0];
    if (!po) throw notFound('Bon de commande introuvable');
    if (req.user.role !== 'admin' && po.location_id !== req.user.location_id) throw forbidden('Ce bon concerne un autre emplacement');
    if (po.status === 'annulé') throw bad('Ce bon est annulé');
    if (po.status === 'reçu') throw bad('Ce bon est déjà entièrement reçu');
    const lines = await q(conn, 'SELECT id, product_id, name, qty, received FROM purchase_order_lines WHERE po_id=? FOR UPDATE', [id]);
    const byId = new Map(lines.map((l) => [l.id, l]));
    const sum = new Map();
    for (const w of wanted) {
      const l = byId.get(int(w.lineId));
      const qty = int(w.qty);
      if (l && qty > 0) sum.set(l.id, (sum.get(l.id) || 0) + qty);
    }
    const todo = [];
    for (const [lineId, qty] of sum) {
      const l = byId.get(lineId);
      if (qty > l.qty - l.received) throw bad('Quantité trop élevée pour « ' + l.name + ' » (reste ' + (l.qty - l.received) + ')');
      todo.push({ l, qty });
    }
    if (!todo.length) throw bad('Indiquez au moins une quantité reçue');
    const now = Date.now();
    for (const { l, qty } of todo) {
      await q(conn, 'UPDATE purchase_order_lines SET received = received + ? WHERE id=?', [qty, l.id]);
      l.received += qty;
    }
    await q(conn, 'INSERT INTO stock_moves (company_id, product_id, location_id, qty, why, cost, supplier, by_name, t) VALUES ?',
      [todo.map(({ l, qty }) => [cid, l.product_id, po.location_id, qty, po.no, 0, po.supplier_name, req.user.name, now])]);
    const status = lines.every((l) => l.received >= l.qty) ? 'reçu' : 'reçu partiel';
    await q(conn, 'UPDATE purchase_orders SET status=? WHERE id=?', [status, id]);
    await logActivity(req, 'achat', po.no + ' : réception (' + todo.length + ' ligne(s))', conn);
    return { status, lines: todo.length };
  });
  res.status(201).json(out);
}));

router.post('/purchase-orders/:id/cancel', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const id = int(req.params.id);
  await tx(async (conn) => {
    const heads = await q(conn, 'SELECT id, no, status FROM purchase_orders WHERE id=? AND company_id=? FOR UPDATE', [id, cid]);
    if (!heads[0]) throw notFound('Bon de commande introuvable');
    if (heads[0].status !== 'ouvert') throw bad('Seul un bon sans réception peut être annulé');
    await q(conn, 'UPDATE purchase_orders SET status=? WHERE id=?', ['annulé', id]);
    await logActivity(req, 'achat', heads[0].no + ' : annulé', conn);
  });
  res.json({ ok: true });
}));

/* ---------- Dettes et paiements fournisseurs ---------- */
router.get('/suppliers/balances', adminOnly, wrap(async (req, res) => {
  res.json(await supplierBalances(req.user.company_id));
}));

router.post('/suppliers/:id/payments', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const id = int(req.params.id);
  const amount = round2(num(req.body.amount));
  if (!(amount > 0)) throw bad('Montant invalide');
  const scope = await scopeLoc(req);
  await tx(async (conn) => {
    const sup = await q(conn, 'SELECT id, name FROM suppliers WHERE id=? AND company_id=? FOR UPDATE', [id, cid]);
    if (!sup[0]) throw notFound('Fournisseur introuvable');
    const rec = await q(conn,
      'SELECT COALESCE(SUM(pol.received * pol.cost), 0) AS v FROM purchase_order_lines pol JOIN purchase_orders po ON po.id = pol.po_id WHERE po.supplier_id=? AND po.company_id=?',
      [id, cid]);
    const paid = await q(conn, 'SELECT COALESCE(SUM(amount), 0) AS v FROM supplier_payments WHERE supplier_id=? AND company_id=?', [id, cid]);
    const due = round2(rec[0].v - paid[0].v);
    if (amount > due) throw bad('Le montant dépasse la dette envers ce fournisseur (' + due + ')');
    await q(conn, 'INSERT INTO supplier_payments (company_id, supplier_id, location_id, amount, note, by_name, t) VALUES (?,?,?,?,?,?,?)',
      [cid, id, scope.all ? null : scope.id, amount, str(req.body.note, 255), req.user.name, Date.now()]);
    await logActivity(req, 'paiement fournisseur', sup[0].name + ' : ' + amount, conn);
  });
  res.status(201).json({ amount });
}));

module.exports = router;
