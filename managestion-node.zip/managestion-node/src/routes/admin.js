'use strict';
// Entreprise, profil, emplacements, utilisateurs, fournisseurs, journal d'activité.
const bcrypt = require('bcryptjs');
const express = require('express');
const { query, tx, q } = require('../db');
const { adminOnly } = require('../auth');
const { bad, notFound, ApiError, wrap, str, num, int, logActivity, locCode } = require('../util');
const { getCompany, getLocations } = require('../models');

const router = express.Router();
const LOGO_RE = /^data:image\/(png|jpe?g|gif|webp|svg\+xml);base64,[A-Za-z0-9+/=]+$/;
const ROLES = ['admin', 'gérant', 'employé'];
const LOC_TYPES = ['magasin', 'entrepôt'];

/* ---------- Entreprise ---------- */
router.get('/company', wrap(async (req, res) => {
  res.json(await getCompany(req.user.company_id));
}));

router.put('/company', adminOnly, wrap(async (req, res) => {
  const b = req.body;
  const name = str(b.name, 150);
  if (!name) throw bad('Nom de l\'entreprise requis');
  const tva = num(b.tva);
  if (tva < 0 || tva > 100) throw bad('TVA : entre 0 et 100');
  const logo = str(b.logo, 500000);
  if (logo && !LOGO_RE.test(logo)) throw bad('Logo invalide');
  const fields = [name, str(b.holder, 150), str(b.bank, 150), str(b.addr, 255), str(b.gsm, 40), str(b.e1, 150), str(b.e2, 150),
    str(b.nif, 60), str(b.cur, 10, 'KMF') || 'KMF', tva, str(b.foot, 500)];
  let sql = 'UPDATE companies SET name=?, holder=?, bank=?, addr=?, gsm=?, email1=?, email2=?, nif=?, currency=?, tva=?, footer=?';
  if (logo) { sql += ', logo=?'; fields.push(logo); }
  await query(sql + ' WHERE id=?', [...fields, req.user.company_id]);
  await logActivity(req, 'entreprise', 'mise à jour');
  res.json(await getCompany(req.user.company_id));
}));

/* ---------- Profil ---------- */
router.put('/me', wrap(async (req, res) => {
  const name = str(req.body.name, 100);
  if (!name) throw bad('Nom requis');
  const newPin = String(req.body.newPin ?? '');
  if (newPin) {
    if (newPin.length < 6 || newPin.length > 64) throw bad('Nouveau mot de passe : 6 caractères minimum');
    const rows = await query('SELECT pin_hash FROM users WHERE id = ?', [req.user.id]);
    if (!(await bcrypt.compare(String(req.body.currentPin ?? ''), rows[0].pin_hash))) throw bad('Mot de passe actuel incorrect');
    await query('UPDATE users SET name=?, pin_hash=? WHERE id=?', [name, await bcrypt.hash(newPin, 10), req.user.id]);
  } else {
    await query('UPDATE users SET name=? WHERE id=?', [name, req.user.id]);
  }
  req.user.name = name;
  await logActivity(req, 'profil', newPin ? 'nom et mot de passe' : 'nom');
  res.json({ name });
}));

/* ---------- Emplacements ---------- */
router.get('/locations', wrap(async (req, res) => {
  const rows = await getLocations(req.user.company_id);
  res.json(rows.map((l) => ({ ...l, archived: !!l.archived })));
}));

/** Valide un compte (nom, identifiant, mot de passe) saisi à la création d'un emplacement. */
function readAccount(raw, label) {
  const a = raw || {};
  const name = str(a.name, 100);
  const login = str(a.login, 60).toLowerCase().replace(/\s+/g, ' ');
  const pin = String(a.pin ?? '');
  if (!name || !login) throw bad('Compte ' + label + ' : nom et identifiant requis');
  if (pin.length < 6 || pin.length > 64) throw bad('Compte ' + label + ' : mot de passe de 6 caractères minimum');
  return { name, login, pin };
}

// Un nouvel emplacement n'existe jamais sans ses comptes : un gérant et un employé, chacun avec son identifiant
// et son mot de passe. Tout est créé dans une seule transaction (rien n'est enregistré si un identifiant est déjà pris).
router.post('/locations', adminOnly, wrap(async (req, res) => {
  const name = str(req.body.name, 120);
  if (!name) throw bad('Nom requis');
  const type = LOC_TYPES.includes(req.body.type) ? req.body.type : 'magasin';
  const manager = readAccount(req.body.manager, 'gérant');
  const employee = readAccount(req.body.employee, 'employé');
  if (manager.login === employee.login) throw bad('Le gérant et l\'employé doivent avoir deux identifiants différents');
  const cid = req.user.company_id;
  const [mHash, eHash] = await Promise.all([bcrypt.hash(manager.pin, 10), bcrypt.hash(employee.pin, 10)]);

  let id;
  try {
    id = await tx(async (conn) => {
      const taken = new Set((await q(conn, 'SELECT code FROM locations WHERE company_id = ?', [cid])).map((r) => r.code));
      const r = await q(conn, 'INSERT INTO locations (company_id, name, type, addr, code) VALUES (?,?,?,?,?)',
        [cid, name, type, str(req.body.addr, 255), locCode(name, taken)]);
      const now = Date.now();
      await q(conn, 'INSERT INTO users (company_id, name, login, pin_hash, role, location_id, created_at) VALUES (?,?,?,?,?,?,?)',
        [cid, manager.name, manager.login, mHash, 'gérant', r.insertId, now]);
      await q(conn, 'INSERT INTO users (company_id, name, login, pin_hash, role, location_id, created_at) VALUES (?,?,?,?,?,?,?)',
        [cid, employee.name, employee.login, eHash, 'employé', r.insertId, now]);
      await logActivity(req, 'loc', name + ' (gérant @' + manager.login + ', employé @' + employee.login + ')', conn);
      return r.insertId;
    });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new ApiError(409, 'Un des identifiants est déjà utilisé : choisissez-en d\'autres');
    throw e;
  }
  res.status(201).json({ id });
}));

router.put('/locations/:id', adminOnly, wrap(async (req, res) => {
  const name = str(req.body.name, 120);
  if (!name) throw bad('Nom requis');
  const type = LOC_TYPES.includes(req.body.type) ? req.body.type : 'magasin';
  const r = await query('UPDATE locations SET name=?, type=?, addr=? WHERE id=? AND company_id=?',
    [name, type, str(req.body.addr, 255), int(req.params.id), req.user.company_id]);
  if (!r.affectedRows) throw notFound('Emplacement introuvable');
  await logActivity(req, 'loc', name);
  res.json({ ok: true });
}));

router.post('/locations/:id/archive', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const id = int(req.params.id);
  const rows = await query('SELECT id, name, archived FROM locations WHERE id=? AND company_id=?', [id, cid]);
  const l = rows[0];
  if (!l) throw notFound('Emplacement introuvable');
  if (!l.archived) {
    const active = await query('SELECT COUNT(*) AS n FROM locations WHERE company_id=? AND archived=0', [cid]);
    if (active[0].n < 2) throw bad('Gardez au moins un emplacement actif');
    const stock = await query(
      'SELECT 1 FROM (SELECT product_id FROM stock_moves WHERE location_id=? GROUP BY product_id HAVING SUM(qty) <> 0) x LIMIT 1', [id]);
    if (stock.length) throw bad('Transférez ou videz le stock avant d\'archiver');
    const users = await query(
      "SELECT 1 FROM users WHERE company_id=? AND location_id=? AND disabled=0 AND role<>'admin' LIMIT 1", [cid, id]);
    if (users.length) throw bad('Réaffectez d\'abord les utilisateurs de cet emplacement');
  }
  await query('UPDATE locations SET archived = 1 - archived WHERE id=?', [id]);
  await logActivity(req, 'emplacement', l.name + (l.archived ? ' réactivé' : ' archivé'));
  res.json({ archived: !l.archived });
}));

/* ---------- Utilisateurs ---------- */
router.get('/users', adminOnly, wrap(async (req, res) => {
  const rows = await query(
    'SELECT u.id, u.name, u.login, u.role, u.location_id, u.disabled FROM users u WHERE u.company_id = ? ORDER BY u.id',
    [req.user.company_id]);
  res.json(rows.map((u) => ({ ...u, disabled: !!u.disabled })));
}));

async function checkLocation(cid, id) {
  const rows = await query('SELECT id FROM locations WHERE id=? AND company_id=? AND archived=0', [id, cid]);
  if (!rows[0]) throw bad('Emplacement invalide');
}

router.post('/users', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const name = str(req.body.name, 100);
  const login = str(req.body.login, 60).toLowerCase().replace(/\s+/g, ' ');
  const pin = String(req.body.pin ?? '');
  const role = req.body.role;
  if (!name || !login || pin.length < 6 || pin.length > 64) throw bad('Nom, identifiant et mot de passe (6 caractères min.) requis');
  if (!ROLES.includes(role)) throw bad('Rôle invalide');
  let loc = null;
  if (role !== 'admin') {
    loc = int(req.body.location_id) || null;
    if (!loc) throw bad('Emplacement requis');
    await checkLocation(cid, loc);
  }
  try {
    const r = await query('INSERT INTO users (company_id, name, login, pin_hash, role, location_id, created_at) VALUES (?,?,?,?,?,?,?)',
      [cid, name, login, await bcrypt.hash(pin, 10), role, loc, Date.now()]);
    await logActivity(req, 'user', login);
    res.status(201).json({ id: r.insertId });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new ApiError(409, 'Identifiant déjà utilisé');
    throw e;
  }
}));

router.put('/users/:id', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const id = int(req.params.id);
  const name = str(req.body.name, 100);
  const role = req.body.role;
  const disabled = req.body.disabled ? 1 : 0;
  const pin = String(req.body.pin ?? '');
  if (!name) throw bad('Nom requis');
  if (!ROLES.includes(role)) throw bad('Rôle invalide');
  if (pin && (pin.length < 6 || pin.length > 64)) throw bad('Mot de passe : 6 caractères minimum');

  await tx(async (conn) => {
    const rows = await q(conn, 'SELECT id, login, role FROM users WHERE id=? AND company_id=? FOR UPDATE', [id, cid]);
    const u = rows[0];
    if (!u) throw notFound('Utilisateur introuvable');
    if (id === req.user.id && disabled) throw bad('Vous ne pouvez pas désactiver votre propre compte');
    if (u.role === 'admin' && (role !== 'admin' || disabled)) {
      const others = await q(conn, "SELECT COUNT(*) AS n FROM users WHERE company_id=? AND role='admin' AND disabled=0 AND id<>? FOR UPDATE", [cid, id]);
      if (!others[0].n) throw bad('Il faut au moins un administrateur actif');
    }
    let loc = null;
    if (role !== 'admin') {
      loc = int(req.body.location_id) || null;
      if (!loc) throw bad('Emplacement requis');
      const l = await q(conn, 'SELECT id FROM locations WHERE id=? AND company_id=? AND archived=0', [loc, cid]);
      if (!l[0]) throw bad('Emplacement invalide');
    }
    const set = ['name=?', 'role=?', 'location_id=?', 'disabled=?'];
    const params = [name, role, loc, disabled];
    if (pin) { set.push('pin_hash=?'); params.push(await bcrypt.hash(pin, 10)); }
    await q(conn, 'UPDATE users SET ' + set.join(', ') + ' WHERE id=?', [...params, id]);
    await logActivity(req, 'utilisateur', u.login, conn);
  });
  res.json({ ok: true });
}));

/* ---------- Fournisseurs ---------- */
router.get('/suppliers', wrap(async (req, res) => {
  res.json(await query('SELECT id, name, phone FROM suppliers WHERE company_id=? ORDER BY name', [req.user.company_id]));
}));

router.post('/suppliers', adminOnly, wrap(async (req, res) => {
  const name = str(req.body.name, 150);
  if (!name) throw bad('Nom requis');
  const r = await query('INSERT INTO suppliers (company_id, name, phone) VALUES (?,?,?)', [req.user.company_id, name, str(req.body.phone, 40)]);
  await logActivity(req, 'fournisseur', name);
  res.status(201).json({ id: r.insertId });
}));

/* ---------- Journal ---------- */
router.get('/log', adminOnly, wrap(async (req, res) => {
  res.json(await query(
    'SELECT id, by_name AS `by`, type AS ty, detail AS d, t FROM activity_log WHERE company_id=? ORDER BY id DESC LIMIT 100',
    [req.user.company_id]));
}));

module.exports = router;
