'use strict';
// Espace propriétaire : vue d'ensemble des entreprises, blocage, réinitialisation de PIN, accès propriétaire.
const bcrypt = require('bcryptjs');
const express = require('express');
const { query } = require('../db');
const { wrap, int, bad, notFound, ApiError } = require('../util');
const ownerAccount = require('../ownerAccount');
const config = require('../config');
const subscription = require('../subscription');

const router = express.Router();

router.get('/companies', wrap(async (req, res) => {
  const [companies, users, locs] = await Promise.all([
    query('SELECT id, slug, name, addr, gsm, email1, blocked, created_at FROM companies ORDER BY created_at DESC'),
    query('SELECT id, company_id, name, login, role, disabled FROM users ORDER BY id'),
    query('SELECT company_id, name FROM locations WHERE archived = 0 ORDER BY id'),
  ]);
  const subs = await subscription.statuses(companies.map((c) => c.id));
  res.json(companies.map((c) => ({
    sub: subs.get(c.id),
    id: c.id, slug: c.slug, name: c.name, addr: c.addr, gsm: c.gsm, email: c.email1, blocked: !!c.blocked, created_at: c.created_at,
    users: users.filter((u) => u.company_id === c.id).map((u) => ({ id: u.id, name: u.name, login: u.login, role: u.role, disabled: !!u.disabled })),
    locations: locs.filter((l) => l.company_id === c.id).map((l) => l.name),
  })));
}));

router.post('/companies/:id/block', wrap(async (req, res) => {
  const blocked = req.body.blocked ? 1 : 0;
  const r = await query('UPDATE companies SET blocked = ? WHERE id = ?', [blocked, int(req.params.id)]);
  if (!r.affectedRows) throw notFound('Entreprise introuvable');
  res.json({ blocked: !!blocked });
}));

/** Marque l'abonnement de la période due comme payé (7 500 KMF par défaut). */
router.post('/companies/:id/pay', wrap(async (req, res) => {
  const id = int(req.params.id);
  const rows = await query('SELECT id FROM companies WHERE id = ?', [id]);
  if (!rows[0]) throw notFound('Entreprise introuvable');
  const { period } = (await subscription.statuses([id])).get(id);
  const now = Date.now();
  const r = await query('INSERT IGNORE INTO subscription_payments (company_id, period, amount, t) VALUES (?,?,?,?)', [id, period, config.subscriptionPrice, now]);
  if (r.affectedRows) {
    await query('INSERT INTO activity_log (company_id, by_name, type, detail, t) VALUES (?,?,?,?,?)',
      [id, 'Propriétaire', 'abonnement', ('abonnement ' + period + ' payé (' + config.subscriptionPrice + ')').slice(0, 255), now]);
  }
  res.json({ period, paid: true, amount: config.subscriptionPrice });
}));

/** Le PIN existant n'est jamais lisible : le propriétaire en définit un nouveau, à transmettre à l'utilisateur. */
router.post('/users/:id/reset-pin', wrap(async (req, res) => {
  const pin = String(req.body.pin ?? '');
  if (pin.length < 6 || pin.length > 64) throw bad('Le mot de passe doit contenir au moins 6 caractères');
  const id = int(req.params.id);
  const rows = await query('SELECT id, company_id, login FROM users WHERE id = ?', [id]);
  const u = rows[0];
  if (!u) throw notFound('Utilisateur introuvable');
  await query('UPDATE users SET pin_hash = ? WHERE id = ?', [await bcrypt.hash(pin, 10), id]);
  await query('INSERT INTO activity_log (company_id, by_name, type, detail, t) VALUES (?,?,?,?,?)',
    [u.company_id, 'Propriétaire', 'pin', ('réinitialisation du PIN de ' + u.login).slice(0, 255), Date.now()]);
  res.json({ ok: true });
}));

/* ---------- Accès propriétaire ---------- */
router.get('/account', wrap(async (req, res) => {
  res.json(await ownerAccount.currentLogin());
}));

router.put('/account', wrap(async (req, res) => {
  const cur = await ownerAccount.currentLogin();
  if (!(await ownerAccount.verify(cur.login, req.body.currentPin))) throw new ApiError(400, 'PIN actuel incorrect');
  const login = ownerAccount.norm(req.body.login) || cur.login;
  const pin = String(req.body.newPin ?? '');
  if (pin.length < 6 || pin.length > 64) throw bad('Le nouveau PIN doit contenir au moins 6 caractères');
  await ownerAccount.save(login, pin);
  res.json({ login });
}));

module.exports = router;
