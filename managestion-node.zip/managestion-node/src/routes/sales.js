'use strict';
// Ventes, factures, avoirs, crédits clients.
const bcrypt = require('bcryptjs');
const express = require('express');
const { query, tx, q } = require('../db');
const { managerUp, scopeLoc, locFilter } = require('../auth');
const { bad, notFound, forbidden, wrap, str, num, int, logActivity } = require('../util');
const { creditList } = require('../queries');
const promo = require('../promo');

const router = express.Router();
const MODES = ['Espèces', 'MVola', 'Holo', 'Banque', 'Crédit'];
const round2 = (n) => Math.round(n * 100) / 100;
// Hash factice : on compare toujours un mot de passe, même si l'identifiant n'existe pas.
const DUMMY_HASH = bcrypt.hashSync('dummy-pin', 10);

/** Facture complète (en-tête, lignes, avoir éventuel, montant payé). */
async function getSale(cid, id, user) {
  const rows = await query(
    'SELECT s.id, s.no, s.t, s.client, s.mode, s.total, s.by_name AS `by`, s.location_id AS loc, l.name AS locName, ' +
      's.discount, s.customer_id AS customerId, cn.no AS cnNo, cn.reason AS cnReason, cn.t AS cnT ' +
      'FROM sales s JOIN locations l ON l.id = s.location_id LEFT JOIN credit_notes cn ON cn.sale_id = s.id ' +
      'WHERE s.id = ? AND s.company_id = ?',
    [id, cid]);
  const s = rows[0];
  if (!s || (user.role !== 'admin' && s.loc !== user.location_id)) throw notFound('Facture introuvable');
  const lines = await query('SELECT product_id AS id, name, price, qty, list_price AS listPrice, promo_pct AS promoPct FROM sale_lines WHERE sale_id = ? ORDER BY id', [id]);
  const paid = await query('SELECT COALESCE(SUM(amount),0) AS p FROM payments WHERE sale_id = ?', [id]);
  const cancelled = !!s.cnNo;
  return {
    id: s.id, no: s.no, t: s.t, client: s.client, mode: s.mode, total: s.total, discount: s.discount, customerId: s.customerId, by: s.by, loc: s.loc, locName: s.locName,
    lines, cancelled, cnNo: s.cnNo, cnReason: s.cnReason, cnT: s.cnT,
    rest: s.mode === 'Crédit' && !cancelled ? Math.round((s.total - paid[0].p) * 100) / 100 : 0,
  };
}

/* ---------- Nouvelle vente ---------- */
router.post('/sales', wrap(async (req, res) => {
  const cid = req.user.company_id;
  const raw = Array.isArray(req.body.lines) ? req.body.lines : [];
  if (!raw.length) throw bad('Le panier est vide');
  if (raw.length > 200) throw bad('Trop de lignes');
  // Quantités regroupées par produit ; les prix viennent toujours de la base, jamais du navigateur
  const want = new Map();
  for (const l of raw) {
    const pid = int(l.productId);
    const qty = int(l.qty);
    if (!pid || !(qty > 0)) throw bad('Ligne de vente invalide');
    want.set(pid, (want.get(pid) || 0) + qty);
  }
  const mode = req.body.mode;
  if (!MODES.includes(mode)) throw bad('Mode de paiement invalide');
  const clientName = str(req.body.client, 150);
  const customerId = int(req.body.customerId) || null;
  const discount = round2(Math.max(0, num(req.body.discount)));
  if (mode === 'Crédit' && !clientName && !customerId) throw bad('Client requis pour un crédit');
  let client = clientName || 'Client comptoir';
  const scope = await scopeLoc(req, { single: true });

  const saleId = await tx(async (conn) => {
    if (customerId) {
      const cu = await q(conn, 'SELECT id, name FROM customers WHERE id=? AND company_id=? AND deleted=0', [customerId, cid]);
      if (!cu[0]) throw bad('Client introuvable');
      client = cu[0].name;
    }
    // 1) verrou de l'emplacement : numérotation des factures sans trou ni doublon
    const lr = await q(conn, 'SELECT id, code, seq FROM locations WHERE id=? AND company_id=? FOR UPDATE', [scope.id, cid]);
    if (!lr[0]) throw bad('Emplacement inconnu');
    const seq = lr[0].seq + 1;
    await q(conn, 'UPDATE locations SET seq=? WHERE id=?', [seq, scope.id]);
    const no = 'FAC-' + lr[0].code + '-' + String(seq).padStart(4, '0');

    // 2) verrou des produits (ordre croissant) puis contrôle du stock
    const ids = [...want.keys()].sort((a, b) => a - b);
    const now = Date.now();
    const prods = await q(conn, 'SELECT id, name, buy, price, promo_pct, promo_from, promo_to FROM products WHERE company_id=? AND deleted=0 AND id IN (?) ORDER BY id FOR UPDATE', [cid, ids]);
    if (prods.length !== ids.length) throw bad('Un produit du panier n\'existe plus');
    const st = await q(conn,
      'SELECT product_id, COALESCE(SUM(qty),0) AS s FROM stock_moves WHERE company_id=? AND location_id=? AND product_id IN (?) GROUP BY product_id',
      [cid, scope.id, ids]);
    const have = new Map(st.map((r) => [r.product_id, r.s]));
    let total = 0;
    for (const p of prods) {
      const qty = want.get(p.id);
      const h = have.get(p.id) || 0;
      if (qty > h) throw bad('Stock insuffisant pour « ' + p.name + ' » (' + h + ' disponible)');
      // prix du moment : prix réduit si une promotion est en cours (relu dans la base, jamais envoyé par le navigateur)
      p.unit = promo.salePrice(p, now);
      p.pct = promo.isActive(p, now) ? promo.pctOf(p) : 0;
      total += qty * p.unit;
    }
    total = round2(total);
    if (discount > total) throw bad('La remise dépasse le total de la vente');
    const net = round2(total - discount);

    // 3) enregistrement
    const r = await q(conn, 'INSERT INTO sales (company_id, location_id, customer_id, no, client, mode, discount, total, by_name, t) VALUES (?,?,?,?,?,?,?,?,?,?)',
      [cid, scope.id, customerId, no, client, mode, discount, net, req.user.name, now]);
    await q(conn, 'INSERT INTO sale_lines (sale_id, product_id, name, price, buy, qty, list_price, promo_pct) VALUES ?',
      [prods.map((p) => [r.insertId, p.id, p.name, p.unit, p.buy, want.get(p.id), p.price, p.pct])]);
    await q(conn, 'INSERT INTO stock_moves (company_id, product_id, location_id, qty, why, by_name, t) VALUES ?',
      [prods.map((p) => [cid, p.id, scope.id, -want.get(p.id), no, req.user.name, now])]);
    await logActivity(req, 'sale', no + (discount > 0 ? ' (remise ' + discount + ')' : ''), conn);
    return r.insertId;
  });
  res.status(201).json(await getSale(cid, saleId, req.user));
}));

/* ---------- Historique ---------- */
router.get('/sales', managerUp, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const scope = await scopeLoc(req);
  const f = locFilter(scope, 's.location_id');
  const limit = Math.min(500, Math.max(1, int(req.query.limit, 200)));
  const offset = Math.max(0, int(req.query.offset, 0));
  const search = str(req.query.q, 80);
  let where = 's.company_id = ?' + f.sql;
  const params = [cid, ...f.params];
  if (search) {
    const like = '%' + search.replace(/[\\%_]/g, '\\$&') + '%';
    where += ' AND (s.no LIKE ? OR s.client LIKE ?)';
    params.push(like, like);
  }
  const rows = await query(
    'SELECT s.id, s.no, s.t, s.client, s.mode, s.total, s.by_name AS `by`, s.location_id AS loc, l.name AS locName, ' +
      '(cn.id IS NOT NULL) AS cancelled, ' +
      "CASE WHEN s.mode = 'Crédit' AND cn.id IS NULL THEN s.total - COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.sale_id = s.id), 0) ELSE 0 END AS rest " +
      'FROM sales s JOIN locations l ON l.id = s.location_id LEFT JOIN credit_notes cn ON cn.sale_id = s.id ' +
      'WHERE ' + where + ' ORDER BY s.t DESC, s.id DESC LIMIT ? OFFSET ?',
    [...params, limit, offset]);
  res.json(rows.map((r) => ({ ...r, cancelled: !!r.cancelled })));
}));

router.get('/sales/:id', wrap(async (req, res) => {
  res.json(await getSale(req.user.company_id, int(req.params.id), req.user));
}));

/* ---------- Avoirs ---------- */
router.get('/credit-notes', managerUp, wrap(async (req, res) => {
  const scope = await scopeLoc(req);
  const f = locFilter(scope, 'location_id');
  res.json(await query(
    'SELECT id, no, t, sale_id, sale_no AS sno, total, refund, reason FROM credit_notes WHERE company_id = ?' + f.sql + ' ORDER BY id DESC LIMIT 200',
    [req.user.company_id, ...f.params]));
}));

/**
 * Vérifie l'identifiant et le mot de passe saisis pour autoriser une annulation.
 * Seul le gérant de l'emplacement de la vente (ou un administrateur) peut l'autoriser.
 * Une erreur renvoie 403 (jamais 401, qui déconnecterait la personne devant la caisse).
 */
async function cancelAuthorizer(cid, locId, loginRaw, password) {
  const login = str(loginRaw, 60).toLowerCase().replace(/\s+/g, ' ');
  if (!login || !password) throw bad('Identifiant et mot de passe du gérant requis pour annuler');
  const rows = await query('SELECT id, name, login, pin_hash, role, location_id, disabled FROM users WHERE company_id=? AND login=?', [cid, login]);
  const u = rows[0];
  const ok = await bcrypt.compare(password, u ? u.pin_hash : DUMMY_HASH);
  if (!u || !ok || u.disabled) throw forbidden('Identifiant ou mot de passe incorrect');
  if (!(u.role === 'admin' || (u.role === 'gérant' && u.location_id === locId))) {
    throw forbidden('Seul le gérant de cet emplacement (ou l\'administrateur) peut annuler cette vente');
  }
  return u;
}

router.post('/sales/:id/credit-note', wrap(async (req, res) => {
  const cid = req.user.company_id;
  const id = int(req.params.id);
  const reason = str(req.body.reason, 255);

  const head = await query('SELECT id, location_id FROM sales WHERE id=? AND company_id=?', [id, cid]);
  if (!head[0] || (req.user.role !== 'admin' && head[0].location_id !== req.user.location_id)) throw notFound('Facture introuvable');
  const boss = await cancelAuthorizer(cid, head[0].location_id, req.body.login, String(req.body.password ?? ''));

  const no = await tx(async (conn) => {
    const rows = await q(conn, 'SELECT id, no, mode, total, location_id FROM sales WHERE id=? AND company_id=? FOR UPDATE', [id, cid]);
    const s = rows[0];
    if (!s) throw notFound('Facture introuvable');
    const ex = await q(conn, 'SELECT id FROM credit_notes WHERE sale_id=?', [id]);
    if (ex[0]) throw bad('Cette facture est déjà annulée');

    const cr = await q(conn, 'SELECT credit_note_seq FROM companies WHERE id=? FOR UPDATE', [cid]);
    const seq = cr[0].credit_note_seq + 1;
    await q(conn, 'UPDATE companies SET credit_note_seq=? WHERE id=?', [seq, cid]);
    const cnNo = 'AVR-' + String(seq).padStart(4, '0');

    let refund = s.total;
    if (s.mode === 'Crédit') {
      const p = await q(conn, 'SELECT COALESCE(SUM(amount),0) AS p FROM payments WHERE sale_id=?', [id]);
      refund = p[0].p;
    }
    const now = Date.now();
    // L'avoir est signé par le gérant qui l'a autorisé
    await q(conn, 'INSERT INTO credit_notes (company_id, location_id, sale_id, no, sale_no, total, refund, reason, by_name, t) VALUES (?,?,?,?,?,?,?,?,?,?)',
      [cid, s.location_id, id, cnNo, s.no, s.total, refund, reason, boss.name, now]);
    const lines = await q(conn, 'SELECT product_id, qty FROM sale_lines WHERE sale_id=?', [id]);
    if (lines.length) {
      await q(conn, 'INSERT INTO stock_moves (company_id, product_id, location_id, qty, why, by_name, t) VALUES ?',
        [lines.map((l) => [cid, l.product_id, s.location_id, l.qty, cnNo, boss.name, now])]);
    }
    await logActivity(req, 'avoir', cnNo + ' (' + s.no + ') autorisé par ' + boss.name + ' (@' + boss.login + ')', conn);
    return cnNo;
  });
  res.status(201).json({ no });
}));

/* ---------- Crédits clients ---------- */
router.get('/credits', wrap(async (req, res) => {
  const scope = await scopeLoc(req);
  const list = await creditList(req.user.company_id, scope);
  res.json({ list, due: list.reduce((a, s) => a + s.rest, 0) });
}));

router.post('/credits/:saleId/pay', wrap(async (req, res) => {
  const cid = req.user.company_id;
  const id = int(req.params.saleId);
  const wanted = num(req.body.amount);
  const amount = await tx(async (conn) => {
    const rows = await q(conn, 'SELECT id, no, mode, total, location_id FROM sales WHERE id=? AND company_id=? FOR UPDATE', [id, cid]);
    const s = rows[0];
    if (!s || s.mode !== 'Crédit') throw notFound('Crédit introuvable');
    if (req.user.role !== 'admin' && s.location_id !== req.user.location_id) throw forbidden('Ce crédit appartient à un autre emplacement');
    const cn = await q(conn, 'SELECT id FROM credit_notes WHERE sale_id=?', [id]);
    if (cn[0]) throw bad('Facture annulée');
    const p = await q(conn, 'SELECT COALESCE(SUM(amount),0) AS p FROM payments WHERE sale_id=?', [id]);
    const rest = Math.round((s.total - p[0].p) * 100) / 100;
    const a = Math.round(Math.min(wanted, rest) * 100) / 100;
    if (!(a > 0)) throw bad('Montant invalide');
    await q(conn, 'INSERT INTO payments (company_id, sale_id, location_id, no, amount, by_name, t) VALUES (?,?,?,?,?,?,?)',
      [cid, id, s.location_id, s.no, a, req.user.name, Date.now()]);
    await logActivity(req, 'pay', s.no, conn);
    return a;
  });
  res.status(201).json({ amount });
}));

module.exports = router;
