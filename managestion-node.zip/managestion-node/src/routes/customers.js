'use strict';
// Fichier clients : fiches, historique d'achats, solde de crédit.
const express = require('express');
const { query } = require('../db');
const { adminOnly, scopeLoc, locFilter } = require('../auth');
const { bad, notFound, wrap, str, int, logActivity } = require('../util');

const router = express.Router();

router.get('/customers', wrap(async (req, res) => {
  const cid = req.user.company_id;
  const search = str(req.query.q, 80);
  let where = 'c.company_id = ? AND c.deleted = 0';
  const params = [cid, cid];
  if (search) {
    const like = '%' + search.replace(/[\\%_]/g, '\\$&') + '%';
    where += ' AND (c.name LIKE ? OR c.phone LIKE ?)';
    params.push(like, like);
  }
  const rows = await query(
    'SELECT c.id, c.name, c.phone, c.addr, c.note, COALESCE(st.n, 0) AS purchases, COALESCE(st.spent, 0) AS spent, COALESCE(st.due, 0) AS due ' +
      'FROM customers c LEFT JOIN (' +
        'SELECT x.customer_id, COUNT(*) AS n, SUM(x.total) AS spent, SUM(x.rest) AS due FROM (' +
          'SELECT s.customer_id, s.total, ' +
            "CASE WHEN s.mode = 'Crédit' THEN s.total - COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.sale_id = s.id), 0) ELSE 0 END AS rest " +
          'FROM sales s LEFT JOIN credit_notes cn ON cn.sale_id = s.id ' +
          'WHERE s.company_id = ? AND s.customer_id IS NOT NULL AND cn.id IS NULL' +
        ') x GROUP BY x.customer_id' +
      ') st ON st.customer_id = c.id ' +
      'WHERE ' + where + ' ORDER BY c.name LIMIT 500',
    params);
  res.json(rows);
}));

router.post('/customers', wrap(async (req, res) => {
  const name = str(req.body.name, 150);
  if (!name) throw bad('Nom du client requis');
  const r = await query('INSERT INTO customers (company_id, name, phone, addr, note, created_at) VALUES (?,?,?,?,?,?)',
    [req.user.company_id, name, str(req.body.phone, 40), str(req.body.addr, 255), str(req.body.note, 255), Date.now()]);
  await logActivity(req, 'client', name);
  res.status(201).json({ id: r.insertId, name });
}));

router.put('/customers/:id', adminOnly, wrap(async (req, res) => {
  const name = str(req.body.name, 150);
  if (!name) throw bad('Nom du client requis');
  const r = await query('UPDATE customers SET name=?, phone=?, addr=?, note=? WHERE id=? AND company_id=? AND deleted=0',
    [name, str(req.body.phone, 40), str(req.body.addr, 255), str(req.body.note, 255), int(req.params.id), req.user.company_id]);
  if (!r.affectedRows) throw notFound('Client introuvable');
  await logActivity(req, 'client', name);
  res.json({ ok: true });
}));

router.delete('/customers/:id', adminOnly, wrap(async (req, res) => {
  const r = await query('UPDATE customers SET deleted=1 WHERE id=? AND company_id=?', [int(req.params.id), req.user.company_id]);
  if (!r.affectedRows) throw notFound('Client introuvable');
  await logActivity(req, 'client', 'archivé ' + req.params.id);
  res.json({ ok: true });
}));

/** Fiche client avec l'historique de ses achats (un gérant ou un employé ne voit que ceux de son emplacement). */
router.get('/customers/:id', wrap(async (req, res) => {
  const cid = req.user.company_id;
  const id = int(req.params.id);
  const rows = await query('SELECT id, name, phone, addr, note FROM customers WHERE id=? AND company_id=? AND deleted=0', [id, cid]);
  if (!rows[0]) throw notFound('Client introuvable');
  const scope = await scopeLoc(req);
  const f = locFilter(scope, 's.location_id');
  const sales = await query(
    'SELECT s.id, s.no, s.t, s.mode, s.total, (cn.id IS NOT NULL) AS cancelled, ' +
      "CASE WHEN s.mode = 'Crédit' AND cn.id IS NULL THEN s.total - COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.sale_id = s.id), 0) ELSE 0 END AS rest " +
      'FROM sales s LEFT JOIN credit_notes cn ON cn.sale_id = s.id ' +
      'WHERE s.company_id = ? AND s.customer_id = ?' + f.sql + ' ORDER BY s.t DESC, s.id DESC LIMIT 100',
    [cid, id, ...f.params]);
  res.json({ ...rows[0], sales: sales.map((s) => ({ ...s, cancelled: !!s.cancelled })) });
}));

module.exports = router;
