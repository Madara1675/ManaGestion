'use strict';
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const express = require('express');
const config = require('../config');
const { query, tx, q } = require('../db');
const { setSession, clearSession, readToken, authUser } = require('../auth');
const { bad, ApiError, wrap, str, logActivity, locCode } = require('../util');
const { sessionData } = require('../models');
const ownerAccount = require('../ownerAccount');

const router = express.Router();

const normLogin = (s) => str(s, 60).toLowerCase().replace(/\s+/g, ' ');
// Hash factice : on compare toujours un mot de passe, même si l'identifiant n'existe pas (évite de révéler quels comptes existent).
const DUMMY_HASH = bcrypt.hashSync('dummy-pin', 10);
const LOGO_RE = /^data:image\/(png|jpe?g|gif|webp|svg\+xml);base64,[A-Za-z0-9+/=]+$/;

router.post('/login', wrap(async (req, res) => {
  const slug = str(req.body.slug, 40).toLowerCase();
  const login = normLogin(req.body.login);
  const pin = String(req.body.pin ?? '');
  if (!login || !pin) throw bad('Identifiant et mot de passe requis');

  // Accès propriétaire : mêmes champs que la connexion normale (le code entreprise est ignoré)
  if ((await ownerAccount.enabled()) && (await ownerAccount.verify(login, pin))) {
    setSession(req, res, { owner: true });
    return res.json({ owner: true });
  }
  if (!slug) throw new ApiError(401, 'Entreprise, identifiant ou mot de passe incorrect');

  const rows = await query(
    'SELECT u.id, u.company_id, u.name, u.login, u.pin_hash, u.role, u.location_id, u.disabled, c.blocked ' +
      'FROM users u JOIN companies c ON c.id = u.company_id WHERE c.slug = ? AND u.login = ?',
    [slug, login]
  );
  const u = rows[0];
  const ok = await bcrypt.compare(pin, u ? u.pin_hash : DUMMY_HASH);
  if (!u || !ok) throw new ApiError(401, 'Entreprise, identifiant ou mot de passe incorrect');
  if (u.blocked) throw new ApiError(403, 'Compte bloqué. Contactez ManaGestion.');
  if (u.disabled) throw new ApiError(403, 'Compte désactivé. Contactez l\'administrateur.');

  setSession(req, res, { uid: u.id, cid: u.company_id });
  req.user = { company_id: u.company_id, name: u.name };
  await logActivity(req, 'connexion', '');

  if (u.role !== 'admin' && !u.location_id) {
    const l = await query('SELECT id FROM locations WHERE company_id = ? AND archived = 0 ORDER BY id LIMIT 1', [u.company_id]);
    u.location_id = l[0] ? l[0].id : null;
  }
  res.json(await sessionData(u));
}));

router.post('/register', wrap(async (req, res) => {
  if (!config.allowRegistration) throw new ApiError(403, 'La création d\'entreprise est désactivée');
  const c = req.body.company || {};
  const a = req.body.admin || {};
  const name = str(c.name, 150);
  const email1 = str(c.email1, 150);
  const adminName = str(a.name, 100);
  const adminLogin = normLogin(a.login);
  const pin = String(a.pin ?? '');

  if (!name || !email1 || !adminName || !adminLogin) throw bad('Remplissez les champs obligatoires (*)');
  if (!/^\S+@\S+\.\S+$/.test(email1)) throw bad('Adresse email invalide');
  if (pin.length < 6 || pin.length > 64) throw bad('Le mot de passe doit contenir au moins 6 caractères');
  const logo = str(c.logo, 500000);
  if (logo && !LOGO_RE.test(logo)) throw bad('Logo invalide');

  const pinHash = await bcrypt.hash(pin, 10);
  const now = Date.now();
  // Code de connexion de l'entreprise : généré à partir du nom, rendu unique si besoin
  let base = name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30).replace(/-+$/, '');
  if (base.length < 3) base = (base + 'ent').slice(0, 3);
  let slug = base;
  for (let i = 0; i < 20 && (await query('SELECT id FROM companies WHERE slug = ?', [slug])).length; i++) {
    slug = base + '-' + (1000 + crypto.randomInt(9000));
  }
  let user;
  try {
    user = await tx(async (conn) => {
      const r1 = await q(conn,
        'INSERT INTO companies (slug, name, addr, email1, logo, created_at) VALUES (?,?,?,?,?,?)',
        [slug, name, str(c.addr, 255), email1, logo || null, now]);
      const cid = r1.insertId;
      const locName = 'Magasin principal';
      await q(conn, 'INSERT INTO locations (company_id, name, type, addr, code) VALUES (?,?,?,?,?)',
        [cid, locName, 'magasin', '', locCode(name, new Set())]);
      const r2 = await q(conn,
        'INSERT INTO users (company_id, name, login, pin_hash, role, created_at) VALUES (?,?,?,?,?,?)',
        [cid, adminName, adminLogin, pinHash, 'admin', now]);
      return { id: r2.insertId, company_id: cid, name: adminName, login: adminLogin, role: 'admin', location_id: null };
    });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new ApiError(409, 'Ce code entreprise est déjà utilisé : choisissez-en un autre');
    throw e;
  }
  setSession(req, res, { uid: user.id, cid: user.company_id });
  req.user = user;
  await logActivity(req, 'entreprise', 'création');
  res.status(201).json(await sessionData(user));
}));

router.post('/logout', (req, res) => {
  clearSession(res);
  res.json({ ok: true });
});

router.get('/session', wrap(async (req, res, next) => {
  const p = readToken(req);
  if (p && p.owner && (await ownerAccount.enabled())) return res.json({ owner: true });
  next();
}), authUser, wrap(async (req, res) => {
  res.json(await sessionData(req.user));
}));

module.exports = router;
