'use strict';
// Import de produits (CSV) et inventaire physique (comptage du stock réel).
const express = require('express');
const { query, tx, q } = require('../db');
const { adminOnly, scopeLoc } = require('../auth');
const { bad, notFound, wrap, str, num, int, logActivity } = require('../util');

const router = express.Router();

async function firstActiveLoc(conn, cid) {
  const rows = await q(conn, 'SELECT id FROM locations WHERE company_id=? AND archived=0 ORDER BY id LIMIT 1', [cid]);
  if (!rows[0]) throw bad('Aucun emplacement actif');
  return rows[0].id;
}

/* ---------- Import de produits ---------- */
// Le fichier est lu dans le navigateur ; le serveur reçoit les lignes déjà découpées.
// Un produit dont le code-barres existe déjà est mis à jour (nom, prix, seuil). Son stock n'est PAS modifié : utilisez l'inventaire.
router.post('/products/import', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const rows = Array.isArray(req.body.rows) ? req.body.rows : [];
  if (!rows.length) throw bad('Aucune ligne à importer');
  if (rows.length > 2000) throw bad('Maximum 2000 lignes par import');
  const scope = await scopeLoc(req);

  const out = await tx(async (conn) => {
    const loc = scope.all ? await firstActiveLoc(conn, cid) : scope.id;
    const existing = await q(conn, "SELECT id, code FROM products WHERE company_id=? AND deleted=0 AND code<>''", [cid]);
    const byCode = new Map(existing.map((p) => [p.code, p.id]));
    let created = 0, updated = 0, stocked = 0;
    const skipped = [];
    const now = Date.now();
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i] || {};
      const line = i + 2; // ligne 1 = en-têtes du fichier
      const name = str(r.name, 150);
      const price = r.price === '' || r.price === null || r.price === undefined ? NaN : num(r.price, NaN);
      if (!name) { skipped.push({ line, reason: 'Nom manquant' }); continue; }
      if (!(price >= 0)) { skipped.push({ line, reason: 'Prix de vente manquant ou invalide' }); continue; }
      const code = str(r.code, 80);
      const buy = Math.max(0, num(r.buy));
      const min = r.min === '' || r.min === null || r.min === undefined ? 5 : Math.max(0, int(r.min));
      const qty = Math.max(0, int(r.qty));
      if (code && byCode.has(code)) {
        await q(conn, 'UPDATE products SET name=?, buy=?, price=?, min_stock=? WHERE id=? AND company_id=?', [name, buy, price, min, byCode.get(code), cid]);
        updated++;
        continue;
      }
      const ins = await q(conn, 'INSERT INTO products (company_id, name, code, buy, price, min_stock) VALUES (?,?,?,?,?,?)', [cid, name, code, buy, price, min]);
      created++;
      if (code) byCode.set(code, ins.insertId);
      if (qty > 0) {
        await q(conn, 'INSERT INTO stock_moves (company_id, product_id, location_id, qty, why, by_name, t) VALUES (?,?,?,?,?,?,?)',
          [cid, ins.insertId, loc, qty, 'import', req.user.name, now]);
        stocked++;
      }
    }
    await logActivity(req, 'import', created + ' créés, ' + updated + ' mis à jour, ' + skipped.length + ' ignorés', conn);
    return { created, updated, stocked, skippedCount: skipped.length, skipped: skipped.slice(0, 30) };
  });
  res.status(201).json(out);
}));

/* ---------- Inventaire physique ---------- */
router.get('/inventory', adminOnly, wrap(async (req, res) => {
  res.json(await query(
    'SELECT sc.id, sc.t, sc.by_name AS `by`, sc.note, l.name AS locName, ' +
      'COALESCE(SUM(CASE WHEN scl.counted <> scl.expected THEN 1 ELSE 0 END), 0) AS diffs, ' +
      'COALESCE(SUM((scl.counted - scl.expected) * scl.buy), 0) AS value, COUNT(scl.id) AS nlines ' +
      'FROM stock_counts sc JOIN locations l ON l.id = sc.location_id LEFT JOIN stock_count_lines scl ON scl.count_id = sc.id ' +
      'WHERE sc.company_id = ? GROUP BY sc.id, l.name ORDER BY sc.id DESC LIMIT 50',
    [req.user.company_id]));
}));

router.get('/inventory/:id', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const id = int(req.params.id);
  const head = await query(
    'SELECT sc.id, sc.t, sc.by_name AS `by`, sc.note, l.name AS locName FROM stock_counts sc JOIN locations l ON l.id = sc.location_id WHERE sc.id = ? AND sc.company_id = ?',
    [id, cid]);
  if (!head[0]) throw notFound('Inventaire introuvable');
  const lines = await query('SELECT product_id AS id, name, expected, counted, buy FROM stock_count_lines WHERE count_id = ? ORDER BY name', [id]);
  res.json({ ...head[0], lines });
}));

// Seuls les produits renseignés sont comptés. Le stock attendu est relu dans la base au moment de la validation,
// et chaque écart devient un mouvement de stock « inventaire #N ».
router.post('/inventory', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const raw = Array.isArray(req.body.counts) ? req.body.counts : [];
  if (!raw.length) throw bad('Renseignez la quantité comptée d\'au moins un produit');
  if (raw.length > 5000) throw bad('Trop de lignes');
  const counted = new Map();
  for (const c of raw) {
    const pid = int(c.productId);
    const n = Number(c.counted);
    if (!pid || !Number.isFinite(n) || n < 0 || !Number.isInteger(n)) throw bad('Quantité comptée invalide');
    counted.set(pid, n);
  }
  const scope = await scopeLoc(req, { single: true });
  const note = str(req.body.note, 255);

  const out = await tx(async (conn) => {
    const ids = [...counted.keys()].sort((a, b) => a - b);
    const prods = await q(conn, 'SELECT id, name, buy FROM products WHERE company_id=? AND deleted=0 AND id IN (?) ORDER BY id FOR UPDATE', [cid, ids]);
    if (prods.length !== ids.length) throw bad('Un produit de la liste n\'existe plus');
    const st = await q(conn,
      'SELECT product_id, COALESCE(SUM(qty),0) AS s FROM stock_moves WHERE company_id=? AND location_id=? AND product_id IN (?) GROUP BY product_id',
      [cid, scope.id, ids]);
    const have = new Map(st.map((r) => [r.product_id, r.s]));
    const now = Date.now();
    const head = await q(conn, 'INSERT INTO stock_counts (company_id, location_id, note, by_name, t) VALUES (?,?,?,?,?)', [cid, scope.id, note, req.user.name, now]);
    const lines = prods.map((p) => [head.insertId, p.id, p.name, have.get(p.id) || 0, counted.get(p.id), p.buy]);
    await q(conn, 'INSERT INTO stock_count_lines (count_id, product_id, name, expected, counted, buy) VALUES ?', [lines]);
    const moves = lines.filter((l) => l[4] !== l[3]).map((l) => [cid, l[1], scope.id, l[4] - l[3], 'inventaire #' + head.insertId, req.user.name, now]);
    if (moves.length) await q(conn, 'INSERT INTO stock_moves (company_id, product_id, location_id, qty, why, by_name, t) VALUES ?', [moves]);
    await logActivity(req, 'inventaire', '#' + head.insertId + ' : ' + moves.length + ' écart(s) corrigé(s)', conn);
    return { id: head.insertId, counted: lines.length, differences: moves.length };
  });
  res.status(201).json(out);
}));

module.exports = router;
