'use strict';
// Tableau de bord, trésorerie, rapports, exports CSV et sauvegarde.
const express = require('express');
const { query } = require('../db');
const { adminOnly, scopeLoc, locFilter } = require('../auth');
const { bad, wrap, int, range, toCsv, logActivity } = require('../util');
const { creditList, stockValue, supplierBalances } = require('../queries');
const { getCompany, getLocations } = require('../models');
const promo = require('../promo');

const router = express.Router();

/** jj/mm/aaaa selon le fuseau du navigateur (tz = Date.getTimezoneOffset()). */
function fmtDate(t, tz) {
  const d = new Date(t - tz * 60000);
  const p = (n) => String(n).padStart(2, '0');
  return p(d.getUTCDate()) + '/' + p(d.getUTCMonth() + 1) + '/' + d.getUTCFullYear();
}

/* ---------- Tableau de bord ---------- */
router.get('/dashboard', wrap(async (req, res) => {
  const cid = req.user.company_id;
  const isAdmin = req.user.role === 'admin';
  const scope = await scopeLoc(req);
  const since = int(req.query.since, 0);
  if (!since) throw bad('Paramètre "since" requis');

  const fs = locFilter(scope, 'location_id');
  const [sales, notes, products, credits] = await Promise.all([
    query('SELECT COALESCE(SUM(total),0) AS v FROM sales WHERE company_id=? AND t>=?' + fs.sql, [cid, since, ...fs.params]),
    query('SELECT COALESCE(SUM(total),0) AS v FROM credit_notes WHERE company_id=? AND t>=?' + fs.sql, [cid, since, ...fs.params]),
    query('SELECT COUNT(*) AS n FROM products WHERE company_id=? AND deleted=0', [cid]),
    creditList(cid, scope),
  ]);

  const fm = locFilter(scope, 'location_id');
  const low = await query(
    'SELECT p.id, p.name, p.min_stock AS `min`, COALESCE(s.q,0) AS stock FROM products p ' +
      'LEFT JOIN (SELECT product_id, SUM(qty) AS q FROM stock_moves WHERE company_id=?' + fm.sql + ' GROUP BY product_id) s ON s.product_id = p.id ' +
      'WHERE p.company_id=? AND p.deleted=0 AND COALESCE(s.q,0) <= p.min_stock ORDER BY p.name',
    [cid, ...fm.params, cid]);

  const out = {
    today: sales[0].v - notes[0].v,
    products: products[0].n,
    creditsDue: credits.reduce((a, s) => a + s.rest, 0),
    low,
  };
  if (isAdmin) {
    out.stockValue = (await stockValue(cid, scope)).buyv;
    out.suppliersDue = (await supplierBalances(cid)).reduce((a, b) => a + b.due, 0);
  }
  res.json(out);
}));

/* ---------- Trésorerie (admin) ---------- */
router.get('/cash', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const { from, to } = range(req);
  const scope = await scopeLoc(req);
  const fl = locFilter(scope, 'location_id');
  const fm = locFilter(scope, 'm.location_id');
  const rows = [];

  const sales = await query("SELECT t, no, mode, total FROM sales WHERE company_id=? AND mode<>'Crédit' AND t>=? AND t<?" + fl.sql, [cid, from, to, ...fl.params]);
  sales.forEach((s) => rows.push({ t: s.t, label: 'Vente ' + s.no + ' (' + s.mode + ')', amount: s.total, kind: 'in' }));

  const pays = await query('SELECT t, no, amount FROM payments WHERE company_id=? AND t>=? AND t<?' + fl.sql, [cid, from, to, ...fl.params]);
  pays.forEach((p) => rows.push({ t: p.t, label: 'Règlement crédit ' + p.no, amount: p.amount, kind: 'in' }));

  const notes = await query('SELECT t, no, refund FROM credit_notes WHERE company_id=? AND refund>0 AND t>=? AND t<?' + fl.sql, [cid, from, to, ...fl.params]);
  notes.forEach((n) => rows.push({ t: n.t, label: 'Remboursement ' + n.no, amount: n.refund, kind: 'out' }));

  const buys = await query(
    'SELECT m.t, m.cost, m.supplier, p.name FROM stock_moves m JOIN products p ON p.id = m.product_id ' +
      'WHERE m.company_id=? AND m.cost>0 AND m.t>=? AND m.t<?' + fm.sql, [cid, from, to, ...fm.params]);
  buys.forEach((b) => rows.push({ t: b.t, label: 'Achat stock : ' + b.name + (b.supplier ? ' (' + b.supplier + ')' : ''), amount: b.cost, kind: 'out' }));

  const supPays = await query(
    'SELECT sp.t, sp.amount, su.name FROM supplier_payments sp JOIN suppliers su ON su.id = sp.supplier_id ' +
      'WHERE sp.company_id=? AND sp.t>=? AND sp.t<?' + fl.sql.replace('location_id', 'sp.location_id'), [cid, from, to, ...fl.params]);
  supPays.forEach((p) => rows.push({ t: p.t, label: 'Paiement fournisseur : ' + p.name, amount: p.amount, kind: 'out' }));

  // Les opérations "entreprise" (sans emplacement) n'apparaissent que dans la vue "Tous les emplacements"
  const entries = await query('SELECT t, label, amount, kind FROM cash_entries WHERE company_id=? AND t>=? AND t<?' + fl.sql, [cid, from, to, ...fl.params]);
  entries.forEach((e) => rows.push({ t: e.t, label: e.label, amount: e.amount, kind: e.kind === 'in' ? 'in' : 'out' }));

  rows.sort((a, b) => a.t - b.t);
  const sum = (k) => rows.filter((r) => r.kind === k).reduce((a, r) => a + r.amount, 0);
  res.json({ rows, totalIn: sum('in'), totalOut: sum('out') });
}));

router.post('/cash', adminOnly, wrap(async (req, res) => {
  const label = String(req.body.label ?? '').trim().slice(0, 200);
  const amount = Number(req.body.amount);
  if (!label || !(amount > 0)) throw bad('Libellé et montant requis');
  const scope = await scopeLoc(req);
  await query('INSERT INTO cash_entries (company_id, location_id, label, amount, kind, by_name, t) VALUES (?,?,?,?,?,?,?)',
    [req.user.company_id, scope.all ? null : scope.id, label, amount, req.body.kind === 'in' ? 'in' : 'out', req.user.name, Date.now()]);
  await logActivity(req, 'cash', label);
  res.status(201).json({ ok: true });
}));

/* ---------- Rapports (admin) ---------- */
router.get('/reports', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const { from, to } = range(req);
  const scope = await scopeLoc(req);
  const f = locFilter(scope, 's.location_id');
  const base =
    'FROM sale_lines sl JOIN sales s ON s.id = sl.sale_id LEFT JOIN credit_notes cn ON cn.sale_id = s.id ' +
    'WHERE s.company_id = ? AND s.t >= ? AND s.t < ? AND cn.id IS NULL' + f.sql;
  const params = [cid, from, to, ...f.params];
  const [tot, top, sv, credits, disc] = await Promise.all([
    query('SELECT COALESCE(SUM(sl.price * sl.qty),0) AS rev, COALESCE(SUM(sl.buy * sl.qty),0) AS cost ' + base, params),
    query('SELECT sl.name, SUM(sl.qty) AS q, SUM(sl.price * sl.qty) AS a ' + base + ' GROUP BY sl.name ORDER BY a DESC LIMIT 5', params),
    stockValue(cid, scope),
    creditList(cid, scope),
    query(
      'SELECT COALESCE(SUM(s.discount), 0) AS d FROM sales s LEFT JOIN credit_notes cn ON cn.sale_id = s.id ' +
        'WHERE s.company_id = ? AND s.t >= ? AND s.t < ? AND cn.id IS NULL' + f.sql, params),
  ]);
  res.json({
    rev: tot[0].rev - disc[0].d,
    discounts: disc[0].d,
    cost: tot[0].cost,
    top,
    stockBuy: sv.buyv,
    stockSell: sv.sellv,
    creditsDue: credits.reduce((a, s) => a + s.rest, 0),
  });
}));

/* ---------- Exports CSV (admin) ---------- */
function sendCsv(res, name, rows) {
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="' + name + '.csv"');
  res.send(toCsv(rows));
}
const fileBase = (req, k) => (req.user.slug || 'export') + '_' + k;

router.get('/export/:kind.csv', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const tz = int(req.query.tz, 0);
  const scope = await scopeLoc(req);
  const kind = req.params.kind;

  if (kind === 'products') {
    const f = locFilter(scope, 'm.location_id');
    const rows = await query(
      'SELECT p.name, p.code, p.buy, p.price, p.promo_pct, p.promo_from, p.promo_to, COALESCE(SUM(m.qty),0) AS stock FROM products p ' +
        'LEFT JOIN stock_moves m ON m.product_id = p.id' + f.sql + ' WHERE p.company_id=? AND p.deleted=0 GROUP BY p.id ORDER BY p.name',
      [...f.params, cid]);
    const now = Date.now();
    return sendCsv(res, fileBase(req, kind), [['Produit', 'Code', 'Achat', 'Vente', 'Promo %', 'Prix promo', 'Stock'],
      ...rows.map((p) => [p.name, p.code, p.buy, p.price, promo.isActive(p, now) ? promo.pctOf(p) : 0, promo.salePrice(p, now), p.stock])]);
  }
  if (kind === 'sales') {
    const f = locFilter(scope, 's.location_id');
    const rows = await query(
      'SELECT s.no, s.t, s.client, s.mode, s.total, s.by_name, (cn.id IS NOT NULL) AS cancelled FROM sales s ' +
        'LEFT JOIN credit_notes cn ON cn.sale_id = s.id WHERE s.company_id=?' + f.sql + ' ORDER BY s.t, s.id',
      [cid, ...f.params]);
    return sendCsv(res, fileBase(req, kind), [['Facture', 'Date', 'Client', 'Mode', 'Total', 'Vendeur', 'Statut'],
      ...rows.map((s) => [s.no, fmtDate(s.t, tz), s.client, s.mode, s.total, s.by_name, s.cancelled ? 'annulée' : 'ok'])]);
  }
  if (kind === 'credits') {
    const list = await creditList(cid, scope);
    return sendCsv(res, fileBase(req, kind), [['Facture', 'Client', 'Total', 'Reste'], ...list.map((s) => [s.no, s.client, s.total, s.rest])]);
  }
  throw bad('Export inconnu');
}));

/* ---------- Sauvegarde complète (admin) ---------- */
router.get('/backup', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const t = (sql) => query(sql, [cid]);
  const [locations, users, products, suppliers, moves, sales, lines, payments, notes, cash, log, customers, counts, countLines, orders, orderLines, supPayments] = await Promise.all([
    getLocations(cid),
    t('SELECT id, name, login, role, location_id, disabled FROM users WHERE company_id=?'),
    t('SELECT * FROM products WHERE company_id=?'),
    t('SELECT * FROM suppliers WHERE company_id=?'),
    t('SELECT * FROM stock_moves WHERE company_id=?'),
    t('SELECT * FROM sales WHERE company_id=?'),
    t('SELECT sl.* FROM sale_lines sl JOIN sales s ON s.id = sl.sale_id WHERE s.company_id=?'),
    t('SELECT * FROM payments WHERE company_id=?'),
    t('SELECT * FROM credit_notes WHERE company_id=?'),
    t('SELECT * FROM cash_entries WHERE company_id=?'),
    t('SELECT * FROM activity_log WHERE company_id=?'),
    t('SELECT * FROM customers WHERE company_id=?'),
    t('SELECT * FROM stock_counts WHERE company_id=?'),
    t('SELECT l.* FROM stock_count_lines l JOIN stock_counts c ON c.id = l.count_id WHERE c.company_id=?'),
    t('SELECT * FROM purchase_orders WHERE company_id=?'),
    t('SELECT l.* FROM purchase_order_lines l JOIN purchase_orders o ON o.id = l.po_id WHERE o.company_id=?'),
    t('SELECT * FROM supplier_payments WHERE company_id=?'),
  ]);
  const company = await getCompany(cid);
  await logActivity(req, 'sauvegarde', 'export');
  const day = new Date().toISOString().slice(0, 10);
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="sauvegarde_' + company.slug + '_' + day + '.json"');
  res.send(JSON.stringify({
    app: 'ManaGestion', v: 2, t: Date.now(), company, locations, users, products, suppliers,
    stock_moves: moves, sales, sale_lines: lines, payments, credit_notes: notes, cash_entries: cash, activity_log: log,
    customers, stock_counts: counts, stock_count_lines: countLines, purchase_orders: orders, purchase_order_lines: orderLines,
    supplier_payments: supPayments,
  }));
}));

module.exports = router;
