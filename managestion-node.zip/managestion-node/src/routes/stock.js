'use strict';
// Produits et mouvements de stock (réception, transfert).
const express = require('express');
const { query, tx, q } = require('../db');
const { adminOnly, managerUp, promoRoles, scopeLoc, locFilter } = require('../auth');
const { bad, notFound, wrap, str, num, int, logActivity } = require('../util');
const promo = require('../promo');

const router = express.Router();

/** Emplacement de référence pour une opération qui en exige un : celui choisi, sinon le premier actif. */
async function targetLoc(conn, scope, cid) {
  if (!scope.all) return scope.id;
  const rows = await q(conn, 'SELECT id FROM locations WHERE company_id=? AND archived=0 ORDER BY id LIMIT 1', [cid]);
  if (!rows[0]) throw bad('Aucun emplacement actif');
  return rows[0].id;
}

async function stockQty(conn, cid, productId, locId) {
  const rows = await q(conn,
    'SELECT COALESCE(SUM(qty),0) AS s FROM stock_moves WHERE company_id=? AND product_id=? AND location_id=?',
    [cid, productId, locId]);
  return rows[0].s;
}

/** Verrouille un produit actif de l'entreprise pour la durée de la transaction. */
async function lockProduct(conn, cid, id) {
  const rows = await q(conn, 'SELECT id, name, buy, price FROM products WHERE id=? AND company_id=? AND deleted=0 FOR UPDATE', [id, cid]);
  if (!rows[0]) throw notFound('Produit introuvable');
  return rows[0];
}

async function codeTaken(conn, cid, code, exceptId) {
  if (!code) return false;
  const rows = await q(conn, 'SELECT id FROM products WHERE company_id=? AND code=? AND deleted=0 AND id<>? LIMIT 1', [cid, code, exceptId || 0]);
  return !!rows[0];
}

/* ---------- Produits ---------- */
router.get('/products', wrap(async (req, res) => {
  const cid = req.user.company_id;
  const isAdmin = req.user.role === 'admin';
  const scope = await scopeLoc(req);
  const f = locFilter(scope, 'm.location_id');
  const rows = await query(
    'SELECT p.id, p.name, p.code, p.buy, p.price, p.min_stock AS `min`, p.promo_pct, p.promo_from, p.promo_to, COALESCE(SUM(m.qty),0) AS stock ' +
      'FROM products p LEFT JOIN stock_moves m ON m.product_id = p.id' + f.sql +
      ' WHERE p.company_id = ? AND p.deleted = 0 GROUP BY p.id ORDER BY p.name',
    [...f.params, cid]);

  let byLoc = {};
  if (isAdmin) {
    const mv = await query('SELECT product_id, location_id, SUM(qty) AS s FROM stock_moves WHERE company_id=? GROUP BY product_id, location_id', [cid]);
    for (const m of mv) (byLoc[m.product_id] = byLoc[m.product_id] || {})[m.location_id] = m.s;
  }
  const now = Date.now();
  res.json(rows.map((p) => {
    const o = {
      id: p.id, name: p.name, code: p.code, price: p.price, min: p.min, stock: p.stock,
      // promotion : salePrice est le prix réellement demandé à la caisse en ce moment
      promoPct: promo.pctOf(p), promoFrom: p.promo_from, promoTo: p.promo_to,
      promoState: promo.state(p, now), promoActive: promo.isActive(p, now), salePrice: promo.salePrice(p, now),
    };
    if (isAdmin) { o.buy = p.buy; o.byLoc = byLoc[p.id] || {}; }
    return o;
  }));
}));

router.post('/products', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const name = str(req.body.name, 150);
  const price = num(req.body.price, NaN);
  if (!name || !(price >= 0)) throw bad('Nom et prix de vente requis');
  const buy = Math.max(0, num(req.body.buy));
  const min = Math.max(0, int(req.body.min));
  const qty = Math.max(0, int(req.body.qty));
  const code = str(req.body.code, 80);
  const scope = await scopeLoc(req);
  const id = await tx(async (conn) => {
    if (await codeTaken(conn, cid, code)) throw bad('Ce code-barres est déjà utilisé par un autre produit');
    const r = await q(conn, 'INSERT INTO products (company_id, name, code, buy, price, min_stock) VALUES (?,?,?,?,?,?)', [cid, name, code, buy, price, min]);
    if (qty > 0) {
      const loc = await targetLoc(conn, scope, cid);
      await q(conn, 'INSERT INTO stock_moves (company_id, product_id, location_id, qty, why, by_name, t) VALUES (?,?,?,?,?,?,?)',
        [cid, r.insertId, loc, qty, 'stock initial', req.user.name, Date.now()]);
    }
    await logActivity(req, 'produit', name, conn);
    return r.insertId;
  });
  res.status(201).json({ id });
}));

router.put('/products/:id', adminOnly, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const id = int(req.params.id);
  const name = str(req.body.name, 150);
  const price = num(req.body.price, NaN);
  if (!name || !(price >= 0)) throw bad('Nom et prix requis');
  const code = str(req.body.code, 80);
  const adjust = int(req.body.adjust);
  const scope = await scopeLoc(req);
  await tx(async (conn) => {
    await lockProduct(conn, cid, id);
    if (await codeTaken(conn, cid, code, id)) throw bad('Ce code-barres est déjà utilisé par un autre produit');
    await q(conn, 'UPDATE products SET name=?, code=?, buy=?, price=?, min_stock=? WHERE id=? AND company_id=?',
      [name, code, Math.max(0, num(req.body.buy)), price, Math.max(0, int(req.body.min)), id, cid]);
    if (adjust) {
      const loc = await targetLoc(conn, scope, cid);
      if ((await stockQty(conn, cid, id, loc)) + adjust < 0) throw bad('Ajustement impossible : le stock deviendrait négatif');
      await q(conn, 'INSERT INTO stock_moves (company_id, product_id, location_id, qty, why, by_name, t) VALUES (?,?,?,?,?,?,?)',
        [cid, id, loc, adjust, 'ajustement', req.user.name, Date.now()]);
    }
    await logActivity(req, 'produit', name, conn);
  });
  res.json({ ok: true });
}));

router.delete('/products/:id', adminOnly, wrap(async (req, res) => {
  const r = await query('UPDATE products SET deleted=1 WHERE id=? AND company_id=?', [int(req.params.id), req.user.company_id]);
  if (!r.affectedRows) throw notFound('Produit introuvable');
  await logActivity(req, 'archive', String(req.params.id));
  res.json({ ok: true });
}));

/* ---------- Promotions ---------- */
// Applique le même pourcentage à un ou plusieurs produits (administrateur ou gérant).
router.post('/promotions', promoRoles, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const rawIds = Array.isArray(req.body.ids) ? req.body.ids : [];
  const ids = [...new Set(rawIds.map((x) => int(x)).filter((x) => x > 0))];
  if (!ids.length) throw bad('Choisissez au moins un produit');
  if (ids.length > 1000) throw bad('Trop de produits à la fois');
  const pct = Math.round(num(req.body.pct, NaN) * 100) / 100;
  if (!(pct >= 1 && pct <= 99)) throw bad('Le pourcentage doit être compris entre 1 et 99');
  const from = Math.max(0, int(req.body.from));
  const to = Math.max(0, int(req.body.to));
  if (from && to && to < from) throw bad('La date de fin précède la date de début');
  if (to && to < Date.now()) throw bad('La date de fin est déjà passée');
  const count = await tx(async (conn) => {
    const rows = await q(conn, 'SELECT id FROM products WHERE company_id=? AND deleted=0 AND id IN (?) FOR UPDATE', [cid, ids]);
    if (rows.length !== ids.length) throw bad('Un des produits choisis n\'existe plus');
    await q(conn, 'UPDATE products SET promo_pct=?, promo_from=?, promo_to=? WHERE company_id=? AND id IN (?)', [pct, from, to, cid, ids]);
    await logActivity(req, 'promo', '-' + pct + ' % sur ' + ids.length + ' produit(s)', conn);
    return rows.length;
  });
  res.json({ count });
}));

// Retire toutes les promotions de l'entreprise.
router.delete('/promotions', promoRoles, wrap(async (req, res) => {
  const r = await query('UPDATE products SET promo_pct=0, promo_from=0, promo_to=0 WHERE company_id=? AND promo_pct>0', [req.user.company_id]);
  await logActivity(req, 'promo', 'toutes les promotions retirées (' + r.affectedRows + ')');
  res.json({ count: r.affectedRows });
}));

// Retire la promotion d'un produit.
router.delete('/promotions/:id', promoRoles, wrap(async (req, res) => {
  const id = int(req.params.id);
  const r = await query('UPDATE products SET promo_pct=0, promo_from=0, promo_to=0 WHERE id=? AND company_id=? AND deleted=0', [id, req.user.company_id]);
  if (!r.affectedRows) throw notFound('Produit introuvable');
  await logActivity(req, 'promo', 'promotion retirée (produit ' + id + ')');
  res.json({ ok: true });
}));

/* ---------- Réception de stock ---------- */
router.post('/stock/receive', managerUp, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const productId = int(req.body.productId);
  const qty = int(req.body.qty);
  if (!(qty > 0)) throw bad('Entrez la quantité à ajouter');
  const scope = await scopeLoc(req, { single: true });
  const supplier = str(req.body.supplier, 150);
  const name = await tx(async (conn) => {
    const p = await lockProduct(conn, cid, productId);
    await q(conn, 'INSERT INTO stock_moves (company_id, product_id, location_id, qty, why, cost, supplier, by_name, t) VALUES (?,?,?,?,?,?,?,?,?)',
      [cid, productId, scope.id, qty, 'réception', qty * p.buy, supplier, req.user.name, Date.now()]);
    await logActivity(req, 'stock', p.name + ' +' + qty, conn);
    return p.name;
  });
  res.status(201).json({ name, qty });
}));

/* ---------- Transfert entre emplacements ---------- */
router.post('/stock/transfer', managerUp, wrap(async (req, res) => {
  const cid = req.user.company_id;
  const productId = int(req.body.productId);
  const qty = int(req.body.qty);
  const to = int(req.body.to);
  const from = req.user.role === 'admin' ? int(req.body.from) : req.user.location_id;
  if (!from || !to || from === to) throw bad('Choisissez deux emplacements différents');
  if (!(qty > 0)) throw bad('Quantité requise');
  await tx(async (conn) => {
    const locs = await q(conn, 'SELECT id, name FROM locations WHERE company_id=? AND archived=0 AND id IN (?)', [cid, [from, to]]);
    const lf = locs.find((l) => l.id === from);
    const lt = locs.find((l) => l.id === to);
    if (!lf || !lt) throw bad('Emplacement invalide');
    const p = await lockProduct(conn, cid, productId);
    const have = await stockQty(conn, cid, productId, from);
    if (qty > have) throw bad('Stock insuffisant à l\'origine (' + have + ')');
    const t = Date.now();
    await q(conn, 'INSERT INTO stock_moves (company_id, product_id, location_id, qty, why, by_name, t) VALUES (?,?,?,?,?,?,?), (?,?,?,?,?,?,?)',
      [cid, productId, from, -qty, 'transfert → ' + lt.name, req.user.name, t,
        cid, productId, to, qty, 'transfert ← ' + lf.name, req.user.name, t]);
    await logActivity(req, 'transfert', p.name + ' ' + qty + ' : ' + lf.name + ' → ' + lt.name, conn);
  });
  res.status(201).json({ ok: true });
}));

module.exports = router;
module.exports.stockQty = stockQty;
