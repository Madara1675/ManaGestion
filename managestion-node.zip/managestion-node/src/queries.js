'use strict';
// Requêtes partagées entre plusieurs routes.
const { query } = require('./db');
const { locFilter } = require('./auth');

/** Ventes à crédit non annulées avec un reste à payer, selon l'emplacement. */
async function creditList(cid, scope) {
  const f = locFilter(scope, 's.location_id');
  const rows = await query(
    'SELECT * FROM (' +
      'SELECT s.id, s.no, s.t, s.client, s.total, s.location_id AS loc, s.total - COALESCE(p.paid, 0) AS rest ' +
      'FROM sales s ' +
      'LEFT JOIN credit_notes cn ON cn.sale_id = s.id ' +
      'LEFT JOIN (SELECT sale_id, SUM(amount) AS paid FROM payments WHERE company_id = ? GROUP BY sale_id) p ON p.sale_id = s.id ' +
      "WHERE s.company_id = ? AND s.mode = 'Crédit' AND cn.id IS NULL" + f.sql +
    ') x WHERE x.rest > 0 ORDER BY x.t',
    [cid, cid, ...f.params]);
  return rows;
}

/** Valeur du stock courant (au prix d'achat et au prix de vente). */
async function stockValue(cid, scope) {
  const f = locFilter(scope, 'location_id');
  const rows = await query(
    'SELECT COALESCE(SUM(s.q * p.buy), 0) AS buyv, COALESCE(SUM(s.q * p.price), 0) AS sellv ' +
      'FROM products p JOIN (SELECT product_id, SUM(qty) AS q FROM stock_moves WHERE company_id = ?' + f.sql + ' GROUP BY product_id) s ' +
      'ON s.product_id = p.id WHERE p.company_id = ? AND p.deleted = 0',
    [cid, ...f.params, cid]);
  return rows[0];
}

/** Dette envers chaque fournisseur = valeur reçue sur les bons de commande - paiements effectués. */
async function supplierBalances(cid) {
  const rows = await query(
    'SELECT s.id, s.name, s.phone, ' +
      'COALESCE((SELECT SUM(pol.received * pol.cost) FROM purchase_order_lines pol JOIN purchase_orders po ON po.id = pol.po_id WHERE po.supplier_id = s.id AND po.company_id = ?), 0) AS received, ' +
      'COALESCE((SELECT SUM(sp.amount) FROM supplier_payments sp WHERE sp.supplier_id = s.id AND sp.company_id = ?), 0) AS paid ' +
      'FROM suppliers s WHERE s.company_id = ? ORDER BY s.name',
    [cid, cid, cid]);
  return rows.map((r) => ({ ...r, due: Math.round((r.received - r.paid) * 100) / 100 }));
}

module.exports = { creditList, stockValue, supplierBalances };
