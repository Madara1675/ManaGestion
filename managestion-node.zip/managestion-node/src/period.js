'use strict';
// Période d'abonnement à payer à une date donnée (sans dépendance, testable seule).
// Règle : à partir du 30 du mois (ou du dernier jour si le mois est plus court, ex. février),
// c'est l'abonnement du mois suivant qui est dû. Avant, c'est celui du mois en cours.
// d = Date déjà décalée dans le fuseau voulu (on lit ses champs UTC).
function duePeriod(d) {
  const y = d.getUTCFullYear();
  const m = d.getUTCMonth();
  const last = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  const shift = d.getUTCDate() >= Math.min(30, last) ? 1 : 0;
  const t = new Date(Date.UTC(y, m + shift, 1));
  return t.getUTCFullYear() + '-' + String(t.getUTCMonth() + 1).padStart(2, '0');
}
// Vrai à partir du 30 du mois (ou du dernier jour d'un mois plus court) : l'abonnement du mois suivant est à payer.
function inDueWindow(d) {
  const last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
  return d.getUTCDate() >= Math.min(30, last);
}
module.exports = { duePeriod, inDueWindow };
