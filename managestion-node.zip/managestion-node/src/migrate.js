'use strict';
// Crée les tables si elles n'existent pas. Appelé au démarrage du serveur et par "npm run migrate".
const fs = require('fs');
const path = require('path');
const { pool } = require('./db');

async function migrate() {
  const file = path.join(__dirname, '..', 'database', 'schema.sql');
  const sql = fs
    .readFileSync(file, 'utf8')
    .split('\n')
    .filter((l) => !l.trim().startsWith('--'))
    .join('\n');
  const statements = sql.split(/;\s*(?:\n|$)/).map((s) => s.trim()).filter(Boolean);
  for (const st of statements) await pool.query(st);

  // Mise à jour des bases créées par une version précédente : ajoute les colonnes manquantes
  const upgrades = [
    ['companies', 'po_seq', 'INT UNSIGNED NOT NULL DEFAULT 0'],
    ['sales', 'customer_id', 'INT UNSIGNED NULL'],
    ['sales', 'discount', 'DECIMAL(14,2) NOT NULL DEFAULT 0'],
    ['products', 'promo_pct', 'DECIMAL(5,2) NOT NULL DEFAULT 0'],
    ['products', 'promo_from', 'BIGINT NOT NULL DEFAULT 0'],
    ['products', 'promo_to', 'BIGINT NOT NULL DEFAULT 0'],
    ['sale_lines', 'list_price', 'DECIMAL(14,2) NOT NULL DEFAULT 0'],
    ['sale_lines', 'promo_pct', 'DECIMAL(5,2) NOT NULL DEFAULT 0'],
  ];
  for (const [table, column, ddl] of upgrades) {
    const [found] = await pool.query(
      'SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?',
      [table, column]);
    if (!found.length) await pool.query('ALTER TABLE `' + table + '` ADD COLUMN `' + column + '` ' + ddl);
  }

  // Rôles : l'ancien « vendeur » devient « gérant » (gérant d'un emplacement)
  await pool.query("UPDATE users SET role = 'gérant' WHERE role = 'vendeur'");
  return statements.length;
}

module.exports = migrate;

if (require.main === module) {
  migrate()
    .then((n) => { console.log('Base de données prête (' + n + ' tables vérifiées).'); return pool.end(); })
    .catch((e) => { console.error('Échec de la migration :', e.message); process.exit(1); });
}
