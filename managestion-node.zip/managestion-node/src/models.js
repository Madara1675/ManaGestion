'use strict';
const { query } = require('./db');
const subscription = require('./subscription');

/** Entreprise au format attendu par l'interface. */
function mapCompany(r) {
  return {
    id: r.id,
    slug: r.slug,
    name: r.name,
    holder: r.holder,
    bank: r.bank,
    addr: r.addr,
    gsm: r.gsm,
    e1: r.email1,
    e2: r.email2,
    nif: r.nif,
    cur: r.currency,
    tva: r.tva,
    foot: r.footer,
    logo: r.logo || '',
  };
}

async function getCompany(cid) {
  const rows = await query('SELECT * FROM companies WHERE id = ?', [cid]);
  return rows[0] ? mapCompany(rows[0]) : null;
}

async function getLocations(cid) {
  return query(
    'SELECT id, name, type, addr, code, archived FROM locations WHERE company_id = ? ORDER BY id',
    [cid]
  );
}

/** Données envoyées au navigateur après connexion ou au rechargement de la page. */
async function sessionData(user) {
  const [company, locations] = await Promise.all([getCompany(user.company_id), getLocations(user.company_id)]);
  const st = (await subscription.statuses([user.company_id])).get(user.company_id);
  return {
    sub: { unpaid: st.unpaid, period: st.period, ...subscription.info() },
    user: { id: user.id, name: user.name, login: user.login, role: user.role, location_id: user.location_id || null },
    company,
    locations: locations.map((l) => ({ ...l, archived: !!l.archived })),
  };
}

module.exports = { mapCompany, getCompany, getLocations, sessionData };
