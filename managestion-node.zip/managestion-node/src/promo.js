'use strict';
// Promotions : un produit peut porter un pourcentage de réduction (1 à 99 %),
// avec une date de début et une date de fin facultatives (0 = pas de limite).
// Le prix promotionnel est toujours calculé par le serveur à partir du prix de vente normal.

const pctOf = (p) => {
  const n = Number(p.promo_pct);
  return Number.isFinite(n) && n > 0 ? n : 0;
};

/** La promotion est-elle en cours à l'instant `now` (ms) ? */
function isActive(p, now = Date.now()) {
  if (!pctOf(p)) return false;
  if (p.promo_from && now < p.promo_from) return false;
  if (p.promo_to && now > p.promo_to) return false;
  return true;
}

/** Prix demandé au client : prix normal, ou prix réduit arrondi à l'unité si la promotion est en cours. */
function salePrice(p, now = Date.now()) {
  const base = Number(p.price) || 0;
  return isActive(p, now) ? Math.max(0, Math.round(base * (1 - pctOf(p) / 100))) : base;
}

/** '' (aucune), 'active', 'planned' (pas encore commencée) ou 'ended' (terminée). */
function state(p, now = Date.now()) {
  if (!pctOf(p)) return '';
  if (p.promo_from && now < p.promo_from) return 'planned';
  if (p.promo_to && now > p.promo_to) return 'ended';
  return 'active';
}

module.exports = { pctOf, isActive, salePrice, state };
