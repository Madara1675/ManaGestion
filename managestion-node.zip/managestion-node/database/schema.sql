-- ManaGestion : schéma MySQL / MariaDB (utf8mb4, InnoDB)
-- Ce fichier est appliqué automatiquement au démarrage (npm run migrate).
-- Vous pouvez aussi l'importer à la main avec phpMyAdmin. Il est sans danger si relancé.
-- Les dates sont des horodatages en millisecondes (colonnes "t" et "created_at").

CREATE TABLE IF NOT EXISTS companies (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  slug VARCHAR(40) NOT NULL,
  name VARCHAR(150) NOT NULL,
  holder VARCHAR(150) NOT NULL DEFAULT '',
  bank VARCHAR(150) NOT NULL DEFAULT '',
  addr VARCHAR(255) NOT NULL DEFAULT '',
  gsm VARCHAR(40) NOT NULL DEFAULT '',
  email1 VARCHAR(150) NOT NULL DEFAULT '',
  email2 VARCHAR(150) NOT NULL DEFAULT '',
  nif VARCHAR(60) NOT NULL DEFAULT '',
  currency VARCHAR(10) NOT NULL DEFAULT 'KMF',
  tva DECIMAL(5,2) NOT NULL DEFAULT 0,
  footer VARCHAR(500) NOT NULL DEFAULT '',
  logo MEDIUMTEXT NULL,
  blocked TINYINT(1) NOT NULL DEFAULT 0,
  credit_note_seq INT UNSIGNED NOT NULL DEFAULT 0,
  po_seq INT UNSIGNED NOT NULL DEFAULT 0,
  created_at BIGINT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_companies_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS locations (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  name VARCHAR(120) NOT NULL,
  type VARCHAR(20) NOT NULL DEFAULT 'magasin',
  addr VARCHAR(255) NOT NULL DEFAULT '',
  code VARCHAR(10) NOT NULL,
  seq INT UNSIGNED NOT NULL DEFAULT 0,
  archived TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uq_locations_code (company_id, code),
  CONSTRAINT fk_locations_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  name VARCHAR(100) NOT NULL,
  login VARCHAR(60) NOT NULL,
  pin_hash VARCHAR(100) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'employé',
  location_id INT UNSIGNED NULL,
  disabled TINYINT(1) NOT NULL DEFAULT 0,
  created_at BIGINT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_login (company_id, login),
  CONSTRAINT fk_users_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
  CONSTRAINT fk_users_location FOREIGN KEY (location_id) REFERENCES locations (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  name VARCHAR(150) NOT NULL,
  code VARCHAR(80) NOT NULL DEFAULT '',
  buy DECIMAL(14,2) NOT NULL DEFAULT 0,
  price DECIMAL(14,2) NOT NULL DEFAULT 0,
  min_stock INT NOT NULL DEFAULT 0,
  promo_pct DECIMAL(5,2) NOT NULL DEFAULT 0,
  promo_from BIGINT NOT NULL DEFAULT 0,
  promo_to BIGINT NOT NULL DEFAULT 0,
  deleted TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY ix_products_company (company_id, deleted),
  KEY ix_products_code (company_id, code),
  CONSTRAINT fk_products_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS suppliers (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  name VARCHAR(150) NOT NULL,
  phone VARCHAR(40) NOT NULL DEFAULT '',
  PRIMARY KEY (id),
  KEY ix_suppliers_company (company_id),
  CONSTRAINT fk_suppliers_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Journal des mouvements de stock : le stock d'un produit = somme des quantités (entrées +, sorties -).
CREATE TABLE IF NOT EXISTS stock_moves (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  location_id INT UNSIGNED NOT NULL,
  qty INT NOT NULL,
  why VARCHAR(150) NOT NULL DEFAULT '',
  cost DECIMAL(14,2) NOT NULL DEFAULT 0,
  supplier VARCHAR(150) NOT NULL DEFAULT '',
  by_name VARCHAR(100) NOT NULL DEFAULT '',
  t BIGINT NOT NULL,
  PRIMARY KEY (id),
  KEY ix_moves_stock (company_id, location_id, product_id),
  KEY ix_moves_product (product_id),
  KEY ix_moves_time (company_id, t),
  CONSTRAINT fk_moves_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
  CONSTRAINT fk_moves_product FOREIGN KEY (product_id) REFERENCES products (id),
  CONSTRAINT fk_moves_location FOREIGN KEY (location_id) REFERENCES locations (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS customers (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  name VARCHAR(150) NOT NULL,
  phone VARCHAR(40) NOT NULL DEFAULT '',
  addr VARCHAR(255) NOT NULL DEFAULT '',
  note VARCHAR(255) NOT NULL DEFAULT '',
  deleted TINYINT(1) NOT NULL DEFAULT 0,
  created_at BIGINT NOT NULL,
  PRIMARY KEY (id),
  KEY ix_customers_company (company_id, deleted),
  CONSTRAINT fk_customers_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sales (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  location_id INT UNSIGNED NOT NULL,
  customer_id INT UNSIGNED NULL,
  no VARCHAR(40) NOT NULL,
  client VARCHAR(150) NOT NULL DEFAULT 'Client comptoir',
  mode VARCHAR(30) NOT NULL DEFAULT 'Espèces',
  discount DECIMAL(14,2) NOT NULL DEFAULT 0,
  total DECIMAL(14,2) NOT NULL DEFAULT 0,
  by_name VARCHAR(100) NOT NULL DEFAULT '',
  t BIGINT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sales_no (company_id, no),
  KEY ix_sales_loc_time (company_id, location_id, t),
  KEY ix_sales_customer (customer_id),
  CONSTRAINT fk_sales_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
  CONSTRAINT fk_sales_customer FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE SET NULL,
  CONSTRAINT fk_sales_location FOREIGN KEY (location_id) REFERENCES locations (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sale_lines (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sale_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  name VARCHAR(150) NOT NULL,
  price DECIMAL(14,2) NOT NULL,
  buy DECIMAL(14,2) NOT NULL DEFAULT 0,
  qty INT NOT NULL,
  list_price DECIMAL(14,2) NOT NULL DEFAULT 0,
  promo_pct DECIMAL(5,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY ix_lines_sale (sale_id),
  KEY ix_lines_product (product_id),
  CONSTRAINT fk_lines_sale FOREIGN KEY (sale_id) REFERENCES sales (id) ON DELETE CASCADE,
  CONSTRAINT fk_lines_product FOREIGN KEY (product_id) REFERENCES products (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Règlements des ventes à crédit
CREATE TABLE IF NOT EXISTS payments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  sale_id INT UNSIGNED NOT NULL,
  location_id INT UNSIGNED NOT NULL,
  no VARCHAR(40) NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  by_name VARCHAR(100) NOT NULL DEFAULT '',
  t BIGINT NOT NULL,
  PRIMARY KEY (id),
  KEY ix_payments_sale (sale_id),
  KEY ix_payments_time (company_id, location_id, t),
  CONSTRAINT fk_payments_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
  CONSTRAINT fk_payments_sale FOREIGN KEY (sale_id) REFERENCES sales (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Avoirs : une facture ne se modifie jamais, elle s'annule par un avoir (un seul par facture)
CREATE TABLE IF NOT EXISTS credit_notes (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  location_id INT UNSIGNED NOT NULL,
  sale_id INT UNSIGNED NOT NULL,
  no VARCHAR(40) NOT NULL,
  sale_no VARCHAR(40) NOT NULL,
  total DECIMAL(14,2) NOT NULL,
  refund DECIMAL(14,2) NOT NULL DEFAULT 0,
  reason VARCHAR(255) NOT NULL DEFAULT '',
  by_name VARCHAR(100) NOT NULL DEFAULT '',
  t BIGINT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_credit_notes_sale (sale_id),
  UNIQUE KEY uq_credit_notes_no (company_id, no),
  KEY ix_credit_notes_time (company_id, location_id, t),
  CONSTRAINT fk_credit_notes_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
  CONSTRAINT fk_credit_notes_sale FOREIGN KEY (sale_id) REFERENCES sales (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Opérations de trésorerie saisies à la main (loyer, salaires...). location_id NULL = niveau entreprise.
CREATE TABLE IF NOT EXISTS cash_entries (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  location_id INT UNSIGNED NULL,
  label VARCHAR(200) NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  kind VARCHAR(5) NOT NULL DEFAULT 'out',
  by_name VARCHAR(100) NOT NULL DEFAULT '',
  t BIGINT NOT NULL,
  PRIMARY KEY (id),
  KEY ix_cash_time (company_id, t),
  CONSTRAINT fk_cash_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS activity_log (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  by_name VARCHAR(100) NOT NULL DEFAULT '',
  type VARCHAR(40) NOT NULL,
  detail VARCHAR(255) NOT NULL DEFAULT '',
  t BIGINT NOT NULL,
  PRIMARY KEY (id),
  KEY ix_log_time (company_id, t),
  CONSTRAINT fk_log_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Accès propriétaire modifiable depuis l'interface (une seule ligne). Tant qu'elle n'existe pas, OWNER_LOGIN / OWNER_PIN s'appliquent.
CREATE TABLE IF NOT EXISTS owner_account (
  id TINYINT UNSIGNED NOT NULL,
  login VARCHAR(60) NOT NULL,
  pin_hash VARCHAR(100) NOT NULL,
  updated_at BIGINT NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inventaires physiques : chaque comptage garde le stock attendu, le stock compté et le prix d'achat du moment
CREATE TABLE IF NOT EXISTS stock_counts (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  location_id INT UNSIGNED NOT NULL,
  note VARCHAR(255) NOT NULL DEFAULT '',
  by_name VARCHAR(100) NOT NULL DEFAULT '',
  t BIGINT NOT NULL,
  PRIMARY KEY (id),
  KEY ix_counts_company (company_id, t),
  CONSTRAINT fk_counts_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
  CONSTRAINT fk_counts_location FOREIGN KEY (location_id) REFERENCES locations (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS stock_count_lines (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  count_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  name VARCHAR(150) NOT NULL,
  expected INT NOT NULL,
  counted INT NOT NULL,
  buy DECIMAL(14,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY ix_count_lines (count_id),
  CONSTRAINT fk_count_lines_count FOREIGN KEY (count_id) REFERENCES stock_counts (id) ON DELETE CASCADE,
  CONSTRAINT fk_count_lines_product FOREIGN KEY (product_id) REFERENCES products (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bons de commande fournisseurs. La dette envers un fournisseur = valeur reçue - paiements.
CREATE TABLE IF NOT EXISTS purchase_orders (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  location_id INT UNSIGNED NOT NULL,
  supplier_id INT UNSIGNED NOT NULL,
  supplier_name VARCHAR(150) NOT NULL,
  no VARCHAR(40) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'ouvert',
  note VARCHAR(255) NOT NULL DEFAULT '',
  by_name VARCHAR(100) NOT NULL DEFAULT '',
  t BIGINT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_po_no (company_id, no),
  KEY ix_po_supplier (supplier_id),
  KEY ix_po_loc (company_id, location_id, t),
  CONSTRAINT fk_po_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
  CONSTRAINT fk_po_location FOREIGN KEY (location_id) REFERENCES locations (id),
  CONSTRAINT fk_po_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS purchase_order_lines (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  po_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  name VARCHAR(150) NOT NULL,
  qty INT NOT NULL,
  received INT NOT NULL DEFAULT 0,
  cost DECIMAL(14,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY ix_po_lines (po_id),
  CONSTRAINT fk_po_lines_po FOREIGN KEY (po_id) REFERENCES purchase_orders (id) ON DELETE CASCADE,
  CONSTRAINT fk_po_lines_product FOREIGN KEY (product_id) REFERENCES products (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS supplier_payments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  supplier_id INT UNSIGNED NOT NULL,
  location_id INT UNSIGNED NULL,
  amount DECIMAL(14,2) NOT NULL,
  note VARCHAR(255) NOT NULL DEFAULT '',
  by_name VARCHAR(100) NOT NULL DEFAULT '',
  t BIGINT NOT NULL,
  PRIMARY KEY (id),
  KEY ix_sp_supplier (supplier_id),
  KEY ix_sp_time (company_id, t),
  CONSTRAINT fk_sp_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
  CONSTRAINT fk_sp_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Abonnements : un paiement par entreprise et par mois (period = AAAA-MM). Enregistré par le propriétaire.
CREATE TABLE IF NOT EXISTS subscription_payments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  period CHAR(7) NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  t BIGINT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_subscription_period (company_id, period),
  CONSTRAINT fk_subscription_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
